#$ -S /bin/bash
#$ -t 1-50
#$ -N concatReads.sh
#$ -cwd 

# # # # # # # # # # # # # # # # # # # # # # # # # # # 
# This shell script is an example
# to use it, you'll need to change the file names appropriately.
# # # # # # # # # # # # # # # # # # # # # # # # # # # 


cat concatReads.sh

dataname=s_7  ### 
datafolder='.'

## if you want to parallelize your tasks to run within a server time limit,
## These lines are set up to work with the SGE job system
## In my experience, processing 1 million reads takes about 8 hrs
numseqs2process=500000  
numseqs2skip=$(( ( ${SGE_TASK_ID}-1 ) * ${numseqs2process} ))

date

perl /data/soniat/overlapper/concatReads.pl \
--numseqs2skip=$numseqs2skip \
--numseqs2process=$numseqs2process \
--adaptersFile=/data/soniat/overlapper/data/${dataname}_adapters+anchors10N.fa \
${datafolder}/${dataname}_1_sequence.txt \
${datafolder}/${dataname}_2_sequence.txt

date


: <<COMMENTS
# additional optional options
--outputFolder=results_${dataname} \
--debug \
--baseFreqFile=/data/soniat/overlapper/data/aboutdata/${sp}_base_freq_file.txt \
COMMENTS
