#!/usr/bin/perl -w
# use lib "/home/soniat/src/perlmodules";    # EDIT THIS LINE so it points to the *.pm files you downloaded
use OutputSequenceFile ':all';
use QualityConversion ':all';
#use Overlapper::ConsensusQual ':all';
use ConsensusQual ':all';

use Getopt::Long;
use File::Basename qw{fileparse};
use List::Util qw/ min max sum /;

use vars qw($ascii_shift %q2qv_table %binomial_table);

# DECLARE SUBS
# general general functions
sub maxEntry_byValue;  # not the most efficient buddy!

# General seq functions
sub revcomp;

# seq name parsing
sub encodeStatsInName;
sub get_oltrue_maqsim;
sub get_oltrue_mapped;
sub check_seqNames;

# wrapper
sub overlapSeqs;

# basic seq-handling functions
sub readAdaptersFile;
sub concatAdapters;
sub getOverlapRegions;
sub makeConsensus;
sub joinGenomicSeqs;


# alignment scoring Functions
sub matchesByQual;  
sub percentID;  
sub rightMinusWrong;
sub rightMinusWrong_onlygoodqual;

# alignment scoring support
sub aln_stats2localnose;
sub pickHigherQualityBase; 
sub __pickHigherQualityBase_withThreshold; # deprecated
sub matchesByQual_justOne; ## 
sub matchesByQual_keepSum; ##

# basic alignment evaluation output
sub printScores_v1;
sub printScores_v1b;


# DEFAULT PARAMETERS
my %doc;
my $debug=0;
my $qualityScaling = 'Solexa';
my $numseqs2process=1e8;
my $numseqs2skip=0;
my $outputFolder = ".";
my $scoringFunc= \&rightMinusWrong ;
my %params = ( 'minOverlap'  => 10 ,
	       'maxOverlap'  => 250 ,
	       'scoringFunc' => $scoringFunc ,
	       'qualityScaling' => '' ,
	       'adapters'    => '' ,
	       'baseFreqFile'=> '' ,
	       ) ;
my %scoringFuncName2subref = ( 'rightMinusWrong' => \&rightMinusWrong ,
			       'rightMinusWrong_onlygoodqual' => \&rightMinusWrong_onlygoodqual ,
			       'rightMinusWrong_normalized' => \&rightMinusWrong_normalized ,
			       'matchesByQual' => \&matchesByQual ,
			       'binomial' => \&binomial ,
			       ) ;  # not doing anything right now.


# GET USER SUPPLIED PARAMETERS
GetOptions ( 'debug!' => \$debug , 
	     'numseqs2process:i'  => \$numseqs2process ,
	     'numseqs2skip:i'  => \$numseqs2skip ,
	     'outputFolder:s'  => \$outputFolder ,
	     'qualityScaling:s'  => \$params{'qualityScaling'} ,
             'baseFreqFile:s'  => \$params{'baseFreqFile'} ,
	     'binomialTableFile:s'  => \$params{'binomialTableFile'} ,
	     'adaptersFile:s'  => \$params{'adapters'} ,
	     'minOverlap:i'  => \$params{'minOverlap'} ,
#            'scoringFunction:s' => \ $params{'scoringFunc'} ,
	    ) ;
# $params{'scoringFunc'} = $scoringFuncName2subref{$scoringFunc};  # ugly
$doc{'adapters'}  = 
    "TIP: Providing an adapters file is recommended if your library may include inserts shorter than your read length.
     See documentation for details \n ";
if( ! $params{'adapters'}){ print STDERR $doc{'adapters'} };

# PROCESS INPUT
$doc{'argv'} = 'Input two sequence.txt files in FR orientation';
@ARGV==2 or die $doc{'argv'};
my ($filename1, $filename2) = @ARGV;
my $infile_basename = (fileparse($filename1))[0];
(my $filenameOut = $infile_basename) =~ s/_1_?|\-[FR]/_ovl_$numseqs2skip+$numseqs2process\_/;
$filenameOut =~ s/\.txt|\.fastq//;

# SET INPUT_QUALITY SCALING BASED ON FLAG OR GUESS BASED ON FILENAME
our $ascii_shift;
if ( $params{'qualityScaling'} =~ /(solexa)|(illumina)/i ) {
    $ascii_shift = 64;
} elsif ( $params{'qualityScaling'} =~ /phred|sanger/i ) {
    $ascii_shift = 33;
} else {
    $params{'qualityScaling'} = ($infile_basename =~ /txt$/)? 'Illumina' : 'Sanger' ;
    $ascii_shift = ($infile_basename =~ /txt$/)? 64: 33;
    print STDERR "Based on the filenames' extension, SHE-RA guessed that input files had $params{'qualityScaling'} quality scaling.\n";
}

# SET GLOBAL VARS, BUILD TABLES
our %q2qv_table = maketable_q2qv($ascii_shift);
if ( $params{'binomialTableFile'} ) {  # FIX THIS if you want to use alternative scoring scheme.
    read_binomial_table($params{'binomialTableFile'}) or die "no binomal table";
}
my $parse_oltrue_func = ($infile_basename =~ /^sim/) ? \&get_oltrue_maqsim : \&get_oltrue_mapped ;
read_base_freq_table($params{'baseFreqFile'}) if $params{'baseFreqFile'};
make_consensusQual_tables();  # resets (need to reset after different baseFreq ? ? )


# OPEN FILES
open $FILE1, "< $filename1" or die "Can't open $filename1";
open $FILE2, "< $filename2" or die "Can't open $filename2";
my $ovlseqfile = "$outputFolder/$filenameOut" . ".fa" ;
my $ovlqualfile = "$outputFolder/$filenameOut" . ".quala" ;
open $OVLSEQ, "> $ovlseqfile" or die "Can't open $ovlseqfile for output: $!";
open $OVLQUAL, "> $ovlqualfile" or die "Can't open $ovlqualfile for output: $!";
if ($debug) {
    open $DEBUGDATA, "> $outputFolder/debug.out" or die "can't open debug.out for output";
    open $EVALDATA, "> $outputFolder/eval.out" or die "can't open eval.out for output";
}


# PROCESS SEQUENCES 
print STDERR "Processing sequence files ...... \n";
my $adaptersData_ref = readAdaptersFile($params{'adapters'}) if ($params{'adapters'});
my $numseqs;
while (my $name1 = <$FILE1>) {
    chomp( $name1 );
    chomp(my $name2 = <$FILE2>);
#    check_seqNames($name1, $name2) or die "reads seem mislabeled";
    map { s/ /:/g } ($name1, $name2);

    chomp( my $seq1 = <$FILE1> );
    chomp( my $seq2 = <$FILE2> );
    $tmp = <$FILE1>; # + name line
    $tmp = <$FILE2>; 
    chomp ( my $qual1 = <$FILE1> );
    chomp ( my $qual2 = <$FILE2> );

    next if (++$numseqs <= $numseqs2skip);

    my $data_ref = { 'name1'  => $name1 ,
		     'seq1'   => $seq1 ,
		     'length1'=> length($seq1) ,
		     'qual1'  => $qual1 ,
		     'name2'  => $name2 ,
		     'seq2'   => $seq2 , 
		     'qual2'  => $qual2 ,
		     'length2'=> length($seq2) ,
		 } ;

    my $output_ref = overlapSeqs($data_ref, \%params);
    printFa($OVLSEQ, $output_ref) if  $output_ref->{'seq'}; # does this catch anything anymore ? 
    printQuala($OVLQUAL, $output_ref) if $output_ref->{'seq'}; 
    
    last if ( $numseqs >= $numseqs2skip + $numseqs2process);
}
# write log file that includes time, params, etc.

sub readAdaptersFile {
    my $filename = shift;
    open $ADAPTERS, "< $filename" or die "can't open adaptersfile $filename";
    my ($fwdadapter, $bwdadapter);
    while(<$ADAPTERS>) {
	if (/Forward/i) {          # change pattern?
	    chomp( $fwdadapter = <$ADAPTERS>);
	} elsif (/Reverse/i) {
	    chomp( $bwdadapter = <$ADAPTERS>);
	}
    }
    close $ADAPTERS;
    ($fwdadapter=~/^[ACGTN]+$/i && $bwdadapter=~/^[ACGTN]+$/i) or die "Adapters file incorrectly formatted";

    my %adapter_data = (
			'fwdseq' => $fwdadapter ,
			'fwdqual' => chr(40+$ascii_shift) x length($fwdadapter) ,
			'bwdseq' => $bwdadapter ,
			'bwdseqrc' => revcomp($bwdadapter) ,
			'bwdqual' => chr(40+$ascii_shift) x length($fwdadapter) ,
			);
    return \%adapter_data;
}

sub concatAdapterSeqs {
    my %data = %{$_[0]};
    my %adapters = %{$_[1]};
#    $data{'seq1noAdapter'} = $data{'seq1'}; # you'd have to add a lot more and rev/rc them where appropriate.
#    $data{'seq2noAdapter'} = $data{'seq2'}; #
    $data{'adapter1len'} = length($adapters{'fwdseq'});  # redundant sometimes but often convenient.
    $data{'adapter2len'} = length($adapters{'bwdseq'});
    $data{'seq1'} =  $adapters{'fwdseq'} . $data{'seq1'};
    $data{'qual1'} =  $adapters{'fwdqual'} . $data{'qual1'};
    $data{'seq2'} =  $adapters{'bwdseq'} . $data{'seq2'};
    $data{'qual2'} =  $adapters{'bwdqual'} . $data{'qual2'};
    $data{'adapters'} = 1;  # length info? 
#    printFq_pe($DEBUGDATA, \%data);
    return \%data;
}

sub overlapSeqs {  
    my %data = %{$_[0]};  
    my %params = %{$_[1]};
    ($minOverlap, $maxOverlap) = @params{'minOverlap','maxOverlap'};

    my %aln_scores;
    my %aln_stats;
    my %overlapped;

    %data= %{concatAdapterSeqs(\%data, $adaptersData_ref)} if $params{'adapters'}; 
    $maxOverlap = min( length($data{'seq1'}), length($data{'seq2'}), $maxOverlap);  # these lengths include the adapters, if any
    $data{'seq2rc'} = revcomp( $data{'seq2'} );
    $data{'qual2r'} =  reverse( $data{'qual2'} );
    @data{('qv1', 'qv2r')} = ( qualString2qvArray($data{'qual1'}), qualString2qvArray($data{'qual2r'}) );

    foreach my $overlapLength ($minOverlap .. $maxOverlap) {
	my %data2aln = %{ getOverlapRegions(\%data, $overlapLength) }; # make a ref maybe
	$aln_scores{$overlapLength}  = &{$params{'scoringFunc'}}(\%data2aln, \%params);
    }
    my ($bestOverlap , $bestScore) = maxEntry_byValue(\%aln_scores);
    @aln_stats{ ('bestOverlap', 'bestScore', 'minOverlap', 'maxOverlap') } =
	($bestOverlap, $bestScore, $minOverlap, $maxOverlap) ;

    $aln_stats{'statistic'} = aln_scores2localnose(\%aln_scores, \%aln_stats) ; # will this skip all the adapters cols in aln ? 

    %overlapped = %{makeConsensus(\%data, \%params, $bestOverlap) };
    $overlapped{'name'} = encodeStatsInName( $data{'name1'}, \%aln_stats);

    if ($debug && 1) { 
#	matchesByQual_justOne(\%data2aln, \%params);  # gotta make data2pass, pass ovl...
	printScores_v1b( $EVALDATA, \%aln_scores, \%aln_stats, \%overlapped);
	print_shortreadAln( $DEBUGDATA, \%data, $bestOverlap);
    }
    return \%overlapped;
}

sub getOverlapRegions {
    my %data = %{$_[0]};
    my $overlapLength = $_[1];
#    if ($overlapLength > min($data{'length1'},$data{'length2'}) ) {  # inefficient but possibly the cleanest
#	my %data = %{ concatAdapterSeqs(\%data) };  # no you'd need to do this before the rc/qv processing.
#    }
    my %data2align = (
		      'frag1seq'  => substr($data{'seq1'}, -$overlapLength) ,
		      'frag1qual' => substr($data{'qual1'}, -$overlapLength) ,
		      'frag1qv'   => [ @{$data{'qv1'}}[-$overlapLength..-1] ] ,  # UGLY!
		      'frag2seq'  =>  substr($data{'seq2rc'}, 0, $overlapLength) ,
		      'frag2qual' => substr($data{'qual2r'}, 0, $overlapLength) ,
		      'frag2qv'   => [ @{$data{'qv2r'}}[0..$overlapLength-1] ] , 
		      );   
    return \%data2align;
}

sub makeConsensus {  
    my %data = %{$_[0]};
    my %params = %{$_[1]};
    my $ol = $_[2];  # best overlapLength

    my ($num_matches, $num_mismatches) = (0,0);

    my %frag_data = %{ getOverlapRegions(\%data, $ol) } ; 
    my ($f1s,$f2s,$f1qv,$f2qv) = @frag_data{('frag1seq','frag2seq', 'frag1qv','frag2qv')};

    my ($overlapSeq, @overlapQv);
    foreach my $i (0 .. $ol-1) { # local numbering within overlap
	my ($b1,$b2) = ( substr($f1s,$i,1) ,  substr($f2s,$i,1) ) ;
	my ($qv1,$qv2) = ($f1qv->[$i], $f2qv->[$i]);
	my ($nt, $qv);  # consensus
	if ($b1 eq 'N') {
	    ($nt,$qv) = ($b2, $qv2); 
	} elsif ($b2 eq 'N') {
	    ($nt,$qv) = ($b1, $qv1);
	} elsif ($b1 eq $b2) {
	    ($nt,$qv) = consensusQual($b1,$b2,$qv1, $qv2) ;  # now excludes the both-Ns case
	    $num_matches++;
	} else {
	    ($nt, $qv) = consensusQual($b1,$b2,$qv1, $qv2);
	    $num_mismatches++;
	}
	$overlapSeq .= $nt;
	push(@overlapQv, $qv);
#	print {$DEBUGDATA} join(" ", $b1,$qv1, $qv2, $b2, '-->', $nt, $qv)."\n";
    }
    print {$DEBUGDATA} join(" ", $data{'name1'}, $ol, $num_matches, $num_mismatches)."\n" if $debug;
    my $insertData_ref = joinGenomicSeqs(\%data, $ol, $overlapSeq, \@overlapQv);
    return $insertData_ref;
}


sub joinGenomicSeqs {  # join up the insert and trim off the rest.
    my %data = %{$_[0]} ;
    my ($ol, $overlapSeq) = @_[1,2];
    my @overlapQv = @{$_[3]};

    my $insertSeq = '';
    my @insertQv = ();

    my $ins_len = sum($data{'length1'},$data{'length2'}) - $ol;  # genomic lengths
    if ($ins_len < 1 ) { return {'seq'=>'N', 'qv'=> [2] } };
    my ($seq1genomic, $seq2genomic, @qv1genomic, @qv2genomic);

    if ( $params{'adapters'}) { # change to:  if $ovl < $max_genomicLen  ?   ugly unconcatentation
	# i think only meant to trim NONsequenced adapters here, 
	$seq1genomic = substr($data{'seq1'}, -$data{'length1'} );
	$seq2genomic = substr($data{'seq2rc'}, 0, $data{'length2'} );
	@qv1genomic = @{$data{'qv1'}}[-$data{'length1'} .. -1];  
	@qv2genomic = @{$data{'qv2r'}}[0 .. $data{'length2'}-1 ];
    } else {
	($seq1genomic, $seq2genomic) = @data{'seq1','seq2rc'};
	@qv1genomic = @{$data{'qv1'}};
	@qv2genomic = @{$data{'qv2r'}};
    }

#    print STDERR join(" ..","line305",@data{'seq1','seq2rc'})."\n";
#    print STDERR join(" ","line306 qv1 orig length", (@qv1genomic+0), "\n qv2 orig length: ",(@qv2genomic+0) )."\n";
#    print STDERR join(" ","line307 seq1genomic seq2genomc",$seq1genomic,$seq2genomic)."\n";

    if ($ol <= min($data{'length1'},$data{'length2'}) ) {  # shorter overlaps -> overlap does not need trimming. easy.
     	$insertSeq = substr($seq1genomic,0, -$ol) . $overlapSeq . substr($seq2genomic,$ol); # paste 
	@insertQv = @qv1genomic[0..$data{'length1'}-$ol-1];
	push @insertQv, @overlapQv;
#	push @insertQv, @{$data{'qv2r'}}[$ol..$data{'length2'}-1];
	push @insertQv, @qv2genomic[$ol..$data{'length2'}-1];
    } else { # trim overlap first, then add it to other sequence
        my ($ovl_nonGenomicLen_5prime, $ovl_nonGenomicLen_3prime) = (0,0);
	($ovl_nonGenomicLen_5prime,$ovl_nonGenomicLen_3prime) = map { max($ol - $_, 0) } @data{ ('length1','length2') }; 
	my $overlapSeq_genomic = substr($overlapSeq, $ovl_nonGenomicLen_5prime, 
					$ol-$ovl_nonGenomicLen_5prime-$ovl_nonGenomicLen_3prime);
	my @overlapQv_genomic = @overlapQv[$ovl_nonGenomicLen_5prime .. $#overlapQv-$ovl_nonGenomicLen_3prime];
#	print STDERR join(" ","LINE 335","trimmed from overlap",$ovl_nonGenomicLen_5prime, $ovl_nonGenomicLen_3prime, 
#			  'left in overlapQv', (@overlapQv_genomic+0))."\n";

	if ($ol >= max($data{'length1'},$data{'length2'}) ) {  # get whole insert from  overlap if ol> max len 
	    $insertSeq = $overlapSeq_genomic;
	    @insertQv = @overlapQv_genomic;

#	    print STDERR join(" ", "LINE 352", "insertQv len", $#insertQv, "overlapQv_genomic", $#overlapQv_genomic)."\n"; 
#	    $insertSeq = substr($overlapSeq, $ovl_nonGenomicLen_5prime, 
#				$ol - $ovl_nonGenomicLen_5prime -$ovl_nonGenomicLen_3prime); # need to check seq
#	    @insertQv = @overlapQv[$ovl_nonGenomicLen_5prime 
#				   .. $#overlapQv-$ovl_nonGenomicLen_5prime-$ovl_nonGenomicLen_3prime];
	} else {  # get info not in seq
	    my ($seq1_outside_ovl, $seq2_outside_ovl) = map { $_ - $ol } @data{ ('length1','length2') };
	    if ($ol < $data{'length1'} ) {  # seq1 has additional information in its 5prime
		$insertSeq .= substr($seq1genomic, 0, $data{'length1'} - $ol ); 
		push(@insertQv, @qv1genomic[0 .. $data{'length1'} - $ol -1 ] );
	    }

	    $insertSeq .= $overlapSeq_genomic;
	    push @insertQv, @overlapQv_genomic;
#	    print STDERR join(" ", "LINE 352", "insertQv len", $#insertQv, "overlapQv_genomic", $#overlapQv_genomic)."\n"; 

	    if ($ol < $data{'length2'} ) { # seq2 has additional information 
		$insertSeq .= substr($seq2genomic, -$seq2_outside_ovl); # 3prime of seq2rc
		push(@insertQv, @qv2genomic[-$seq2_outside_ovl .. -1] );
	    }
	}
    }
#    print STDERR join(" ","\nline360 insertseq ",$insertSeq , "len" . length($insertSeq), "insertQv len", @insertQv+0)."\n";
    if (length($insertSeq) != $ins_len) {die length($insertSeq)." is not length $ins_len , ol = $ol"};
    if (@insertQv+0 != $ins_len) { die "insertQv len" . (@insertQv+0) . " should be length $ins_len, ol = $ol"};
    return {'seq'=>$insertSeq, 'qv'=> \@insertQv };
}

sub aln_scores2localnose {
    my %aln_scores = %{$_[0]};
    my %aln_stats = %{$_[1]};
    my ($bestScore,$bestOverlap) = @aln_stats{'bestScore','bestOverlap'};

    my $worstScore = min( values %aln_scores);

    my @localScores; 
    map { 
        my $edgeEffect = exists($aln_scores{$_}) ? $aln_scores{$_} : $worstScore;  #suboptimal
        push( @localScores, $edgeEffect);
    } ($bestOverlap-3 .. $bestOverlap+3) ;
    
    my @localScores_sorted = sort { $b <=> $a } @localScores;
    my ($localSecondBestScore, $localWorstScore) = @localScores_sorted[1, $#localScores_sorted] ;
    my $localSpread =  $bestScore - $localWorstScore + 0.00001;
    $aln_stats{'localnose'} =  abs (($bestScore - $localSecondBestScore) / $localSpread) ;

    return $aln_stats{'localnose'};
}

sub pickHigherQualityBase { 
    my ($b1,$b2,$qv1,$qv2) = @_; # bases and their quality character... or quality value
    my $consensus_nt = ($qv1 > $qv2) ? $b1 : $b2 ;
#    my $consensus_nt = ($q1 gt $q2) ? $b1 : $b2 ;  # accomodate qual chars ?? 
    return $consensus_nt
}

sub percentID {
    my ($f1,$f2) = @{$_[0]}{('frag1seq','frag2seq')};
    my $score = 0;
    my ($num_matches, $num_mismatches, $num_Ns) = countMatches(@_);
    my $percentID = $num_matches / length($f1) * 100;
    return $percentID;
}

sub count_matches {
    my ($f1,$f2) = @{$_[0]}{('frag1seq','frag2seq')};
    my $num_matches = 0;
    my $num_mismatches = 0;
    my $num_Ns =0;
    foreach my $i (0 .. length($f1)-1) {
	my ($b1, $b2) = ( substr($f1,$i,1) , substr($f2,$i,1) );
	if ( ($b1 eq 'N') || ($b2 eq'N')) {
	    $num_Ns++;
	} elsif ( substr($f1,$i,1) eq substr($f2,$i,1) )  {
	    $num_matches++;
	} else {
	    $num_mismatches++;
	}
    }
    return ($num_matches, $num_mismatches, $num_Ns);
}

sub exp_score {
    my ($nonN, $Smm) = @_;
    my $Pm = 0.25; # uncorrected for %gc
    my $exp_score_misaln = $nonN * ( 1 * $Pm + $Smm * (1-$Pm) ) ;
    return $exp_score_misaln;
}

sub rightMinusWrong_normalized {
    my ($num_matches, $num_mismatches, $num_Ns) = count_matches(@_);
    my $Smm = -1.4;
    my $score = 1 * $num_matches 
	+ $Smm  * $num_mismatches 
	- exp_score( $num_matches+$num_mismatches, $Smm);
    return $score ;
}

sub rightMinusWrong {
    my ($f1,$f2) = @{$_[0]}{('frag1seq','frag2seq')};
    my ($num_matches, $num_mismatches, $num_Ns) = count_matches(@_);
    my $score = 1 * $num_matches - 1.4 * $num_mismatches;
    return $score; 
}
sub binomial {
    my ($num_matches, $num_mismatches, $num_Ns) = count_matches(@_);
    my $n = $num_matches + $num_mismatches;
    my $k = $num_matches;
    my $minus_logP = -1 * $binomial_table{$n}{$k};
    return $minus_logP;
}
sub read_binomial_table {
    my $filename = shift;
    open my $TABLEFILE, "< $filename" 
        or die "can't open binomial table file: $filename";
    my $n=1;
    my %table;
    while(<$TABLEFILE>) {
        chomp;
        my @temp =split;
	my $k=0; # new row
	map{ $table{$n}{$k++} = $_ }@temp;
	$n++;

    }
    close $TABLEFILE;
#    print "print line 469 n=3, k=2," . $table{3}{2} ."\n";
    #  some sort of chektable here 
    %binomial_table = %table;
    return 1;
}



sub rightMinusWrong_onlygoodqual {
    my ($f1,$f2,$fqv1,$fqv2) = @{$_[0]}{('frag1seq','frag2seq', 'frag1qv','frag2qv')};
    my $minqual = 5; 
    my $alnscore = 0;
    foreach my $i (0 .. length($f1)-1) {
	my ($b1, $b2) = ( substr($f1,$i,1) , substr($f2,$i,1) );
	if ( ($fqv1->[$i] < $minqual) && ($fqv2->[$i] < $minqual) ) {
	    $alnscore += 0;
#	    print STDERR "$i: ".join("_", $fqv1->[$i] ,$fqv2->[$i], $minqual )." ";
	} elsif  ( ($b1 eq 'N') || ($b2 eq'N')) {
	    $alnscore += 0;
	} else {
	    $alnscore += ( substr($f1,$i,1) eq substr($f2,$i,1) ) ? 1 : -1.5 ;
	}
    }
    return $alnscore;
}

sub matchesByQual_keepSum {  # NEVER WORKED ? 
    my %data = %{$_[0]};
    my ($f1,$f2,$fqv1,$fqv2) = @{$_[0]}{('frag1seq','frag2seq', 'frag1qv','frag2qv')};
    my $ol = length($f1);
    if ($ol == $params{'minOverlap'}) {  # my too possesive... 
	my %match_qualhist = map {$_=>0} (0..40); 
	my %mismatch_qualhist = map {$_=>0} (0..40);
    }
    foreach my $i (0 .. $ol-1) {
	if ( substr($f1,$i,1) eq substr($f2,$i,1) ) { 
	    $match_qualhist{$fqv1->[$i]}++; # if you want to bin less finely, use substr($qv,0,1)
	    $match_qualhist{$fqv2->[$i]}++;
	} else {
	    $mismatch_qualhist{$fqv1->[$i]}++;
	    $mismatch_qualhist{$fqv2->[$i]}++;
	}
    }
    if ($debug && $ol==$params{'maxOverlap'}) {
	print ${EVALDATA} join(" ", "ALL_MATCHES_QUALS:", @match_qualhist{(1..40)} )."\n";
	print ${EVALDATA} join(" ", "ALL_MISMATCHES_QUALS:", @mismatch_qualhist{(1..40)} )."\n";
    }
    my $score = 1; # Placeholder...
    return $score;
}

sub matchesByQual_justOne { # keep it simple!  NEVER WORKED
    my %data = %{$_[0]};
    my ($f1,$f2,$fqv1,$fqv2) = @{$_[0]}{('frag1seq','frag2seq', 'frag1qv','frag2qv')};
    my $ol = length($f1);
    my %match_qualhist = map {$_=>0} (0..40); 
    my %mismatch_qualhist = map {$_=>0} (0..40);
    foreach my $i (0 .. $ol-1) {
	if ( substr($f1,$i,1) eq substr($f2,$i,1) ) { 
	    $match_qualhist{$fqv1->[$i]}++; # if you want to bin less finely, use substr($qv,0,1)
	    $match_qualhist{$fqv2->[$i]}++;
	} else {
	    $mismatch_qualhist{$fqv1->[$i]}++;
	    $mismatch_qualhist{$fqv2->[$i]}++;
	}
    }
    if ($debug) {
	print ${EVALDATA} join(" ", "OLTRUE_MATCHES_QUALS:", @match_qualhist{(1..40)} )."\n";
	print ${EVALDATA} join(" ", "OLTRUE_MISMATCHES_QUALS:", @mismatch_qualhist{(1..40)} )."\n";
    }
    my $score = 1; # placeholder
    return $score;
}

sub encodeStatsInName { 
    my ($name1, $stats_ref) = @_;
    $name1  =~ s/\/1$// ;
    $bestScore = sprintf("%2.1f", $stats_ref->{'bestScore'});  #this is kind of meaningless anyhow
    $statistic = sprintf("%2.2f",$stats_ref->{'statistic'}) ;
    my $newname = join("_", $name1, $stats_ref->{'bestOverlap'} .'bp', $bestScore, $statistic);
    return $newname;
}
sub check_seqNames {
    my ($n1,$n2)= map {substr($_,0,-2) }@_;
    map { s/\#.*//; } ($n1, $n2) ; # for the barcodes
    my $names_ok = ($n1 eq $n2) +0;
    if ($debug) {$names_ok or print STDERR $n1."\n".$n2."\n";}
    return $names_ok;
}

sub get_oltrue_maqsim {
    my %seq_data = %{$_[0]};
    my ($b,$e) = ( split("_", $seq_data{'name1'}) )[2,3] ;
    my $seqlengthssum = $seq_data{'length1'} + $seq_data{'length2'} ;
    my $trueOverlap = $seqlengthssum - ($e-$b+1);
    return $trueOverlap;
}

sub get_oltrue_mapped {  # @HWI-EAS413:7:1:6:1044#AAAC|maq_NA/1
    my %seq_data = %{$_[0]};
    my $trueOverlap = ( $seq_data{'name1'} =~ /_(\w+)\/1$/ ) ? $1 : 'NA';
    return $trueOverlap;
}


sub maxEntry_byValue {
    my %h = %{$_[0]};
    my $maxvalue = max(values %h);
    my @maxkeys = grep {$h{$_} == $maxvalue} keys %h;
    return ($maxkeys[0], $maxvalue);  # a little kludgy
}

sub revcomp{
    my $DNAin = $_[0]; 
    my $DNAout = reverse($DNAin);
    $DNAout =~ tr/ACGTacgt/TGCAtgca/;
    return $DNAout;
}


sub printScores_v1 { # move this outside
    my $EVALDATA = $_[0];
    my %aln_scores = %{$_[1]};
    my %aln_stats = %{ $_[2]};
    my %seq_data = %{$_[3]};

    $aln_stats{'ovl_true'} = &{$parse_oltrue_func}(\%seq_data) if ( ! exists $aln_stats{'ovl_true'} );

    my ($ovl_true, $bestOverlap, $bestScore, $minOverlap, $maxOverlap) = 
	@aln_stats{ ('ovl_true', 'bestOverlap', 'bestScore', 'minOverlap', 'maxOverlap') };

    print {$EVALDATA} join(" ","\nSCORES:", map{sprintf "%2.2f ", $_ }@aln_scores{($minOverlap..$maxOverlap)} );
    print {$EVALDATA} " ".join(" ", "OVERLAP_FOUND:" , $bestOverlap , sprintf("%3g",$bestScore));
    print {$EVALDATA} " OVERLAP_TRUE: " . $ovl_true;

    return 1;
}
sub printScores_v1b { # move this outside
    my $EVALDATA = $_[0];
    my %aln_scores = %{$_[1]};
    my %aln_stats =  %{$_[2]};
    my %overlapped = %{$_[3]};

    my $minOverlap = min(keys %aln_scores);
    my $maxOverlap = max(keys %aln_scores);

    print {$EVALDATA} $overlapped{'name'} . "|";
    print {$EVALDATA} join(" ","SCORES:", map{sprintf "%2.2f ", $_ }@aln_scores{($minOverlap..$maxOverlap)} );
    print {$EVALDATA} "\n";
#    print {$EVALDATA} " ".join(" ", "OVERLAP_FOUND:" , $bestOverlap , sprintf("%3g",$bestScore));
#    print {$EVALDATA} " OVERLAP_TRUE: " . $ovl_true;
    return 1;
}

sub unloadHash4debug {
    my %data = %{$_[0]};
    print {$DEBUGDATA} join("\n", 
			    "fragdata from makeCons", 
			    "qual2r "    . $data{'qual2r'} ,
			    "qv2r "      . join(" ", @{$data{'qv2r'}}) ,
			    "frag2seq "  . $frag_data{'frag2seq'} ,
			    "frag2qual " . $frag_data{'frag2qual'} ,
			    "frag2qv "   . join(" ", @{$frag_data{'frag2qv'}}) ,
			    ) ."\n"  if $debug;
}

__END__


# # # # # # # # # Version Notes # # # # # # # # # # # # # # # 
# FIX LINE 107 !! 
# fixed the len1>ol>len2 case.
# fixed the reverse problem
# matches by qual never worked.
# calculating consensusQual for the adapter regions slightly wasteful
# retooled the matching fxns ... did i check it ? 
# # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # 
