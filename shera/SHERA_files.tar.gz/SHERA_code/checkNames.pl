#!/usr/bin/perl -w
my ($filename1, $filename2) = @ARGV;

open $FILE1, "< $filename1" or die "Can't open $filename1";
open $FILE2, "< $filename2" or die "Can't open $filename2";

my $numseqs2skip =0;
my $checkLength =0;

# faVSorigtxt();
faVSquala();

sub faVSquala {
    while (my $name1 = <$FILE1>) {
	chomp( $name1 );
	chomp(my $name2 = <$FILE2>);
	++$numseqs;
	
	( substr($name1,0,-2) eq substr($name2,0,-2) ) or die "reads seem mislabeled $numseqs $name1 $name2";


	chomp( my $seq = <$FILE1> );
	chomp( my $qual = <$FILE2> );
	
	next if (++$numseqs <= $numseqs2skip);
	
	if ($checkLength) {
	    my @splitqual = split " " ,$qual;
	    ( @splitqual+0  == length($seq) ) or die "seq and qual not same length $numseqs $name1 $name2";
	}
    }
}

sub faVSorigtxt {
    my $groupedlines_file1 =2;
    my $groupedlines_file2 =4;

    while (my $name1 = <$FILE1>) {
	chomp( $name1 );
	chomp(my $name2 = <$FILE2>);
	++$numseqs;
	
	$name1 =~ /^[>@](.*)\#/;
	my $name1_base= $1;
	$name2 =~ /^[>@](.*)\#/;
	my $name2_base= $1;
	($name1_base eq $name2_base) or
	    die "reads seem mislabeled $numseqs $name1 $name1_base \n $name2 $name2_base ";
	
	for (2..$groupedlines_file1) {
	    <$FILE1>; 
	}
	for (2..$groupedlines_file2) {
	    <$FILE2>;
	}
	
	next if (++$numseqs <= $numseqs2skip);
	

    }
}

