package ConsensusQual;
#package Overlapper::ConsensusQual;

use 5.008005;
use strict;
use warnings;
#use lib "/home/soniat/src/perlmodules/QualityConversion/lib";  # why that worked ?
#use lib "/home/soniat/src/perlmodules/";  
use QualityConversion ':all';

require Exporter;

our @ISA = qw(Exporter);

# Items to export into callers namespace by default. Note: do not export
# names by default without a very good reason. Use EXPORT_OK instead.
# Do not simply export all your public functions/methods/constants.

# This allows declaration	use Overlapper::ConsensusQual ':all';
# If you do not need this, moving things directly into @EXPORT or @EXPORT_OK
# will save memory.
our %EXPORT_TAGS = ( 'all' => [ qw( 
				    read_base_freq_table
				    base_freq_table
				    make_consensusQual_tables
				    precompute_px_over_pnotx_table
				    precompute_p1r_times_p2w_table
				    precompute_p1r_times_p2r_table
				    consensusQual
				    ) ] );

our @EXPORT_OK = ( @{ $EXPORT_TAGS{'all'} } );

our @EXPORT = qw( 
	
);

our $VERSION = '0.02';


# Preloaded methods go here.

our %base_freq_table;
our %phredQual2errorProb_table;
our %p1r_times_p2r_table;
our %px_over_pnotx_table;
our %pr_times_pw_table;

sub make_consensusQual_tables {
    if ( ! defined( %base_freq_table) ) { # if we didn't read one in, use 50%
	%base_freq_table = ( 'A' => 0.25 ,  'T' => 0.25 , 
			     'C' => 0.25 ,  'G' => 0.25  );
#	print STDERR " No base frequencies defined, using 50% gc ... \n";
    }
    %phredQual2errorProb_table = maketable_phredQual2errorProb();
    %p1r_times_p2r_table = precompute_p1r_times_p2r_table();
    %px_over_pnotx_table = precompute_px_over_pnotx_table();
    %pr_times_pw_table = precompute_p1r_times_p2w_table();
    return 1;
}

sub read_base_freq_table {
    my $base_freq_filename = shift;
    open my $BASEFREQFILE, "< $base_freq_filename" 
	or die "can't open base frequencies file: $base_freq_filename";
    while(<$BASEFREQFILE>) {
	chomp;
	next unless /^GC|^AT/;
	my ($basepairs, $freq) =split;
	my @bases = split '',$basepairs;
	foreach my $base (@bases) {
	    $base_freq_table{$base} = $freq / 2.0 ;
	}
    }
    if (grep { ! exists( $base_freq_table{$_}) } qw/A C T G/) { die "check $base_freq_filename format" };
    return \%base_freq_table;
}

sub consensusQual {  # see OSN c. 20091205
    my ($b1,$b2,$qv1, $qv2) = @_;
    my %b2qv = ( $b1 => $qv1 , $b2 => $qv2 );

#    print STDERR join("\t", "\n", 'b1', 'b2', 'qv1', 'qv2',"\n", $b1,$b2,$qv1, $qv2)."\n";
    my ($consensusNt, $consensusQv, $pcr); # "pcr" = probability consensus base is right.

    my $p1r = 1 - phredQual2errorProb($qv1);  
    my $p2r = 1 - phredQual2errorProb($qv2);

    my $p1r_times_p2r = $p1r_times_p2r_table{$qv1}{$qv2};

    if ($b1 eq $b2) {
	$consensusNt = $b1;
        my $px_over_pnotx = $px_over_pnotx_table{ $b1 };
#       my $px = $base_freq_table{$b1};
#       print STDERR $px_over_pnotx ."\n";
#       print STDERR $p1r_times_p2r ."\n";
#       print STDERR "px_over_pnotx: " , $px_over_pnotx ."\n";
#       print STDERR $p1r  ."\n";
#       print STDERR $p2r ."\n";
#       print STDERR $p1r_times_p2r ."\n";
        $pcr = $p1r_times_p2r / ( $p1r_times_p2r + ( $px_over_pnotx ) * (1- $p1r - $p2r + $p1r_times_p2r));
    } else {  # "x" is the correct base (goodbase?), by convention  TERRIBLE notation
	my ($goodbase, $badbase);
	if ($qv1 == $qv2) {
	    ($goodbase, $badbase) =  ( int(rand(2)) < 1) ? ($b1,$b2) : ($b2,$b1) ;
	} else {
	    ($goodbase, $badbase) = sort {$b2qv{$b} <=> $b2qv{$a} } keys %b2qv;
	}
	my ($goodqual, $badqual) = @b2qv{ ($goodbase, $badbase) };

        my ($px, $py) =  @base_freq_table{ ($goodbase, $badbase) };
        my $px_over_pnotx = $px_over_pnotx_table{ $goodbase };
        my $pr_times_pw = $pr_times_pw_table{$b2qv{$goodbase}}{$b2qv{$badbase}};

#       print  STDERR "px_over_pnotx: " , $px_over_pnotx ."\n";
#       print  STDERR "p1r_times_p2w :  " , $pr_times_pw ."\n";
#	print STDERR "p1w_times_p2r : " , $pr_times_pw_table{$goodqual}{$badqual} ."\n";
#	print STDERR "p1r \t $p1r \n";
        $pcr = $pr_times_pw / ( $pr_times_pw + 
                                $px_over_pnotx * 
				( phredQual2errorProb($goodqual) * ($pr_times_pw_table{$goodqual}{$badqual} + 2) )
				);
 
	$consensusNt = $goodbase;
    }
    $consensusQv = prob2qv(1-$pcr);
    return ($consensusNt, $consensusQv, $pcr);
}

sub precompute_px_over_pnotx_table {
    foreach my $base ( keys %base_freq_table) {
        my $px = $base_freq_table{$base};
        $px_over_pnotx_table{$base} = $px / (1 - $px);
    }
    return %px_over_pnotx_table;
}

sub precompute_p1r_times_p2w_table {
    my %pr_times_pw_table;
    foreach my $rightbaseqv (0..41) {
        my $pright = 1 - $phredQual2errorProb_table{$rightbaseqv};
        foreach my $wrongbaseqv (0..41) {
            my $pwrong = $phredQual2errorProb_table{$wrongbaseqv};
            $pr_times_pw_table{$rightbaseqv}{$wrongbaseqv} = $pright * $pwrong;
        }
    }
    return %pr_times_pw_table;
}

sub precompute_p1r_times_p2r_table {
    # %phredQual2errorProb_table;
    my %p1r_times_p2r_table;
    foreach my $qv1 (0..41) {
        my $p1r = 1- $phredQual2errorProb_table{$qv1};
        foreach my $qv2 (0..41) {
            my $p2r = 1- $phredQual2errorProb_table{$qv2};
            $p1r_times_p2r_table{$qv1}{$qv2} = $p1r * $p2r;  # underflow worries ? 
        }
    }
    return %p1r_times_p2r_table;
}



1;
__END__

=head1 NAME

Overlapper::ConsensusQual - Perl extension for computing quality of a consensus \
of multiple base calls.

=head1 SYNOPSIS

  use Overlapper::ConsensusQual;
  consensusQual($base1,$base2,$phredQual1,$phredQual2);

=head1 DESCRIPTION

Given two independently-called bases at the same sequence position, and their qualities,
returns the quality (ie error probability) of the consensus call. 
Input qualities should be an integer in [0,41] .
The alignment is assumed correct in this calculation.
(First, precomputes some tables necessary to do this efficiently.)

=head2 EXPORT

None by default.


=head1 SEE ALSO

Mention other useful documentation such as the documentation of
related modules or operating system documentation (such as man pages
in UNIX), or any relevant external documentation such as RFCs or
standards.

If you have a mailing list set up for your module, mention it here.

If you have a web site set up for your module, mention it here.

=head1 AUTHOR

Sonia Timberlake, E<lt>soniat@gmail.comE<gt>

=head1 COPYRIGHT AND LICENSE

Copyright (C) 2009 by Sonia Timberlake

This library is free software; you can redistribute it and/or modify
it under the same terms as Perl itself, either Perl version 5.8.6 or,
at your option, any later version of Perl 5 you may have available.


=cut
