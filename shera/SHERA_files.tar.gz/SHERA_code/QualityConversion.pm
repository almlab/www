package QualityConversion;
use 5.008005;
use strict;
use warnings;

require Exporter;

our @ISA = qw(Exporter);

# Items to export into callers namespace by default. Note: do not export
# names by default without a very good reason. Use EXPORT_OK instead.
# Do not simply export all your public functions/methods/constants.

# This allows declaration	use QualityConversion ':all';
# If you do not need this, moving things directly into @EXPORT or @EXPORT_OK
# will save memory.
our %EXPORT_TAGS = ( 'all' => [ qw(
				   qualString2qvArray
				   phredQual2errorProb
				   prob2qv
				   prob2qualChar
				   maketable_q2qv
				   maketable_phredQual2errorProb
				   %q2qv_table
				   %phredQual2errorProb_table
				   ) ] ,
		     'functions' => [ qw(
				   prob2qv
				   prob2qualChar
                                   qualString2qvArray
                                   phredQual2errorProb
                                   maketable_q2qv
                                   maketable_phredQual2errorProb
					 ) ] ,
		     'tables' => [ qw(
				      %phredQual2errorProb_table
				      %q2qv_table
				  ) ] ,		     
		     );

our @EXPORT_OK = ( @{ $EXPORT_TAGS{'all'} } );

our @EXPORT = qw( );

our $VERSION = '0.01';


# Preloaded methods go here.
our %q2qv_table;  # gets made when calling package passes $ascii_shift 
our %phredQual2errorProb_table = maketable_phredQual2errorProb();

sub maketable_q2qv {
    our $ascii_shift = $_[0];
    %q2qv_table = map { chr($_ + $ascii_shift) => $_ } (0..41); # Solexa/Sanger --> quality conversion table
    $q2qv_table{ chr(0 + $ascii_shift) } = 1; # hack because qv=0 has no meaning
    return %q2qv_table;
}

sub maketable_phredQual2errorProb { # how to make accessible to another module
    %phredQual2errorProb_table = map { $_ => 10**($_ / -10.0) }(0..41); 
    return %phredQual2errorProb_table;
}

sub qualString2qvArray { # quality in ascii string format to array of numbers.
    my $qstring= $_[0]; 
    my @qvArray;
    map {
	my $ascii_symbol = substr($qstring,$_,1);
	defined ( my $qv = $q2qv_table{ substr($qstring,$_,1) }) or
	    die "Unrecognized quality character: $ascii_symbol . Quality scaling was set or guessed wrong. Please use --qualityScaling flag to specify correct quality scaling.";
#$	my $qv = $q2qv_table{ substr($qstring,$_,1) }) or
        push @qvArray, $qv;
    } (0 .. length($qstring)-1);
    return \@qvArray;
}


sub phredQual2errorProb { # quality VALUE (0..40) ---converted to ----> error Probability
    # use this function instead of the lookup table directly, so that you can catch errors.
    defined(my $qv = $_[0]) or die " phredQual2errorProb received no arguments";
    if ( defined($phredQual2errorProb_table{$qv}) ) {
	return $phredQual2errorProb_table{$qv} ;
    } else {
	print STDERR  "Unexpected quality score in input file --> output quality untrustworthy!\n";
	die "Unexpected quality score in input file. Did you specify with --qualityScaling flag correctly?";
	return 0.999 ;
    }
}


sub prob2qv { # make scalable
    my $p = $_[0];  # this is Pwrong
    my $qv = log($p)/log(10) * -10.0 ;
    my $phredqv = int($qv + 0.5) ;  # roundabout rounding
    return $phredqv;
}

sub prob2qualChar {  # make scalable
    my $p = $_[0];
    my $ascii_shift = $_[1];
    my $qv = log($p)/log(10) * -10.0 ;
    my $qualChar = chr ( int($qv + 0.5 ) + $ascii_shift);
    return $qualChar; 
}

1;
__END__


# Below is stub documentation for your module. You'd better edit it!

=head1 NAME

QualityConversion - Perl extension for blah blah blah

=head1 SYNOPSIS

  use QualityConversion;
  blah blah blah

=head1 DESCRIPTION

Stub documentation for QualityConversion, created by h2xs. It looks like the
author of the extension was negligent enough to leave the stub
unedited.

Blah blah blah.

=head2 EXPORT

None by default.



=head1 SEE ALSO

Mention other useful documentation such as the documentation of
related modules or operating system documentation (such as man pages
in UNIX), or any relevant external documentation such as RFCs or
standards.

If you have a mailing list set up for your module, mention it here.

If you have a web site set up for your module, mention it here.

=head1 AUTHOR

Sonia Timberlake, E<lt>sonita@gmail.comE<gt>

=head1 COPYRIGHT AND LICENSE

Copyright (C) 2009 by Sonia Timberlake

This library is free software; you can redistribute it and/or modify
it under the same terms as Perl itself, either Perl version 5.8.6 or,
at your option, any later version of Perl 5 you may have available.


=cut
