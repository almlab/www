package OutputSequenceFile;

use 5.008005;
use strict;
use warnings;
use List::Util qw/ min max sum /;


require Exporter;

our @ISA = qw(Exporter);

# Items to export into callers namespace by default. Note: do not export
# names by default without a very good reason. Use EXPORT_OK instead.
# Do not simply export all your public functions/methods/constants.

# This allows declaration	use OutputSequenceFile ':all';
# If you do not need this, moving things directly into @EXPORT or @EXPORT_OK
# will save memory.
our %EXPORT_TAGS = ( 'all' => [ qw( printFa
				    printFq
				    printFq_pe
				    printQuala
				    seq2paragraph
				    printMultiFasta
				    print_shortreadAln
				    ) ] );

our @EXPORT_OK = ( @{ $EXPORT_TAGS{'all'} } );
our @EXPORT = qw();
our $VERSION = '0.01';


sub printFa {
    my ($OUTFILE, $output_ref)= @_;
    (my $name =  $output_ref->{'name'}) =~ s/^[@>]//;
    print {$OUTFILE}  ">" . $name . "\n" . $output_ref->{'seq'} . "\n"; 
    return 1;
}

sub printFq {
    my ($OUTFILE, $output_ref)= @_;
    (my $name =  $output_ref->{'name'}) =~ s/^[@>]//;
    print {$OUTFILE}  "@" . $name . "\n" . $output_ref->{'seq'} . "\n"; 
    print {$OUTFILE}  "+" . "\n" . $output_ref->{'qual'} . "\n";
    return 1;
}
sub printFq_pe {
    my ($OUTFILE, $output_ref)= @_;
    (my $name1 =  $output_ref->{'name1'}) =~ s/^[@>]//;
    (my $name2 =  $output_ref->{'name2'}) =~ s/^[@>]//;
    print {$OUTFILE}  "@" . $name1 . "\n" . $output_ref->{'seq1'} . "\n"; 
    print {$OUTFILE}  "+" . "\n" . $output_ref->{'qual1'} . "\n";
    print {$OUTFILE}  "@" . $name2 . "\n" . $output_ref->{'seq2'} . "\n"; 
    print {$OUTFILE}  "+" . "\n" . $output_ref->{'qual2'} . "\n";
    return 1;
}
sub printQuala {
    my ($OUTFILE, $output_ref)= @_;
    (my $name =  $output_ref->{'name'}) =~ s/^[@>]//;
    print {$OUTFILE} ">" . $name . "\n";
    print {$OUTFILE} join(" ", @{$output_ref->{'qv'}} ). "\n";
    return 1;
}

sub seq2paragraph {  # used to be called printFasta
    my $nt = shift;
    my $l = (@_==1)? $_[0] : 60;
    $nt =~ s/([a-zA-Z]{$l})/$1\n/g;
    chomp($nt);
    return $nt;
}
sub printMultiFasta {
    my $outfile = shift;
    open OUTFILE, "> $outfile" or die "can't open $outfile:$!";
    my %mfa = %{$_[0]};
    map {
        print OUTFILE ">".$_."\n";
        print OUTFILE seq2paragraph($mfa{$_})."\n";
    } sort keys %mfa;
    return 1;
}

sub print_shortreadAln {
    my ($OUTFILE, $output_ref, $overlap)= @_;
    (my $name1 =  $output_ref->{'name1'}) =~ s/^[@>]//;
    my $name = substr($name1,0,-2) . "_ovl";
    my $seqLen1 = length($output_ref->{'seq1'});
    $overlap = min($overlap, $seqLen1);
    print {$OUTFILE} ">" . $name ."\n";
    print {$OUTFILE} $output_ref->{'seq1'} . "\n";
    print {$OUTFILE} "_" x ($seqLen1-$overlap) . $output_ref->{'seq2rc'} . "\n";
}

1;
__END__
# Below is stub documentation for your module. You'd better edit it!

=head1 NAME

OutputSequenceFile - Perl extension for outputting various format of sequence files

=head1 SYNOPSIS

  use OutputSequenceFile;
  sub printFa ();
  sub printFq ();
  sub printQuala ();
  sub seq2paragraph ();  # formally called printFasta
  sub printMultiFasta ();
  sub print_shortreadAln ($OUTFILE, $output_ref, $overlap) ;   # UNTESTED

  blah blah blah

=head1 DESCRIPTION

Stub documentation for OutputSequenceFile, created by h2xs. It looks like the
author of the extension was negligent enough to leave the stub
unedited.

Blah blah blah.

=head2 EXPORT

None by default.



=head1 SEE ALSO

Mention other useful documentation such as the documentation of
related modules or operating system documentation (such as man pages
in UNIX), or any relevant external documentation such as RFCs or
standards.

If you have a mailing list set up for your module, mention it here.

If you have a web site set up for your module, mention it here.

=head1 AUTHOR

Sonia Timberlake, E<lt>soniat@mit.eduE<gt>

=head1 COPYRIGHT AND LICENSE

Copyright (C) 2009 by Sonia Timberlake

This library is free software; you can redistribute it and/or modify
it under the same terms as Perl itself, either Perl version 5.8.6 or,
at your option, any later version of Perl 5 you may have available.


=cut
