#!/usr/bin/perl -w
my ($filename1, $filename2, $threshold) = @ARGV;

(@ARGV+0 == 3) or die "enter fasta file, quala file, and the threshold for the alignment statistic";

open $FILE1IN, "< $filename1" or die "Can't open $filename1";
open $FILE2IN, "< $filename2" or die "Can't open $filename2";

my $add2filename = ".filter_" . $threshold;
$filename1 =~ s/(\.\w+)$/$add2filename$1/;
$filename2 =~ s/(\.\w+)$/$add2filename$1/;

open $FILE1OUT, "> $filename1 " or die "Can't open $filename1";
open $FILE2OUT, "> $filename2" or die "Can't open $filename2";


while (my $name1 = <$FILE1IN>) {
    chomp( $name1 );
    chomp(my $name2 = <$FILE2IN>);
    ++$numseqs;
    ( substr($name1,0,-2) eq substr($name2,0,-2) ) or die "reads seem mislabeled $numseqs $name1 $name2";

    chomp( my $seq = <$FILE1IN> );
    chomp( my $qual = <$FILE2IN> );
    my @splitqual = split " " ,$qual;
    ( @splitqual+0  == length($seq) ) or die "seq and qual not same length $numseqs $name1 $name2";

    my @g = split("_",$name1);
#    print STDERR join(" ",@g);

    if ($g[-1] >= $threshold) {
	print {$FILE1OUT} $name1 . "\n" . $seq . "\n";
	print {$FILE2OUT} $name2 . "\n" . $qual . "\n";
    }

#    last if $numseqs > 10;
}


