The simplest way to get and run the basic SHERA algorithm: 
    wget  http://almlab.mit.edu/vibrioGenomes/SHERA_temp/downloads/SHERA_files.tar.gz
    tar -xvzf SHERA_files.tar.gz
    cd SHERA_code
    perl concatReads.pl --adaptersFile=s_7_adapters+anchors30N.fa forward_reads_file.txt  reverse_reads_file.txt

Important note on adapters files.
In order to avoid losing a substantial fraction of your reads, I strongly recommend you provide SHERA with an adapters file. You should check that your sequencing platform and your library uses the same Illumina adapters as in my example file. This allows you to find alignments when the insert length is shorter than the read length, and to trim adapters sequences from such inserts. NOTE! If your reads were barcoded on the chips but the barcodes have been removed from the sequence, and you want to use the adapters file option, you need to include the barcode in the adapters file. (This sounds counter-intuitive; drawing a picture of the library fragments helps.) Add the forward-read barcode to the end of the forward read adapter, and the reverse-read barcode to the end of the reverse read adapter. 

Note on quality scaling.
If your input files end with txt, SHERA assumes they use Solexa-quality scores. If they end in fastq, Phred-scaling is assumed. You can force the behavior you want by using the qualityScaling flag: --qualityScaling=(illumina|sanger)

Note on computation time.
As a rule of thumb, processing 1 million 140bp paired-end reads took me about 8 hours. If you want to parallelize the processing, I provided the script concatReads.sh for submitting separate SGE jobs. You will need to edit the first few lines to tell it where to look for your data. When the jobs complete, the SHERA output files can be concatenated.

