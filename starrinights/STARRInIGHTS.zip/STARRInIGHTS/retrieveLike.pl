#!/usr/bin/perl -w

use strict;

my $subseq_file = $ARGV[0]; # the output from make_subSeqList.pl, e.g. contig.60.concat3.1001.subseqs.txt
my $maxTrees = $ARGV[1]; # the maximum number of trees per node

# check for incomplete jobs:
my $leftovers = $subseq_file;
$leftovers =~ s/subseqs\.txt/\*\.phy/;
my $test = `ls $leftovers`;
print $test,"\n";
#unless ($test =~ m/cannot/) {
if ($test =~ m/phy/) {
    print "There are some \.phy files leftover, meaning some jobs submitted by writePhy\+submit did not finish. May want to deal with these\:\n";
    print $test,"\n";
    exit;
}

my $curr_dir = `pwd`;
chomp $curr_dir;
my $out_dir = $curr_dir."\/lk";
my $filename= $subseq_file;
$filename =~ s/subseqs\.txt//;
$filename .= "lk.txt";
my $out_file= $out_dir."\/".$filename;
unless (-d $out_dir) {
    `mkdir $out_dir`;
}
open OUT, ">>$out_file" || die;

# get likelihoods
my $lk_file = $subseq_file;
$lk_file =~ s/subseqs\.txt//;
$lk_file .= "0.phy_phyml_stat.txt";
my @lk;
open LK, "$lk_file" || die;
while (<LK>) {
    chomp;
    next unless (m/\#[\d]+/);
    my $lk = 'na';
    if (m/\#[\d]+[\s]+[\d]+[\s]+([\d\-\.]+)/) {
	$lk = $1;
    }
    push @lk, $lk;
}
close LK;

# get trees
my $tree_file = $subseq_file;
$tree_file =~ s/subseqs\.txt//;
$tree_file .= "0.phy_phyml_tree.txt";
my @trees;
open TREES, "$tree_file" || die;
while (<TREES>) {
    chomp;
    push @trees, $_;
}
close TREES;

my $rm_file = $subseq_file;
$rm_file =~ s/subseqs\.txt//;
$rm_file .= "0.";
my $sh_file = $rm_file."sh*";
my $log_file = $rm_file."log";
my $phy_file = $rm_file."phy*";
`rm $sh_file`;
`rm $log_file`;
`rm $phy_file`;

open SUBSEQS, "$subseq_file" || die;
my $last_sub_batch = 0;
my $treesPerJob = 0;
my $last_start = 0;
my $last_end = 0;
while (<SUBSEQS>) {
    chomp;
    my ($curr_batch, $start, $end) = split "\t";
    $last_start = $start;
    $last_end = $end;
    $treesPerJob++;
    if ( $treesPerJob > $maxTrees) {
	$last_sub_batch++;
	# open new lk file
	if ( (@lk+0) > 0 ) { # the array should be empty by now
	    print "error: lk array is not empty. ", (@lk+0), " entries still remain at ", $_,"\n";
	    exit;
	}
	@lk = (); # clear array
	$lk_file = $subseq_file;
	$lk_file =~ s/subseqs\.txt//;
	$lk_file .= $last_sub_batch.".phy_phyml_stat.txt";
	open LK, "$lk_file" || die;
	while (<LK>) {
	    chomp;
	    next unless (m/\#[\d]+/);
	    my $lk = 'na';
	    if (m/\#[\d]+[\s]+[\d]+[\s]+([\d\-\.]+)/) {
		$lk = $1;
	    }
	    push @lk, $lk;
	}
	close LK;
	if ( (@trees+0) > 0 ) { # the array should be empty by now
	    print "error: tree array is not empty. ", (@trees+0), " entries still remain at ", $_,"\n";
	    exit;
	}
	@trees = (); # clear array
	$tree_file = $subseq_file;
	$tree_file =~ s/subseqs\.txt//;
	$tree_file .= $last_sub_batch.".phy_phyml_tree.txt";
	open TREES, "$tree_file" || die;
	while (<TREES>) {
	    chomp;
	    push @trees, $_;
	}
	close TREES;
	$rm_file = $subseq_file;
	$rm_file =~ s/subseqs\.txt//;
	$rm_file .= $last_sub_batch.".";
	$sh_file = $rm_file."sh*";
	$log_file = $rm_file."log";
	$phy_file = $rm_file."phy*";
	`rm $sh_file`;
	`rm $log_file`;
	`rm $phy_file`;
	$treesPerJob = 1;
    }
    my $subseq_lk = shift(@lk);
    my $subseq_tr = shift(@trees);
    print OUT join "\t", $curr_batch, $start, $end, $subseq_lk, $subseq_tr;
    print OUT "\n";
}
