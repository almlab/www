nf<-layout(matrix(c(1,1,1,1,1,1,2,2,2,2,3,3,3,3,3,3,4,4),9,2,byrow=TRUE))
#layout.show(nf)
par(mar=c(0,5,1,1))

d <- read.table("contigs_out/contig.49.out",header=T)

#topoblocks
idx <- order(d[,1])
idxr <- order(d[,1],decreasing=T)
plot(d[idx,1],d[idx,3],type="n",xlim=c(0,max(d[,1])),xaxs="i",ylim=c(0,max(d[,3]+d[,4])),xlab="",ylab="Phyl. disc. metric",xaxt="n",las=1)
polygon(c(d[idx,1],d[idxr,1]),c(d[idx,3]-d[idx,4],d[idxr,3]+d[idxr,4]),col="lightblue")
points(d[idx,1],d[idx,3],type="l",lwd=3)
#d1<-d[d[,5]=="*",]
#d1<-d[d[,3]+d[,4]>0.1850,]
#points(d1[,1],d1[,3]+d1[,4],pch="*",col="red")
abline(0.19737, 0, lty = 5, col="red", lwd=1)
abline(0.1727, 0, col="red", lwd=1)
abline(0.14809, 0, lty = 5, col="red", lwd=1)

#alignment map
#xnames<-c("X1F273","X1F111","X1F53","X1F289","ZF14","ZF170","ZF270","ZF264")
#znames<-c("","","","1F289","ZF14","ZF170","ZF270","ZF264")
#fnames<-c("1F273","1F111","1F53","","","","","")
#image(as.matrix(d[idx,xnames]),axes=F,col=c("darkblue","white"))
#axis(2,at=seq(0,1,1/7),znames,las=2,tick=F,col.axis="red")
#axis(2,at=seq(0,1,1/7),fnames,las=2,tick=F,col.axis="green")
image(as.matrix(d[idx,7:ncol(d)]),axes=F,col=c("darkblue","white"))
axis(2,at=seq(0,1,1/(ncol(d)-7)),colnames(d[,7:ncol(d)]),las=2,tick=F)

#chisquare
plot(d[idx,1],d[idx,5],type="l",xlim=c(0,max(d[,1])),xaxs="i",lwd=2,xlab="informative SNPs",ylab="P-value",log="y",las=1)
abline(-2,0,lwd=0.5,col="red")
abline(-3,0,lwd=0.5,col="red")
abline(-4,0,lwd=0.5,col="red")
abline(-5,0,lwd=0.5,col="red")
abline(-6,0,lwd=0.5,col="red")
tmp <- d[idx,]
tmp <- tmp[tmp[,6]!='-',]
text(tmp[,1],tmp[,5],tmp[,6],col="red")
