#!/usr/bin/perl -w

my $count = 0;
foreach my $LCB_file (glob "/home/jesse/Vibrio_sequencing/vib25/LCBs/LCB.core.*.22.strains+12B01.12F01.outgr") {
    next if ($LCB_file =~ m/trimGaps/);
    my $trimmed = $LCB_file.".trimGaps.fa";
    `perl trimGaps.pl $LCB_file 0 > $trimmed`;
    print $LCB_file,"\n";
    $count++;
}
print "Trimmed ", $count, " LCBs\n";
