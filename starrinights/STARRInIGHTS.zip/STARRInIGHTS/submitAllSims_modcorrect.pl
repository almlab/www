#!/usr/bin/perl -w

use strict;

my $queue = $ARGV[0];
my $poly = $ARGV[1];
my $alpha = $ARGV[2];
my $strains = $ARGV[3];

my $glob = "*\.concat3\.fa";
if ($poly ne 'na') {
    $glob = "*_".$poly."_*\.concat3\.fa";
}
foreach my $contig (glob $glob) {
    my $subseqs = $contig;
    $subseqs =~ s/\.concat3\.fa/\.concat3\.1\.subseqs\.txt/;
    print join "\t", $contig,"\n";
    # make subseqs file
    `perl /home/jesse1/STARRI/2.0/make_subSeqList_modcorrect.pl $contig $strains > make_subSeqList.screenout`;
    # write multi-phylip file and submit jobs
    `perl /home/jesse1/STARRI/2.0/writePhy+submit.pl $subseqs $contig $strains $alpha 2 $queue 1e50 >> writePhy+submit.screenout`;
    `rm $contig`;
}
