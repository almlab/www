#!/usr/bin/perl -w

use strict;

my $contig_list = $ARGV[0]; # a file containing a list of all subseq files
my $breaks_dir = $ARGV[1]; # the directory containing the above
my $pB_init = $ARGV[2]; # the value of pBinit that results in the ML allocation of breakpoints, e.g. -13.82
my $mode = $ARGV[3]; # choose one of: STARRI.2.0.noEM, STARRI.2.0.EM, STARRI.correct.noEM, or STARRI.correct.EM

if ($breaks_dir !~ m/\/$/) {
    $breaks_dir .= "/";
}
my $pars_dir = $breaks_dir."dnapars.".$pB_init;
unless (-e $pars_dir) {
    `mkdir $pars_dir`;
}

my $sge_file = $pars_dir."/runDNApenny.sh";
if (-e $sge_file) {
    `rm $sge_file`;
}
open SGE, ">>$sge_file" || die "Can't open $sge_file\n";
print SGE "\#!/bin/bash\n";
print SGE "\#\$ -o /dev/null\n"; # write output to null so not to waste disk space                                                                                                 
print SGE "\#\$ -e /dev/null\n";
print SGE "cd $pars_dir\n";
print SGE "\#\$ -cwd\n";

# get info for contigs and breaks
my %lk_score;
my %poly_map; # map polymorphic sites to their actual genomic/contig position
my %n; # the total number of polymorphic sites in the contig
my $Nsingle = 0; # the total number of singletons across all contigs
my %seenContig;
my %physLen; # the total number of bp in the contig, including invar sites
my %subset;
my @species;
my @poly_sites;
my @dimo_sites;
my $n;

my %poly_variants; # the number of bases segregating at a site i
my %r; # store DIMORPHIC sites
my %dimorphic; # whether the site is dimorphic
my @singletons; # list of singletons sites
open CONT, $contig_list || die "Can't find $contig_list file\n";
while (<CONT>) {
    chomp;
    my ($contig, $physLen, $inform, $di, $tri, $quad, $nonInf, $lk_file, $map_file, $sge_file, $concat_file, $subset_file) = split "\t";
# read in parsimony scores for each subsequence ij
    next if (m/^cont/);
    unless (-e $lk_file) {
	print $lk_file, " does not exist!\n";
	exit;
    }
    open PARS, $lk_file || die "Can't find $lk_file\n";
    while (<PARS>) {
	my ($batch, $i, $j, $lk, $tree) = split "\t";
	$lk_score{$contig}{$i}{$j} = $lk;
    }
    close PARS;
}
close CONT;

my $tot_dbl = 0; # the total number of homoplasic mutations across all contigs
open CONT, $contig_list || die "Can't find $contig_list file\n";
while (<CONT>) {
    chomp;
    my ($contig, $physLen, $inform, $di, $tri, $quad, $nonInf, $lk_file, $map_file, $sge_file, $concat_file, $subset_file) = split "\t";
    next if (m/^cont/);
    my %polymorphic; # store polymorphic sites for the current contig
    unless (exists $seenContig{$contig}) {
	$physLen{$contig} = $physLen;
	print "contig ", $contig,"\n";
	unless (-e $map_file) {
	    print $map_file, " does not exist!\n";
	    exit;
	}
	open MAP, "$map_file" || die "Can't find $map_file\n";
	while (<MAP>) {
	    chomp;
	    next if (m/poly/);
	    my ($poly_pos, $cont_pos, $Nvariants) = split "\t";
	    $poly_map{$contig}{$poly_pos} = $cont_pos;
	    $n{$contig} = $poly_pos;
	}
	close MAP;
	
	my @DNAlines;
	open DNA, $concat_file || die "Could not open fasta file for $concat_file\n";
	while (<DNA>) {
	    push @DNAlines, $_;
	}
	close DNA;
	open FILE, $subset_file || die "Can't open infile $subset_file\n";
	while (<FILE>) {
	    chomp;
	    $subset{$_} = $_;
	}
	close FILE;
	my %DNA = readFasta(@DNAlines); # makes a hash of header:sequence
	@species = sort keys %DNA;
# puts sequences in a list to check their length
	my @sequences = values %DNA;
	my $size = length $sequences[0];
	foreach (@sequences) { # checks that all are same length
	    unless ((length $_) == $size) {
		my %reversed = reverse %DNA;
		print "This sequence is not the right length: $reversed{$_}\n";
	    }
	}
	@singletons = ();
# make new fasta, only including variable sites
	for (my $i=0; $i<$size; $i+=1) {	
	    delete $r{$i};
	    delete $dimorphic{$i};
	    my %unique_bases;
	    foreach my $species (@species) {
		my $base = substr($DNA{$species},$i,1);
		$unique_bases{$base} += 1;
	    }
	    # only retain polymorphic sites with 2 segregating bases
	    my $poly_variants = 0;
	    my $singleton = 0; # whether the site contains a singleton or not
	    my $non_sing = 0;
	    foreach my $base (keys %unique_bases) {
		if ($unique_bases{$base} == 1) { # singleton site!
		    $singleton++;
		}
		else {
		    $non_sing++;
		}
		$poly_variants++;
	    }
	    if ($non_sing >= 2) { # a potentially informative site, though it might also contain singletons
		if ($poly_variants >= 2) { # at least 2 alleles segregating
		    $poly_variants{$i} = $poly_variants;
		    foreach my $sp (@species) {
			my $base = substr($DNA{$sp},$i,1);
			$polymorphic{$i}{$sp} = $base;
		    }
		    if ($poly_variants == 2) { # exactly 2 alleles segregating => dimorphic site, to be considered in pre-filtering for perfectly parsimonious stretchs
			foreach my $sp (@species) {
			    my $base = substr($DNA{$sp},$i,1);
			    $r{$i}{$sp}{$contig} = $base;
			    $dimorphic{$i}{$contig} = $i;
			}
		    }
		}
	    }
	    elsif ($singleton >= 1) { 
		push @singletons, $i;
	    }
	}
	print "read poly sites\n";
	@poly_sites = sort numeric keys %polymorphic;
	@dimo_sites = sort numeric keys %r;
	$n = (@dimo_sites+0);

	# find breakpoint locations STARRI.1.5.EM.50.init.pB_-1.pM_-0.001.out
	my $break_file = $breaks_dir.$mode.".".$contig.".init.pB_".$pB_init.".out";
	print "break file = ", $break_file,"\n";
	my %blk_start;
	my %blk_end;
	my %blk_lk; # the lk score of this block
	my $blk_count=0;
	open BREAKFILE, "$break_file" || die "Can't find $break_file\n";
	while (<BREAKFILE>) {
	    chomp;
	    my @breaks = split;
	    @breaks = sort numeric @breaks;
	    my $last_break = 1;
            for (my $b=1; $b<(@breaks+0); $b++) {
                my $start_blk = $last_break;
		my $end_blk = ($breaks[$b]-1);
		my $lk_score = 'na';
		if (exists $lk_score{$contig}{$start_blk}{$end_blk}) {
		    $lk_score = $lk_score{$contig}{$start_blk}{$end_blk};
		}
		$blk_count++;
		$blk_start{$blk_count} = $start_blk;
		$blk_end{$blk_count} = $end_blk;
		$blk_lk{$blk_count} = $lk_score;
                $last_break = $breaks[$b];
		
		# run dnapenny
# get appropriate species names and lengths for phylip format
		my %sp_header;
		foreach my $sp (@species) {
		    my $Nchar = length($sp);
		    my $sp_header = $sp;
		    for (my $i=1; $i<=(10 - $Nchar); $i++) {
			$sp_header .= " ";
		    }
		    $sp_header{$sp} = $sp_header;
		}
		my $start = $start_blk;
		my $end = $end_blk;
		
		my $subseq_file = $pars_dir."/subseq.".$contig.".".$start."_".$end.".phy";
		open OUT, ">$subseq_file" || die "Can't open subseq file\n";
		print OUT "     ",(@species+0),"   ",($end-$start+1),"\n";
		foreach my $sp (@species) {
		    my $subseq = "";
		    for (my $site = ($start-1); $site <= ($end-1); $site++) {
#			print join "\t", $site, $poly_sites[$site], $sp, $contig,"\t";
			if (exists $polymorphic{$poly_sites[$site]}{$sp} ) {
			    $subseq .= $polymorphic{$poly_sites[$site]}{$sp};
#			    print "base=> ", $polymorphic{$poly_sites[$site]}{$sp};
			}
			else {
			    print "no base\n";
			}
		    }
		    print OUT $sp_header{$sp};
		    print OUT $subseq;
		    print OUT "\n";
		}
		print "written to ", $subseq_file,"\n";
# make dnacomp input file
		my $pars_infile = $pars_dir."/pars_infile.".$contig.".".$start."_".$end;
		open (PARS_IN, ">$pars_infile") || die "cannot open pars input tmp file\n";
		print PARS_IN $subseq_file,"\n","I","\n","4","\n","y","\n";
		close PARS_IN;
		my $dnapenny_out = $pars_dir."/dnacomp.".$contig.".".$start."_".$end;
		my $outfile = $pars_dir."/outfile.".$contig.".".$start."_".$end;
		my $outtree = $pars_dir."/outtree.".$contig.".".$start."_".$end;
# run dnacomp
		print SGE "/home/jesse1/STARRI/1.0/dnacomp < ", $pars_infile, " > ", $dnapenny_out,"\n";
		print SGE "mv outfile ",$outfile,"\n";
		print SGE "mv outtree ",$outtree,"\n";
	    }
	}
	print "done reading ", $break_file,"\n";
	close BREAKFILE;
	$seenContig{$contig} = 1;
    }
}

#returns a hash of sequence indexed by fasta headers
sub readFasta{
    my %fasta;
    my $line;
    my $length=0;
    my $header;

    for $line (@_){
        chomp $line;

        #find header lines
	if ($line =~ /^>(.+)/) {
            $header = $1;
#	    print $header,"\n";
            next;
        }

        #for non-header lines...
        if(defined($header)){
	    # only include species in the subset of interest
	    next unless (exists $subset{$header});
            #get rid of spaces
            $line =~ s/\s+//g;
            #append to the current sequence stored in %fasta
            $fasta{$header} .= $line;
        }
    }
    #return sequences indexed by headers
    return %fasta;
}

sub numeric {
    $a <=> $b;
}

sub diffs { # returns differences between 2 arrays
    my ($array1, $array2) = @_;
    my @array1 = @$array1;
    my @array2 = @$array2;
    my @union = my @intersection = my @difference = ();
    my %count = ();
    foreach my $element (@array1, @array2) {
	$count{$element}++;
    }
    foreach my $element (keys %count) {
	push @union, $element;
	push @{ $count{$element} > 1 ? \@intersection : \@difference }, $element;
    }
    return \@difference;
}

sub intersect { # returns the intersection between 2 arrays                                                                                                                                                     
    my ($array1, $array2) = @_;
    my @array1 = @$array1;
    my @array2 = @$array2;
    my @union = my @intersection = my @difference = ();
    my %count = ();
    foreach my $element (@array1, @array2) {
        $count{$element}++;
    }
    foreach my $element (keys %count) {
        push @union, $element;
        push @{ $count{$element} > 1 ? \@intersection : \@difference }, $element;
    }
    return \@intersection;
}
