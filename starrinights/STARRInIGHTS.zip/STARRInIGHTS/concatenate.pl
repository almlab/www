#!/usr/bin/perl -w

use strict;
my $order_file = $ARGV[0]; # a file containing the screenoutput of orderLCBs.pl

my %comp = ("A" => "T", "T" => "A", "C" => "G", "G" => "C");

my %gene_pos;
open ORDER, $order_file;
my %contig_count;
my %strand;
my %start;
my %end;
while (<ORDER>) {
    chomp;
    next if (m/contig/);
    my ($contig, $start, $end, $coverage, $LCB, $length, $strand) = split "\t";
    $contig_count{$contig}++;
    $gene_pos{$contig}{ $contig_count{$contig} } = $LCB;
    $strand{$LCB}{$contig} = $strand;
    $start{$LCB}{$contig} = $start;
    $end{$LCB}{$contig} = $end;
}
close ORDER;

my $keyfile = "concat.".$order_file.".key.out";
open OUT, ">>$keyfile";
print OUT join "\t", "LCB", "contig", "start", "end", "refStart", "refEnd", "strand";
print OUT "\n";
close OUT;

my $totLen = 0;
my %concat;
my $concatLen = 0;
my $contigfile = "contig.".$order_file.".concat.fa";
open CONTIG, ">$contigfile" || die "Can't open contig file: $contigfile\n";
foreach my $contig (sort numeric keys %contig_count) {
    foreach my $order (sort numeric keys %{ $gene_pos{$contig} }) {
	my $LCB = $gene_pos{$contig}{$order};
	my $strand = $strand{$LCB}{$contig};
	my $DNAfile = "/home/jesse/Vibrio_sequencing/vib25/LCBs/LCB.core.".$LCB.".22.strains+12B01.12F01.outgr.trimGaps.fa";
	my @DNAlines; # define array for lines of MSA
	open DNA, "< $DNAfile" || die "Could not open DNA sequence file $DNAfile\n";
	while (<DNA>) { # reads FASTA file into an array 
	    push @DNAlines, $_;
	}
	close DNA;
	my %DNA = readFasta(@DNAlines); # makes a hash of header:sequence
	my @species = sort keys %DNA;
	
# puts sequences in a list to check their length
	my @sequences = values %DNA;
	my $size = length $sequences[0];
#    print "Sequence length: $size\n";
	foreach (@sequences) { # checks that all are same length
	    unless ((length $_) == $size) {
		my %reversed = reverse %DNA;
		print "This sequence is not the right length: $reversed{$_}\n";
	    }
	}
	# Add to concat sequence, update key
	foreach my $species (@species) {
	    if ( $strand >= 0.5) {
		$concat{$species} .= $DNA{$species};
	    }
	    else {
		$concat{$species} .= revcomp($DNA{$species});
	    }
	}
	open OUT, ">>$keyfile";
	print OUT join "\t", $LCB, $contig, $concatLen;
	$concatLen += $size;
	print OUT "\t", $concatLen,"\t", $start{$LCB}{$contig}, "\t", $end{$LCB}{$contig}, "\t", $strand,"\n";
#	$concatLen += 1;
    }
}
# puts sequences in a list to check their length AGAIN                                                                                                                                     
my @sequences_concat = values %concat;
my $size = length $sequences_concat[0];
print "Sequence length: $size\n";
$totLen += $size;
foreach (@sequences_concat) { # checks that all are same length                                                                                                                                   
    unless ((length $_) == $size) {
	my %reversed = reverse %concat;
	print "This sequence is not the right length: $reversed{$_}\tLength= ", length $_,"\n";
    }
}
# print concat fasta                                                                                                                                                                       
foreach my $seq (sort keys %concat) {
    print CONTIG ">".$seq,"\n";
    print CONTIG $concat{$seq},"\n";
}
close OUT;

print "\n", "Total length: ", $totLen, " bp\n";

sub numeric {
    $a<=>$b;
}

#returns a hash of sequence indexed by fasta headers
sub readFasta{
    my %fasta;
    my $line;
    my $length=0;
    my $header;

    for $line (@_){
        chomp $line;
	next if ($line =~ m/^Sequence/);
	next if ($line =~ m/^msa/);
        #find header lines
	if ($line =~ /^>(.+)/) {
            $header = $1;
#	    print $header,"\n";
            next;
        }

        #for non-header lines...
        if(defined($header)){
            #get rid of spaces
            $line =~ s/\s+//g;
	    $line =~ s/a/A/g;
	    $line =~ s/t/T/g;
	    $line =~ s/c/C/g;
	    $line =~ s/g/G/g;
            #append to the current sequence stored in %fasta
            $fasta{$header} .= $line;
        }
    }
    #return sequences indexed by headers
    return %fasta;
}

sub revcomp{
    my $seq = "";
    my $rev = "";
    for my $string (@_) {
	chomp $string;
	$seq .= $string;
    }
#    print "seq ",$seq,"\n";
    my $length = 0;
    for (my $i=(length($seq)-1); $i >= 0; $i-=1) {
	$length++;
	my $base = substr($seq,$i,1);
	if ($base eq 'a') {
	    $base = 'A';
	}
	if ($base eq 'g') {
	    $base = 'G';
	}
	if ($base eq 't') {
	    $base = 'T';
	}
	if ($base eq 'c') {
	    $base = 'C';
	}
	my $comp = $comp{$base};
#	print $comp,"\n";
	$rev .= $comp;
    }
    return $rev;
}
