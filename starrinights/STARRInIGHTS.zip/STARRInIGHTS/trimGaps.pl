#!/usr/bin/perl -w

use strict;

my $DNAfile = $ARGV[0]; # take command-line argument (.fa file)
my $trim_fraction = $ARGV[1]; # proportion of sequences containing a gap that are allowed. If more than this proportion have gaps, trim the position!
my @DNAlines; # define array for lines of .fa

open DNA, "< $DNAfile" || die "Could not open DNA sequence file\n";
while (<DNA>) { # reads FASTA file into an array 
    push @DNAlines, $_;
}
close DNA;

my %DNA = readFasta(@DNAlines); # makes a hash of header:sequence
my @species = keys %DNA;

# puts sequences in a list to check their length
my @sequences = values %DNA;
my $size = length $sequences[0];
print "Sequence length: $size\n";
foreach (@sequences) { # checks that all are same length
    unless ((length $_) == $size) {
	my %reversed = reverse %DNA;
	print "This sequence is not the right length: $reversed{$_}\n";
    }
}

my %trim; # sites not to include because they are a gap or non ATCG character
my $n_species = (@species+0);
# sequence that iterates over each base, marking non-ACGT
foreach my $species (@species) {
    for (my $i=0; $i < $size; $i++) { # should be < $size
	my $base = substr($DNA{$species},$i,1);
	if ($base =~ m/[\-]/) { # gap!
	    $trim{$i}++;
	}
	if ($base =~ m/N/) { # gap!
	    $trim{$i}++;
	}
#	print $base;
    }
#    print "\n";
}

# print trimmed MSA
my $count = 0;
foreach my $species (@species) {
    my $header = ">".$species;
    $header =~ s/\_//g;
    print $header,"\n";
    $count=0;
    for (my $i=0; $i < $size; $i++) { # should be < $size
	my $fraction_ungapped = 1;
	if (exists $trim{$i}) {
	    $fraction_ungapped = ($trim{$i}/$n_species);
	}
	my $base = substr($DNA{$species},$i,1);
	if (exists $trim{$i} && $fraction_ungapped > $trim_fraction) {
#	    print "trimmed\t",$base,"\n";;
	}
	else {
	    print $base;
	    $count++;
	}
    }
    print "\n";
#    print "count= ", $count,"\n";
}
print "msa length = ", $count,"\n";
exit;

# Code below should only be used if you want to print out a tab-delim summary mapping which sites were trimmed

my $untrim_count = 0;
my $trim_count = 0;

# maps untrimmed to trimmed 12B01 positions
for (my $i=0; $i < $size; $i++) { # should be < $size
    my $fraction_ungapped = 1;
    if (exists $trim{$i}) {
	$fraction_ungapped = ($trim{$i}/$n_species);
    }
#    my $base = substr($DNA{"PN73"},$i,1); # base for the reference sequence
    my $base = substr($DNA{"PN73"},$i,1); # base for the reference sequence
    if ($base !~ m/[\-]/) { # not a gap
#    if ($base =~ m/[ACGT]/) {
	$untrim_count++;
	print $untrim_count,"\t";
	if (exists $trim{$i} && $fraction_ungapped > $trim_fraction) {
	    print "trimmed\t",$base,"\n";;
	}
	else {
	    $trim_count++;
	    print $trim_count,"\t",$base,"\n";
	}
    }
    else {
	if (exists $trim{$i} && $fraction_ungapped > $trim_fraction) {
	}
	else {
	    $trim_count++;
	    print "indel","\t",$trim_count,"\t",$base,"\n";
	}
    }
}


#returns a hash of sequence indexed by fasta headers
sub readFasta{
    my %fasta;
    my $line;
    my $length=0;
    my $header;

    for $line (@_){
        chomp $line;

        #find header lines
        if($line =~ /^>(.+)/){
            $header = $1;
            next;
        }

        #for non-header lines...
        if(defined($header)){
            #get rid of spaces
	    $line =~ s/\./\-/g;
            $line =~ s/\s+//g;
            #append to the current sequence stored in %fasta
            $fasta{$header} .= $line;
        }
    }
    #return sequences indexed by headers
    return %fasta;
}
