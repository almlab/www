#!/usr/bin/perl -w

use strict;

my $subseq_file = $ARGV[0]; # the output from make_subSeqList.pl, e.g. contig.60.concat3.1001.subseqs.txt
my $fasta = $ARGV[1]; # the fasta file input
my $subset = $ARGV[2]; # subset of species in the fasta file to include
my $alpha = $ARGV[3]; # the gammadistr shape param, estimated by ML using bootAlpha.pl
my $Ncat = $ARGV[4]; # the number of discrete gamma-distributed rate categories
my $queue = $ARGV[5]; # choose between long (48h), short (12h), quick (3h) or speedy (30min)
my $maxTrees = $ARGV[6]; # the maximum number of trees per node

#print start time
print "Start time:\n";
my @Month_name = ( "January", "February", "March", "April", "May", "June",
		   "July", "August", "September", "October", "November", "December" );
my ( $sec, $min, $hour, $day, $month, $year ) = ( localtime ) [ 0, 1, 2, 3, 4, 5 ];
printf  "%02d:%02d:%02d %02d %s %04d\n", 
    $hour, $min, $sec, $day, $Month_name[$month], $year+1900 ;
print "\n\n";

my @DNAlines;
open DNA, $fasta || die "Could not open fasta file for $fasta\n";
while (<DNA>) {
    push @DNAlines, $_;
}
close DNA;

my %subset;
open FILE, $subset || die "Can't open infile $subset\n";
while (<FILE>) {
    chomp;
    $subset{$_} = $_;
}
close FILE;

my %DNA = readFasta(@DNAlines); # makes a hash of header:sequence
my @species = sort keys %DNA;
# puts sequences in a list to check their length
my @sequences = values %DNA;
my $size = length $sequences[0];
foreach (@sequences) { # checks that all are same length
    unless ((length $_) == $size) {
	my %reversed = reverse %DNA;
	print "This sequence is not the right length: $reversed{$_}\n";
    }
}

# make new fasta, only including variable sites
my %polymorphic; # store polymorphic sites
my $poly_count = 0;
for (my $i=0; $i<$size; $i+=1) {	
    my %unique_bases;
    foreach my $species (@species) {
	my $base = substr($DNA{$species},$i,1);
	$unique_bases{$base} += 1;
    }
    # only retain polymorphic sites with 2 segregating bases
    my $poly_variants = 0;
    my $singleton = 0; # how many unique singleton bases at a site
    my $non_sing = 0; # how many segregating bases at a site are not singletons (eg informative sites)
    foreach my $base (keys %unique_bases) {
	if ($unique_bases{$base} == 1) { # singleton site!
	    $singleton++;
	}
	else {
	    $non_sing++;
	}
	$poly_variants++;
    }
    if ($non_sing >= 2) { # a potentially informative site, though it might also contain singletons
	if ($poly_variants >= 2) { # at least 2 alleles segregating
	    $poly_count++;
	    foreach my $sp (@species) {
		my $base = substr($DNA{$sp},$i,1);
		$polymorphic{$i}{$sp} = $base;
	    }
	}
    }
}
my @poly_sites = sort numeric keys %polymorphic;
my $last_poly_site = $#poly_sites;
#print "last poly index= ", $last_poly_site,"\n";
# print out mapping of polymorphic sites to the actual physical sequence (including invariant sites)

# get appropriate species names and lengths for phylip format
my %sp_header;
foreach my $sp (@species) {
    my $Nchar = length($sp);
    my $sp_header = $sp;
    for (my $i=1; $i<=(10 - $Nchar); $i++) {
	$sp_header .= " ";
    }
    $sp_header{$sp} = $sp_header;
}

my $curr_dir = `pwd`;

# write sh files
open SUBSEQS, "$subseq_file" || die;
my $last_sub_batch = 0;
my $treesPerJob = 0;
while (<SUBSEQS>) {
    chomp;
    my ($curr_batch, $start, $end) = split "\t";
    $treesPerJob++;
    if ( $treesPerJob == $maxTrees) {

	print "trees per job ", $last_sub_batch, " = ", $treesPerJob,"\n";
	my $log_file = $subseq_file;
	$log_file =~ s/subseqs\.txt//;
	$log_file .= $last_sub_batch.".log";
	
	my $sh_file = $subseq_file;
	$sh_file =~ s/subseqs\.txt//;
	$sh_file .= $last_sub_batch.".sh";

	my $phy_file = $subseq_file;
	$phy_file =~ s/subseqs\.txt//;
	$phy_file .= $last_sub_batch.".phy";
	open SH, ">$sh_file" || die;
	print SH "\#!/bin/bash\n";
	print SH "cd $curr_dir\n";
	print SH "\#\$ -cwd\n";
	print SH "date >> $log_file\n";
	print SH "/home/jesse1/src/phyml $phy_file 0 i $treesPerJob 0 JC69 e 0 $Ncat $alpha BIONJ y y > phyml.tmp.screenout\n";
	my $site_lk_file = $phy_file."_phyml_lk.txt";
#	print SH "rm $site_lk_file\n";
	print SH "rm $phy_file\n";
	print SH "date >> $log_file\n";
	$last_sub_batch++;
	$treesPerJob = 0;
    }
}
close SUBSEQS;

# last sh file
if ($treesPerJob > 0) { # some jobs still remain
    print "trees per job ", $last_sub_batch, " = ", $treesPerJob,"\n";
    my $log_file = $subseq_file;
    $log_file =~ s/subseqs\.txt//;
    $log_file .= $last_sub_batch.".log";
    
    my $sh_file = $subseq_file;
    $sh_file =~ s/subseqs\.txt//;
    $sh_file .= $last_sub_batch.".sh";
    
    my $phy_file = $subseq_file;
    $phy_file =~ s/subseqs\.txt//;
    $phy_file .= $last_sub_batch.".phy";
    open SH, ">$sh_file" || die;
    print SH "\#!/bin/bash\n";
    print SH "date >> $log_file\n";
    print SH "cd $curr_dir\n";
    print SH "\#\$ -cwd\n";
    print SH "/home/jesse1/src/phyml $phy_file 0 i $treesPerJob 0 JC69 e 0 $Ncat $alpha BIONJ y y > phyml.tmp.screenout\n";
    my $site_lk_file = $phy_file."_phyml_lk.txt";
#    print SH "rm $site_lk_file\n";
    print SH "rm $phy_file\n";
    print SH "date >> $log_file\n";
    close SH;
}

# write multi-phylip sequence files
open SUBSEQS, "$subseq_file" || die;
$last_sub_batch = 0;
$treesPerJob = 0;
my $last_start = 0;
my $last_end = 0;
while (<SUBSEQS>) {
    chomp;
    my ($curr_batch, $start, $end) = split "\t";
    $treesPerJob++;
    $last_start = $start;
    $last_end = $end;

    my $i = $start - 1;
    my $j = $end - 1;
    my $downstream_include = 0;
    if ($i == 0) { # if it's the very first informative site, include all upstream non-inform. sites
	$downstream_include = 0;
    }
    else {
	$downstream_include = $poly_sites[$i-1] + 1; # start at the first non-informative site AFTER the LAST informative site
    }
    my $upstream_include = $poly_sites[$j];
    if ($j == $last_poly_site) {
	$upstream_include = ($size-1);
    }
    my $true_length = $upstream_include - $downstream_include + 1;
#    print join "\t", $i, $j, $downstream_include, $upstream_include, "(size=", $size;
#    print "\n";
    my $phy_file = $subseq_file;
    $phy_file =~ s/subseqs\.txt//;
    $phy_file .= $last_sub_batch.".phy";
    open PHY, ">>$phy_file" || die;
    print PHY "     ",(@species+0),"   ",$true_length,"\n";
    # write in interleave blocks of sequence (60 bp perline)
    my $block_start = 0;
    while ($block_start < ($true_length-60) ) {
	if ($block_start == 0) { # first block
	    foreach my $sp (@species) {		    
		print PHY $sp_header{$sp};
		print PHY substr($DNA{$sp}, ($downstream_include+$block_start),60);
		print PHY "\n";
	    }		    
	}
	else { # subsequent blocks
	    foreach my $sp (@species) {		    
		print PHY "          ";
		print PHY substr($DNA{$sp}, ($downstream_include+$block_start),60);
		print PHY "\n";
	    }
	}
	print PHY "\n";
	$block_start += 60;
    }
    # print last block of sequence
    my $remainder = $true_length - $block_start;
    if ($block_start == 0) { # first block
	foreach my $sp (@species) {		    
	    print PHY $sp_header{$sp};
	    print PHY substr($DNA{$sp}, ($downstream_include+$block_start),$remainder);
	    print PHY "\n";
	}		    
    }
    else { # subsequent blocks
	foreach my $sp (@species) {		    
	    print PHY "          ";
	    print PHY substr($DNA{$sp}, ($downstream_include+$block_start),$remainder);
	    print PHY "\n";
	}
    }
    print PHY "\n";
    if ( $treesPerJob == $maxTrees) {
	close PHY;
	# wait to make sure no more than 10 jobs are already running
	my $line = `qstat | grep "jesse1" | wc`; # replace jesse1 with your username
	my $Nrunning = 0;
	if ($line =~ m/\s+([\d]+)\s+/) {
	    $Nrunning = $1;
	}
	while ($Nrunning > 15) {
	    sleep 300; # wait 5 minutes before checking again
	    $line = `qstat | grep "jesse1" | wc`;    
	    if ($line =~ m/\s+([\d]+)\s+/) {
		$Nrunning = $1;
	    }
	    else {
		$Nrunning = 0;
	    }
	}
	# submit the last batch:
	my $last_sh = $subseq_file;
	$last_sh =~ s/subseqs\.txt//;
	$last_sh .= $last_sub_batch.".sh";
	`qsub -q $queue $last_sh`;
	print "sub cmd: qsub -q $queue $last_sh\n";
	print "sub'd $last_sh\tStart= ", $start,", End= ", $end,"\n";
	$last_sub_batch++;
	$treesPerJob = 0;
	# cleanup any lk files (these are large files produced by phyml, but we don't need them!)
	my $lk_count = 0;
	foreach my $lk_file (glob "*_phyml_lk.txt") {
	    $lk_count++;
	}
	if ($lk_count > 0) {
	    `rm *_phyml_lk.txt`;
	}
    }
}

# submit the last batch:
if ($treesPerJob > 0) { # some jobs still remain
    # wait to make sure no more than 10 jobs are already running
    my $line = `qstat | grep "jesse1" | wc`; # replace jesse1 with your username
    my $Nrunning = 0;
    if ($line =~ m/\s+([\d]+)\s+/) {
	$Nrunning = $1;
    }
    while ($Nrunning > 15) {
	sleep 300; # wait 5 minutes before checking again
	$line = `qstat | grep "jesse1" | wc`;    
	if ($line =~ m/\s+([\d]+)\s+/) {
	    $Nrunning = $1;
	}
	else {
	    $Nrunning = 0;
	}
    }
    my $last_sh = $subseq_file;
    $last_sh =~ s/subseqs\.txt//;
    $last_sh .= $last_sub_batch.".sh";
    `qsub -q $queue $last_sh`;
    print "sub'd $last_sh\tStart= ", $last_start,", End= ", $last_end,"\n";
    # cleanup any lk files (these are large files produced by phyml, but we don't need them!)
    my $lk_count = 0;
    foreach my $lk_file (glob "*_phyml_lk.txt") {
	$lk_count++;
    }
    if ($lk_count > 0) {
	`rm *_phyml_lk.txt`;
    }
}

print "\n";
#print stop time
print "Finish time:\n";
( $sec, $min, $hour, $day, $month, $year ) = ( localtime ) [ 0, 1, 2, 3, 4, 5 ];
printf  "%02d:%02d:%02d %02d %s %04d\n", 
    $hour, $min, $sec, $day, $Month_name[$month], $year+1900 ;

#returns a hash of sequence indexed by fasta headers
sub readFasta{
    my %fasta;
    my $line;
    my $length=0;
    my $header;

    for $line (@_){
        chomp $line;

        #find header lines
	if ($line =~ /^>(.+)/) {
            $header = $1;
#	    print $header,"\n";
            next;
        }

        #for non-header lines...
        if(defined($header)){
	    # only include species in the subset of interest
	    next unless (exists $subset{$header});
            #get rid of spaces
            $line =~ s/\s+//g;
            #append to the current sequence stored in %fasta
            $fasta{$header} .= $line;
        }
    }
    #return sequences indexed by headers
    return %fasta;
}

sub numeric {
    $a <=> $b;
}
