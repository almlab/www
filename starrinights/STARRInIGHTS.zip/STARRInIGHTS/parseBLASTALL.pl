#!/usr/bin/perl -w

use strict;

my $blast_out = $ARGV[0]; # the m8-formatted output of blast

open BLAST, $blast_out || die "Can't find blastall output file\n";

my %maxLen;
my %contig; # the contig an LCB is on
my %start;
my %end;
my %line;
while (<BLAST>) {
    chomp;
    my ($query,$hit,$identity,$length,$mismatches,$gaps,$queryStart,$queryEnd,$hitStart,$hitEnd,$E,$bitscore) = split;
    if (! exists $maxLen{$query}) {
	$maxLen{$query} = $length;
	$contig{$query} = $hit;
	$start{$query} = $hitStart;
	$end{$query} = $hitEnd;
	$line{$query} = $_;
    }
    elsif ( $length > $maxLen{$query} ) {
	$maxLen{$query} = $length;
	$contig{$query} = $hit;
	$start{$query} = $hitStart;
	$end{$query} = $hitEnd;
	$line{$query} = $_;
    }
}
close BLAST;

my $outfile = $blast_out;
$outfile =~ s/\.out/\.bestHit\.out/;
open OUT, ">$outfile" || die;

foreach my $query (sort keys %maxLen) {
    if (exists $line{$query}) {
	print OUT $line{$query},"\n";
    }
    else {
#	print $query,"\n";
    }
    if ($start{$query} < $end{$query} ) {
	print join "\t", $query, $contig{$query}, $start{$query}, $end{$query}, "+";
    }
    else {
	print join "\t", $query, $contig{$query}, $end{$query}, $start{$query}, "-";
    }
    print "\n";
}
