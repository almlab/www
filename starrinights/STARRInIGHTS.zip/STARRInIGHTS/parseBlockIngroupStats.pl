#!/usr/bin/perl -w

use strict;

my $contig_list = $ARGV[0]; # a file containing a list of all subseq files
my $breaks_dir = $ARGV[1]; # the directory containing the above
my $pB_init = $ARGV[2]; # the value of pBinit that results in the ML allocation of breakpoints, e.g. -13.82
my $mode = $ARGV[3]; # choose one of: STARRI.2.0.noEM, STARRI.2.0.EM, STARRI.correct.noEM, or STARRI.correct.EM
my $common_splits = $ARGV[4]; # the output from parseBlockParsTrees.pl
my $ingr_file = $ARGV[5]; # a list of ingroup strains
my $outgr_file = $ARGV[6]; # a list of outgroup strains

my $tree_file = "trees.pB_".$pB_init."+stats.ingr.".$ingr_file.".txt";
open TREE, ">$tree_file" || die;
print TREE join "\t", "contig", "blk", "start", "end", "Nsnp_pars", "Nsnp_incons", "splitSup", "splitRej", "domGrp", "domFrac", "parsTree", "Nintree", "inconsTree", "Nincons", "NsegSite", "kHat", "tajD", "div", "Fst";
print TREE "\n";

# place to put all output files
if ($breaks_dir !~ m/\/$/) {
    $breaks_dir .= "/";
}
my $out_dir = $breaks_dir."output.pB_".$pB_init; 
unless (-e $out_dir) {
    `mkdir $out_dir`;
}

my @ingr; # list of ingroup species
my $ingr_str; # string of ingroup species
my @outgr; # list of outgroup species
my $outgr_str; # string of outgroup species
my %subset; # all strains to be included = ingr + outgr strains
open INGR, $ingr_file || die;
while (<INGR>) {
    chomp;
    push @ingr, $_;
    $subset{$_} = 1;
}
close INGR;
foreach my $sp (sort @ingr) {
    $ingr_str .= $sp.".";
}

open OUTGR, $outgr_file || die;
while (<OUTGR>) {
    chomp;
    push @outgr, $_;
    $subset{$_} = 1;
}
close OUTGR;
foreach my $sp (sort @outgr) {
    $outgr_str .= $sp.".";
}

my %instances; # the number of total times a grouping is seen                                                                                                                              
open COMMON, $common_splits || die;
while (<COMMON>) {
    chomp;
    next if (m/^group/); # header                                                                                                                                                          
    my ($sites_supporting, $group) = split "\t";
    $instances{$group} = $sites_supporting;
}
close COMMON;

my $pars_dir = $breaks_dir."dnapars.".$pB_init;

# get info for contigs and breaks
my %poly_map; # map polymorphic sites to their actual genomic/contig position
my %rev_map;
my %n; # the total number of polymorphic sites in the contig
my $Nsingle = 0; # the total number of singletons across all contigs
my %seenContig;
my %physLen; # the total number of bp in the contig, including invar sites
my @species;
my @poly_sites;
my @dimo_sites;
my $n;
my %split;
my %poly_variants; # the number of bases segregating at a site i
my %r; # store DIMORPHIC sites
my %dimorphic; # whether the site is dimorphic
my $poly_count = 0;
my @singletons; # list of singletons sites

my %incons_tot; # inconsistencies, summed over all sites & contigs
my %splits_tot; # legitimate splits in the parsimony tree of the block
my %bipart_tot; # both
my $most_popular_split = 0;
open CONT, $contig_list || die "Can't find $contig_list file\n";
print "reading contig info...\n";
while (<CONT>) {
    chomp;
    my ($contig, $physLen, $inform, $di, $tri, $quad, $nonInf, $lk_file, $map_file, $sge_file, $concat_file, $subset_file) = split "\t";
    next if (m/^cont/);
    my %polymorphic; # store polymorphic sites for the current contig
    unless (exists $seenContig{$contig}) {
	print "contig ", $contig,"\n";
	$seenContig{$contig} = 1;
	$physLen{$contig} = $physLen;
	unless (-e $map_file) {
	    print $map_file, " does not exist!\n";
	    exit;
	}
	open MAP, "$map_file" || die "Can't find $map_file\n";
	while (<MAP>) {
	    chomp;
	    next if (m/poly/);
	    my ($poly_pos, $cont_pos, $Nvariant) = split "\t";
	    $poly_map{$contig}{$poly_pos} = $cont_pos;
#	    $rev_map{$contig}{$cont_pos} = $poly_pos;
	    $n{$contig} = $poly_pos;
	}
	close MAP;
	
	my @DNAlines;
	open DNA, $concat_file || die "Could not open fasta file for $concat_file\n";
	while (<DNA>) {
	    push @DNAlines, $_;
	}
	close DNA;

	my %DNA = readFasta(@DNAlines); # makes a hash of header:sequence
	@species = sort keys %DNA;
# puts sequences in a list to check their length
	my @sequences = values %DNA;
	my $size = length $sequences[0];
	foreach (@sequences) { # checks that all are same length
	    unless ((length $_) == $size) {
		my %reversed = reverse %DNA;
		print "This sequence is not the right length: $reversed{$_}\n";
	    }
	}
	@singletons = ();
# make new fasta, only including variable sites
	for (my $i=0; $i<$size; $i+=1) {	
	    delete $r{$i};
	    delete $dimorphic{$i};
	    my %unique_bases;
	    foreach my $species (@species) {
		my $base = substr($DNA{$species},$i,1);
		$unique_bases{$base} += 1;
	    }
	    # only retain polymorphic sites with 2 segregating bases
	    my $poly_variants = 0;
	    my $singleton = 0; # whether the site contains a singleton or not
	    my $non_sing = 0;
	    foreach my $base (keys %unique_bases) {
		if ($unique_bases{$base} == 1) { # singleton site!
		    $singleton++;
		}
		else {
		    $non_sing++;
		}
		$poly_variants++;
	    }
	    if ($non_sing >= 2) { # a potentially informative site, though it might also contain singletons
		if ($poly_variants >= 2) { # at least 2 alleles segregating
		    $poly_count++;
		    $poly_variants{$i} = $poly_variants;
		    foreach my $sp (@species) {
			my $base = substr($DNA{$sp},$i,1);
			$polymorphic{$i}{$sp} = $base;
#			print join "\t", "poly: ", $i, $sp, $contig, $base,"\n";
		    }
		    if ($poly_variants == 2) { # exactly 2 alleles segregating => dimorphic site, to be considered in pre-filtering for perfectly parsimonious stretchs
			foreach my $sp (@species) {
			    my $base = substr($DNA{$sp},$i,1);
			    $r{$i}{$sp}{$contig} = $base;
			    $dimorphic{$i}{$contig} = $i;
			}
		    }
		}
	    }
	    elsif ($singleton >= 1) { 
		push @singletons, $i;
	    }
	}
	@poly_sites = sort numeric keys %polymorphic;
	@dimo_sites = sort numeric keys %r;
	$n = (@dimo_sites+0);
	print "polymorphic sites= ", $n{$contig},"\n";	

	%split = getSplit($contig,0,$n); # contains 2 non-overlapping arrays specifying the bipartition for site j
	# find breakpoint locations STARRI.1.5.EM.50.init.pB_-1.pM_-0.001.out
	my $break_file = $breaks_dir.$mode.".".$contig.".init.pB_".$pB_init.".out";
	print "reading breakpoint file: ", $break_file,"\n";
	my %blk_start;
	my %blk_end;
	my $blk_count=0;
	my %Nmuts; # how many changes required at this site?
	my %Nincompat; # is the site incompatible?
	my %DNA_blk; # fasta of the current block
	open BREAKFILE, "$break_file" || die "Can't find $break_file\n";
	while (<BREAKFILE>) {
	    chomp;
	    my @breaks = split;
	    @breaks = sort numeric @breaks;
	    my $last_break = 1;
            for (my $b=1; $b<(@breaks+0); $b++) {
                my $start_blk = $last_break;
		my $end_blk = ($breaks[$b]-1);

		$blk_count++;
		$blk_start{$blk_count} = $start_blk;
		$blk_end{$blk_count} = $end_blk;
                $last_break = $breaks[$b];
		my %sp_header;
		foreach my $sp (@species) {
		    my $Nchar = length($sp);
		    my $sp_header = $sp;
		    for (my $i=1; $i<=(10 - $Nchar); $i++) {
			$sp_header .= " ";
		    }
		    $sp_header{$sp} = $sp_header;
		}
		my $start = $start_blk;
		my $end = $end_blk;		
		my $subseq_file = $pars_dir."/subseq.".$contig.".".$start."_".$end.".phy";
		my $dnapenny_out = $pars_dir."/dnacomp.".$contig.".".$start."_".$end;
		my $outfile = $pars_dir."/outfile.".$contig.".".$start."_".$end;
		my $outtree = $pars_dir."/outtree.".$contig.".".$start."_".$end;
		
		# read in alignment for just this block
		open PHY, $subseq_file || die;
		while (<PHY>) {
		    chomp;
		    next unless (m/[ATGC]+/);
		    my ($sp, $seq) = split;
		    $DNA_blk{$blk_count}{$sp} = $seq;
		}
		close PHY;

# extract Nmuts, Ncompat, Nincompat from pars outfile
		open PARS, "$outfile" || die "Can't find dnacomp $outfile\n";
		my $Ncompat = 0; # number of compatible sites
		my $Nmuts = 0; # total number of mutations required in the block
		my $Nincompat = 0; # total number of double-mutation events
		my $read_steps = 0;
		my $read_compat = 0;
		my $done = 0;
		my $site_count1 = 0;
		my $site_count2 = 0;
		while (<PARS>) {
		    chomp;
		    if (m/^From/) {
			$done = 1;
			$read_steps = 0;
			$read_compat = 0;
			last;
		    }
		    last if ($done == 1);
		    if (m/total number of compatible sites is[\s]+([\d\.]+)/) {
			$Ncompat = $1;
		    }
		    if (m/\*\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-\-$/) {
			$read_steps = 1;
			$site_count1 = 0;
		    }
		    if ($read_steps == 1) {
			if (m/\|\s+([\s\d]+)$/) {
			    for (my $i=0; $i<=(length($1)); $i++) {
				my $mut =  (substr($1,$i,1));
				if ($mut =~ m/[\d]+/) {
				    $Nmuts += $mut;
				    $site_count1++;
				    $Nmuts{$blk_count}{$site_count1} = $mut;
				}
			    }
			}
		    }
		    if (m/compatibility \(Y or N\) of each site with this tree\:/) {
			$read_steps = 0;
			$site_count2 = 0;
		    }
		    if (m/\*\-\-\-\-\-\-\-\-\-\-$/) {
			$read_compat = 1;
		    }
		    if ($read_compat == 1) {
			if (m/total number of compatible sites is[\s]+([\d\.]+)/) {
			    $read_compat = 0;
			    last;
			}
			elsif (m/[\d]+[\s]+\![\s]*([YN]+)/) {
			    for (my $site=0; $site<=(length $1); $site++) {
				my $inc = 0;
				if (substr($1, $site, 1) eq 'N') {
				    $Nincompat++;
				    $site_count2++;
				    $inc = 1;
				}
				elsif(substr($1, $site, 1) eq 'Y') {
				    $site_count2++;
				    $inc = 0;
				}
				$Nincompat{$blk_count}{$site_count2} = $inc;
			    }
			}
		    }
		}
		close PARS;		
	    }
	}
	close BREAKFILE;

	my $rep = 0;
	my $tree= $contig;
	if ($contig =~ m/tree([\d]+)r([\d]+)/) {
	    $tree = $1;
	    $rep = $2;
	}
	elsif ($contig =~ m/tree([\d]+)/) {
	    $tree = $1;
	}
	my $break_plot_file = $contig.".break.plot.txt";
	open PLOT, ">$break_plot_file" || die "Cant find $break_plot_file\n";
	my $mutrate_file = $breaks_dir.$mode.".".$contig.".init.pB_".$pB_init.".blocks.out";	
	open MUTRATE, "$mutrate_file" || die "Can't open $mutrate_file\n";
	print "writing breakpoint locations to file: ", $break_plot_file,"\n";
	my $curr_block = 0;
	my %physStart;
	my %physEnd;
	my $last_end = 0;
	while (<MUTRATE>) {
	    chomp;
	    my ($start_block, $end_block, $poly_map_start, $poly_map_end, $L) = split "\t";
	    $curr_block++;
	    $physStart{$curr_block} = $last_end + 1;
	    $physEnd{$curr_block} = $poly_map_end;
	    $last_end = $poly_map_end;
	    next if ($curr_block >= $blk_count);
	    print PLOT join "\t", $tree, $rep, $poly_map_end, $pB_init;
	    print PLOT "\n";
	}
	close PLOT;
	close MUTRATE;

	# separate STARRI plot for each contig
	my $Y_key = $out_dir."/".$contig.".Ykey.txt";
	open YKEY, ">$Y_key";
	my %seen;
	my $rank_count = 0;
	my $count = 0;
	my $Ncol = 0; # the number of bipartitions on the y-axis
	my @Ncol;
	foreach my $rank (sort rev_numeric values %instances) {
	    $rank_count++;
	    foreach my $group (sort keys %instances) {
		if ($instances{$group} == $rank) {
		    if (! exists $seen{$group}) {
			print YKEY $rank, "\t", $count,"\t";
			$count += $rank;
			my @group1 = split(/\./, $group);
			my $group2 = diffs(\@species, \@group1);
			my @group2 = @$group2;
			my $groupA;
			my $groupB;
			foreach my $sp (sort @group1) {
			    $groupA .= $sp.".";
			}
			foreach my $sp (sort @group2) {
			    $groupB .= $sp.".";
			}
			my $min = $groupA;
			my $max = $groupB;
			if ( (@group1+0) > (@group2+0) ) {
			    $min = $groupB;
			    $max = $groupA;
			}
			print YKEY join "\t", $count, $min, $max;
			print YKEY "\n";
			push @Ncol, $count;
			$Ncol++;
			$seen{$group} = 1;
		    }
		}
	    }
	}
	
	my $sup_file = $out_dir."/".$contig.".support.txt";
	open SUP, ">$sup_file" || die; # fraction of SNPs in the block supporting a given partition (partition list in YKEY)
	my $Nsup_file = $out_dir."/".$contig.".Nsup.txt";
	open NSUP, ">$Nsup_file" || die; # number of SNPs in the block supporting a given partition
	my $rej_file = $out_dir."/".$contig.".reject.txt";
	open REJ, ">$rej_file" || die; # fraction of SNPs in the block rejecting a given partition
	
	# rows are blocks in STARRI plot
	my $Nrow = $blk_count;
	print SUP "mat<-matrix(byrow=T,nrow=",$Nrow,",data=c("; # can be plotted in R
	print NSUP "mat<-matrix(byrow=T,nrow=",$Nrow,",data=c(";
	print REJ "mat<-matrix(byrow=T,nrow=",$Nrow,",data=c(";
	my @Nrow;
	# print the identities of biparts in each block
	for (my $blk_i=1; $blk_i<=$blk_count; $blk_i++) {
	    my $start_i = $blk_start{$blk_i};
	    my $end_i   = $blk_end{$blk_i};
	    push @Nrow, $physEnd{$blk_i};
	    my $block_len = $physEnd{$blk_i} - $physStart{$blk_i} + 1;
	    # calculate tajima's D and other stats for the block
	    my %taj_fasta; # pad fasta with invariant sites
	    my $padLen = $physEnd{$blk_i} - $physStart{$blk_i} + 1;
	    my $padseq = "";
	    for (my $pad=1; $pad<=$padLen; $pad++) {
		$padseq .= "A";
	    }
	    foreach my $fasta_sp (keys %{ $DNA_blk{$blk_i} }) {
		my $padded = $DNA_blk{$blk_i}{$fasta_sp};
		$padded .= $padseq;
		$taj_fasta{$fasta_sp} = $padded;
	    }
	    my ($seqLength, $N_segSites, $tot_pairDiff, $k_hat, $D, $XY_pairDiff, $k_hatXY, $X_pairDiff, $k_hatX, $Y_pairDiff, $k_hatY) = taj(\%taj_fasta, \@species, \@ingr, \@outgr);
	    my $d = ($k_hatXY/$block_len) - ( (($k_hatX/$block_len) + ($k_hatY/$block_len))/2 ); # estimated ingr/outgr divergence time ((Nei and Li, 1979; Arbogast et al. 2002)
	    my $Fst = 'inf'; # Fst = population differentiation between ingr/outgr
	    if ($k_hatXY > 0) {
		$Fst = ($k_hatXY - ( ($k_hatX+$k_hatY)/2 ) ) / $k_hatXY;
	    }
	    my %biparts_inBlock;
	    my %poly;
	    my $tot_incons = 0;
	    my $expect_i = 0;
	    foreach my $site (sort numeric keys %{ $Nincompat{$blk_i} }) {
		$expect_i++;
		if ($Nmuts{$blk_i}{$site} > 1) {
		    $tot_incons++;
		}
	    }
	    my %splits_in_block;
	    my %incons_in_block;
	    my $i_count = 0;
	    for (my $site_i = ($start_i-1); $site_i <= ($end_i-1); $site_i++) {
		$i_count++;
		
		if (exists $dimorphic{$poly_sites[$site_i]} && exists $split{$contig}{$poly_sites[$site_i]}{1} ) {
#		if (exists $dimorphic{$dimo_sites[$site_i]} && exists $split{$dimo_sites[$site_i]}{1} ) {
		    my @group1_1 = @{ $split{$contig}{$poly_sites[$site_i]}{1} };
		    my $group1_2 = diffs(\@species, \@group1_1);
		    my @group1_2 = @$group1_2;
		    my $groupA = "";
		    my $groupB = "";
		    foreach my $sp (sort @{ $split{$contig}{$poly_sites[$site_i]}{1} } ) {
			$groupA .= $sp.".";
		    }
		    foreach my $sp (sort @{ $split{$contig}{$poly_sites[$site_i]}{2} } ) {
			$groupB .= $sp.".";
		    }
		    my $min = $groupA; # the shortest string that describes the partition
		    my $max = $groupB;
		    if ( (@group1_1+0) > (@group1_2+0) ) {
			$min = $groupB;
			$max = $groupA;
		    }
		    if ($Nmuts{$blk_i}{$i_count} > 1) {
			$incons_in_block{$min}++;
			$incons_tot{$min}++;
		    }
		    else {
			$splits_in_block{$min}++;
			$splits_tot{$min}++;
		    }
		    $bipart_tot{$min}++;
		    if ($bipart_tot{$min} > $most_popular_split) {
			$most_popular_split = $bipart_tot{$min};
		    }
		}
	    }	
	    my $tree_str = "";
	    my $Nsnp_inTree=0;
	    my $inTree_str = "";
	    my $split_sup = 0; # number of SNPs in block supporting the ingr/outgr partition
	    my $split_rej = 0; # number of SNPs in block rejecting the ingr/outgr partition
	    my $Nsnps_inBlock=0;     # count total # SNPs in this block
	    my $dominant_group = "NA"; # find the split with the max # SNPs supporting it in this block
	    my $dominant_fraction = 0; # the fraction of SNPs supporting the dominant group
	    my $max_supporting = 0;
	    my %seen_max; # throw out ties
	    my $ts_all = 0; # count transitions in all SNPs in the block
	    my %done;
	    $rank_count = 0;
	    foreach my $rank (sort rev_numeric values %instances) {
		$rank_count++;
		foreach my $group (sort keys %instances) {
		    if ($instances{$group} == $rank) {
			next if (exists $done{$group});
			$done{$group} = 1;
			my @curr_group = split(/\./, $group);
			# is the current observed grouping consistent with all allowed groups
			my $Nsites = 0;
			my $supporting = 0;
			my $rejecting = 0;
			my @group1_1 = @curr_group;
			my $group1_2 = diffs(\@species, \@curr_group);
			my @group1_2 = @$group1_2;
			my $str1;
			my $str2;
			foreach my $sp (sort @curr_group) {
			    $str1 .= $sp.".";
			}
			foreach my $sp (sort @group1_2) {
			    $str2 .= $sp.".";
			}
			my $groupName = $str1;
			if ( (@curr_group+0) > (@group1_2+0) ) {
			    $groupName = $str2;
			}
			foreach my $split (sort keys %splits_in_block) {
			    $Nsites +=$splits_in_block{$split};
			    if ($split eq $str1) { # exact match
				$supporting += $splits_in_block{$split};
			    }
			    elsif ($split eq $str2) {
				$supporting += $splits_in_block{$split};
			    }
			    else { # not supporting, but does it reject?
				my @group2_1 = split(/\./, $split);
				my $group2_2 = diffs(\@species, \@group2_1);
				my @group2_2 = @$group2_2;
				my $num_crosses = 0;
				my $intersect1_1 = intersect(\@group1_1, \@group2_1);
				my $intersect2_2 = intersect(\@group1_2, \@group2_2);
				my $intersect1_2 = intersect(\@group1_1, \@group2_2);
				my $intersect2_1 = intersect(\@group1_2, \@group2_1);
				my @intersect1_1 = @$intersect1_1;
				my @intersect2_2 = @$intersect2_2;
				my @intersect1_2 = @$intersect1_2;
				my @intersect2_1 = @$intersect2_1;
				if ( ((@intersect1_1+0) > 0) && ((@intersect1_2) > 0) ) { # If group1 at site j spans two previously defined groups at pos
				    $num_crosses++;
				}
				if ( ((@intersect2_1+0) > 0) && ((@intersect2_2) > 0) ) { # if group2 at site j spans two previously defined groups at pos
				    $num_crosses++;
				}
				if ($num_crosses >= 2) { # There is a break between blocks
				    $rejecting += $splits_in_block{$split};
				}
			    }
			}
			my $fraction_rejecting = 0;
			my $fraction_supporting =0;
			if ($Nsites > 0) {
			    $fraction_rejecting = $rejecting / $Nsites;
			    $fraction_supporting = $supporting / $Nsites;
			}
			print SUP $fraction_supporting,",";
			print NSUP $supporting,",";
			print REJ $fraction_rejecting,",";
			if ($supporting > $max_supporting) { # update most popular group
			    $max_supporting = $supporting;
			    $dominant_fraction = $fraction_supporting;
			    $dominant_group = $groupName;
			}
			elsif ($supporting == $max_supporting) { # tie!
			    $seen_max{$supporting} = 1;
			}
			if ($groupName eq $ingr_str || $groupName eq $outgr_str) { # supporting the ingr/outgr partition
			    $split_sup += $supporting;
			    $split_rej += $rejecting;
			}
		    }
		}
	    }
	    # print out the identities of all biparts in the block
	    foreach my $split (sort keys %splits_in_block) {
		$tree_str .= $split."_";
		$Nsnp_inTree += $splits_in_block{$split};
		$inTree_str .= $splits_in_block{$split}."_";
	    }
	    my $incons_str = "";
	    my $Nsnp_homoplasic=0;
	    my $homoplasic_str = "";
	    foreach my $split (sort keys %incons_in_block) {
		$incons_str .= $split."_";
		$Nsnp_homoplasic += $incons_in_block{$split};
		$homoplasic_str .= $incons_in_block{$split}."_";
	    }
	    if ($tree_str eq "") {
		$tree_str = 'na';
	    }
	    if ($incons_str eq "") {
		$incons_str = 'na';
	    }
	    if ($inTree_str eq "") {
		$inTree_str = 'na';
	    }
	    if ($homoplasic_str eq "") {
		$homoplasic_str = 'na';
	    }
	    print TREE join "\t", $contig, $blk_i, $physStart{$blk_i}, $physEnd{$blk_i}, $Nsnp_inTree, $Nsnp_homoplasic, $split_sup, $split_rej, $dominant_group, $dominant_fraction, $tree_str, $inTree_str, $incons_str, $homoplasic_str, $N_segSites, $k_hat, $D, $d, $Fst;
	    print TREE "\n";
	}
	print SUP "))\n";
	print NSUP "))\n";
	print REJ "))\n";
# Print R plot instructions and X,Y coords
# Locations of breakpoints
	print SUP "x<-c(1";
	print NSUP "x<-c(1";
	print REJ "x<-c(1";
	foreach my $break (@Nrow) {
	    print SUP ",", $break;
	    print NSUP ",", $break;
	    print REJ ",", $break;
	}
	print SUP ")\n";
	print NSUP ")\n";
	print REJ ")\n";
	
# Common bipartitions
	print SUP "y<-c(1";
	print NSUP "y<-c(1";
	print REJ "y<-c(1";
	foreach my $rank (@Ncol) {
	    print SUP ",", $rank;
	    print NSUP ",", $rank;
	    print REJ ",", $rank;
	}
	print SUP ")\n";
	print NSUP ")\n";
	print REJ ")\n";
	print SUP "image(x,y,mat,col=gray((0:1000)/1000), yaxt='n',xaxt='n',ylab='Fraction Supporting Bipartition',xlab='Genome position (kb)',main='$contig')\n";
	print NSUP "image(x,y,mat,col=gray((0:1000)/1000), yaxt='n',xaxt='n',ylab='Fraction Supporting Bipartition',xlab='Genome position (kb)',main='$contig')\n";
	print REJ "image(x,y,mat,col=gray((0:1000)/1000), yaxt='n',xaxt='n',ylab='Fraction Rejecting Bipartition',xlab='Genome position (kb)',main='$contig')\n";
	print SUP "axis(2, y, labels=FALSE )\n";
	print NSUP "axis(2, y, labels=FALSE )\n";
	print REJ "axis(2, y, labels=FALSE )\n";
	print SUP "axis(1, x, labels=FALSE)\n";
	print NSUP "axis(1, x, labels=FALSE)\n";
	print REJ "axis(1, x, labels=FALSE)\n";
	print SUP "axis(1, c(50000,100000,150000,200000,250000,300000,350000,400000,450000,500000,550000,600000,650000,700000,750000,800000,850000,900000,950000,1000000,1050000,1100000,1150000,1200000,1250000), labels=c(50,100,150,200,250,300,350,400,450,500,550,600,650,700,750,800,850,900,950,1000,1050,1100,1150,1200,1250),tck=-0.07,lty=3)\n";
	print NSUP "axis(1, c(50000,100000,150000,200000,250000,300000,350000,400000,450000,500000,550000,600000,650000,700000,750000,800000,850000,900000,950000,1000000,1050000,1100000,1150000,1200000,1250000), labels=c(50,100,150,200,250,300,350,400,450,500,550,600,650,700,750,800,850,900,950,1000,1050,1100,1150,1200,1250),tck=-0.07,lty=3)\n";
	print REJ "axis(1, c(50000,100000,150000,200000,250000,300000,350000,400000,450000,500000,550000,600000,650000,700000,750000,800000,850000,900000,950000,1000000,1050000,1100000,1150000,1200000,1250000), labels=c(50,100,150,200,250,300,350,400,450,500,550,600,650,700,750,800,850,900,950,1000,1050,1100,1150,1200,1250),tck=-0.07,lty=3)\n";
    }
}		    
close CONT;

#returns a hash of sequence indexed by fasta headers
sub readFasta{
    my %fasta;
    my $line;
    my $length=0;
    my $header;

    for $line (@_){
        chomp $line;

        #find header lines
	if ($line =~ /^>(.+)/) {
            $header = $1;
#	    print $header,"\n";
            next;
        }

        #for non-header lines...
        if(defined($header)){
	    # only include species in the subset of interest
	    next unless (exists $subset{$header});
            #get rid of spaces
            $line =~ s/\s+//g;
            #append to the current sequence stored in %fasta
            $fasta{$header} .= $line;
        }
    }
    #return sequences indexed by headers
    return %fasta;
}

sub numeric {
    $a <=> $b;
}

sub rev_numeric {
    $b <=> $a;
}

sub getSplit { # convert a site to 2 non-overlapping arrays
    my ($contig,$i,$j) = @_; # the sites of interest
    my %group;
#    print "sub_getSplit::\n";
    for (my $pos=$i; $pos< $j; $pos+=1) {
#	print "position= ", $pos,"\n";
	my $map = $dimo_sites[$pos];
	if (exists $r{$map}{$species[1]}{$contig}) { # Only include dimorphic sites
	    my $ref_base = $r{$map}{$species[1]}{$contig};

	    foreach my $sp (@species) {
		if ($r{$map}{$sp}{$contig} eq $ref_base) {
		    push @{ $group{$contig}{$map}{1} }, $sp;
#		    print "add ", $sp, " to group1\n";
		}
		else {
		    push @{ $group{$contig}{$map}{2} }, $sp;
#		    print "add ", $sp, " to group2\n";
		}
	    }
	    # group1 always contains the shorter list of strain names
	    my @min;
	    my @max;
	    if ( (@{ $group{$contig}{$map}{1} }+0) < (@{ $group{$contig}{$map}{2} }+0) ) {
		@min = sort @{ $group{$contig}{$map}{1} };
		@max = sort @{ $group{$contig}{$map}{2} };
	    }
	    else {
		@min = sort @{ $group{$contig}{$map}{2} };
		@max = sort @{ $group{$contig}{$map}{1} };
	    }
	    @{ $group{$contig}{$map}{1} } = @min;
	    @{ $group{$contig}{$map}{2} } = @max;
#	    print join "\t", "@{ $group{$map}{1} }", "@{ $group{$map}{2} }";
#	    print "\n";
	}
	else {
#	    print join "\t", "no r: ", $map, $dimo_sites[$pos], $pos, $contig,"\n";
	}
    }
    return %group;
}

sub diffs { # returns differences between 2 arrays
    my ($array1, $array2) = @_;
    my @array1 = @$array1;
    my @array2 = @$array2;
    my @union = my @intersection = my @difference = ();
    my %count = ();
    foreach my $element (@array1, @array2) {
	$count{$element}++;
    }
    foreach my $element (keys %count) {
	push @union, $element;
	push @{ $count{$element} > 1 ? \@intersection : \@difference }, $element;
    }
    return \@difference;
}

sub intersect { # returns the intersection between 2 arrays                                                                                                                                                     
    my ($array1, $array2) = @_;
    my @array1 = @$array1;
    my @array2 = @$array2;
    my @union = my @intersection = my @difference = ();
    my %count = ();
    foreach my $element (@array1, @array2) {
        $count{$element}++;
    }
    foreach my $element (keys %count) {
        push @union, $element;
        push @{ $count{$element} > 1 ? \@intersection : \@difference }, $element;
    }
    return \@intersection;
}

sub taj { # computes tajima's D, nucleotide diversity and watterson's S
    my ($dna, $ok_species, $spX, $spY) = @_;
    my %dna = %$dna;
    my @ok_species = @$ok_species;
    my @spX = @$spX;
    my @spY = @$spY;
    my %spX;
    foreach my $sp (@spX) {
	$spX{$sp} = 1;
    }
    my %spY;
    foreach my $sp (@spY) {
	$spY{$sp} = 1;
    }
    my %seenbefore; # avoid redundant pairs we've seenbefore before
    my $tot_pairDiff = 0; # between any pair of species
    my $XY_pairDiff = 0; # only between a member of X and a member of Y
    my $X_pairDiff = 0; # only within X
    my $Y_pairDiff = 0; # only within Y
    my %segregatingSites; # store whether each site in window is polymorphic or not
    my $n = 0; # sample size
    my $XY_pairs = 0;
    my $X_pairs = 0;
    my $Y_pairs = 0;
    my $a1 = 0; # eq. (3) from Tajima 1989
    my $a2 = 0; # eq. (4) from Tajima 1989
    my $seqLength = 0;
    foreach my $species1 (@ok_species) {
	$n++;
	$a1 += 1 / $n;
	$a2 += 1 / ($n*$n);
#	print "taj sp ", $species1,"\n";
	next unless (exists $dna{$species1});
	$seqLength = length($dna{$species1});
#	print "seqLen= ", $seqLength,"\n";
	foreach my $species2 (@ok_species) {
	    next if exists $seenbefore{$species2}{$species1};
	    $seenbefore{$species1}{$species2}++;
	    next if ($species1 eq $species2);
	    if (exists $spX{$species1} && exists $spY{$species2}) {
		$XY_pairs++;
	    }
	    elsif (exists $spX{$species2} && exists $spY{$species1}) {
		$XY_pairs++;
	    }
	    elsif (exists $spX{$species1} && exists $spX{$species2}) {
		$X_pairs++;
	    }
	    elsif (exists $spY{$species1} && exists $spY{$species2}) {
		$Y_pairs++;
	    }
	    for (my $i=0; $i<$seqLength; $i++) {
		next if (substr($dna{$species1},$i,1) eq "-" || substr($dna{$species2},$i,1) eq "-"); #skip gaps
		if (substr($dna{$species1},$i,1) ne substr($dna{$species2},$i,1)) { # diff nucleotide
		    $tot_pairDiff++;
		    $segregatingSites{$i}++;
		    if (exists $spX{$species1} && exists $spY{$species2}) {
			$XY_pairDiff++;
		    }
		    elsif (exists $spX{$species2} && exists $spY{$species1}) {
			$XY_pairDiff++;
		    }
		    elsif (exists $spX{$species1} && exists $spX{$species2}) {
			$X_pairDiff++;
		    }
		    elsif (exists $spY{$species1} && exists $spY{$species2}) {
			$Y_pairDiff++;
		    }
		}
	    }
	}
    }
    $a1 -= 1 / $n; # only want sum to n-1
    $a2 -= 1/ ($n*$n);
    my $b1 =  ($n+1) / (3*($n-1)); # eq. (8) from Tajima 1989
    my $b2 = (2*(($n*$n)+($n)+3)) / (9*$n*($n - 1)); # eq. (9) from Tajima 1989
    my $c1 = $b1 - (1 / $a1);
    my $c2 = $b2 - (($n+2)/($a1*$n)) + ($a2/($a1*$a1));
    my $e1 = $c1 / $a1;
    my $e2 = $c2 / (($a1*$a1)+$a2);

    my @segSites = keys %segregatingSites;
    my $N_segSites = (@segSites+0);
    my $k_hat = $tot_pairDiff / ($n*($n-1)/2); # divide by the n-choose-2 # of seq. pairs
    my $k_hatXY = 0;
    if ($XY_pairs >0) {
	$k_hatXY = $XY_pairDiff / $XY_pairs;
    }
    my $k_hatX = 0;
    if ($X_pairs > 0) {
	$k_hatX = $X_pairDiff / $X_pairs;
    }
    my $k_hatY = 0;
    if ($Y_pairs > 0) {
	$k_hatY = $Y_pairDiff / $Y_pairs;
    }
    my $d = $k_hat - ($N_segSites / $a1); # eq. (28)
    my $V_d = ($e1*$N_segSites) + ($e2*$N_segSites*($N_segSites-1)) ;
    my $D = 0;
    if ($d == 0 && $V_d <= 0) {
	$D = 'NA';
    }
    else {
	$D = $d / sqrt($V_d);
    }
    return ($seqLength, $N_segSites, $tot_pairDiff, $k_hat, $D, $XY_pairDiff, $k_hatXY, $X_pairDiff, $k_hatX, $Y_pairDiff, $k_hatY);
}
