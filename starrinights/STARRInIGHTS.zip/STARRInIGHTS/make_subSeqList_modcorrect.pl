#!/usr/bin/perl -w

use strict;

my $fasta = $ARGV[0]; # the fasta file input (eg. /home/jesse1/STARRI/1.0/c47/contig.c47.concat3.fa )
my $subset = $ARGV[1]; # subset of species in the fasta file to include (eg /home/jesse1/STARRI/1.0/1F+ZF.group )

#print start time
print "Start time:\n";
my @Month_name = ( "January", "February", "March", "April", "May", "June",
		"July", "August", "September", "October", "November", "December" );
my ( $sec, $min, $hour, $day, $month, $year ) = ( localtime ) [ 0, 1, 2, 3, 4, 5 ];
printf  "%02d:%02d:%02d %02d %s %04d\n", 
    $hour, $min, $sec, $day, $Month_name[$month], $year+1900 ;
print "\n\n";

my @DNAlines;
open DNA, $fasta || die "Could not open fasta file for $fasta\n";
while (<DNA>) {
    push @DNAlines, $_;
}
close DNA;

my %subset;
open FILE, $subset || die "Can't open infile $subset\n";
while (<FILE>) {
    chomp;
    $subset{$_} = $_;
}
close FILE;

my %DNA = readFasta(@DNAlines); # makes a hash of header:sequence
my @species = sort keys %DNA;
# puts sequences in a list to check their length
my @sequences = values %DNA;
my $size = length $sequences[0];
foreach (@sequences) { # checks that all are same length
    unless ((length $_) == $size) {
	my %reversed = reverse %DNA;
	print "This sequence is not the right length: $reversed{$_}\n";
    }
}

# make new fasta, only including variable sites
my %polymorphic; # store polymorphic, informative sites
my %poly_variants; # the number of bases segregating at a site i
for (my $i=0; $i<$size; $i+=1) {	
    my %unique_bases;
    foreach my $species (@species) {
	my $base = substr($DNA{$species},$i,1);
	$unique_bases{$base} += 1;
    }
    # only retain polymorphic sites with 2 segregating bases
    my $poly_variants = 0;
    my $singleton = 0; # whether the site contains a singleton or not
    my $non_sing = 0; # how many segregating bases are not singletons
    foreach my $base (keys %unique_bases) {
	if ($unique_bases{$base} == 1) { # singleton site!
	    $singleton++;
	}
	else {
	    $non_sing++;
	}
	$poly_variants++;
    }
    if ($non_sing >= 2) { # a potentially informative site, though it might also contain singletons
	if ($poly_variants >= 2) { # at least 2 alleles segregating
	    $poly_variants{$i} = $poly_variants;
	    foreach my $sp (@species) {
		my $base = substr($DNA{$sp},$i,1);
		$polymorphic{$i}{$sp} = $base;
	    }
	}
    }
}

my @poly_sites = sort numeric keys %polymorphic;

# get appropriate species names and lengths for phylip format
my %sp_header;
foreach my $sp (@species) {
    my $Nchar = length($sp);
    my $sp_header = $sp;
    for (my $i=1; $i<=(10 - $Nchar); $i++) {
	$sp_header .= " ";
    }
    $sp_header{$sp} = $sp_header;
}

#`mkdir shell_scripts`;
my $sge_file = $fasta;
$sge_file =~ s/\.fa$//;
my $sh_count =  1;
$sge_file .= ".".$sh_count.".subseqs.txt";
open SGE, ">$sge_file" || die "Can't open SGE file\n";

my $job_count=0; 
my $sub_job_count=0; # further divide jobs into 1000 to run sequentially on one node
my $subseq_len=0; # the amount of sequence (#bp) considered in the summed parsimony runs
my $batch_count = 1;

# first print out the entire sequence:
print SGE join "\t", $job_count, "1", (@poly_sites+0);
print SGE "\n";

# the print out broken pairs of subsequences
for (my $i=0; $i<(@poly_sites-1); $i+=1) {
    print SGE join "\t", $job_count, "1", ($i+1);
    print SGE "\n";
    print SGE join "\t", $job_count, ($i+2), (@poly_sites+0);
    print SGE "\n";
}

print "\n";
#print stop time
print "Finish time:\n";
( $sec, $min, $hour, $day, $month, $year ) = ( localtime ) [ 0, 1, 2, 3, 4, 5 ];
printf  "%02d:%02d:%02d %02d %s %04d\n", 
    $hour, $min, $sec, $day, $Month_name[$month], $year+1900 ;

#returns a hash of sequence indexed by fasta headers
sub readFasta{
    my %fasta;
    my $line;
    my $length=0;
    my $header;

    for $line (@_){
        chomp $line;

        #find header lines
	if ($line =~ /^>(.+)/) {
            $header = $1;
#	    print $header,"\n";
            next;
        }

        #for non-header lines...
        if(defined($header)){
	    # only include species in the subset of interest
	    next unless (exists $subset{$header});
            #get rid of spaces
            $line =~ s/\s+//g;
            #append to the current sequence stored in %fasta
            $fasta{$header} .= $line;
        }
    }
    #return sequences indexed by headers
    return %fasta;
}

sub numeric {
    $a <=> $b;
}

sub diffs { # returns differences between 2 arrays
    my ($array1, $array2) = @_;
    my @array1 = @$array1;
    my @array2 = @$array2;
    my @union = my @intersection = my @difference = ();
    my %count = ();
    foreach my $element (@array1, @array2) {
	$count{$element}++;
    }
    foreach my $element (keys %count) {
	push @union, $element;
	push @{ $count{$element} > 1 ? \@intersection : \@difference }, $element;
    }
    return \@difference;
}

sub intersect { # returns the intersection between 2 arrays                                                                                                                                                     
    my ($array1, $array2) = @_;
    my @array1 = @$array1;
    my @array2 = @$array2;
    my @union = my @intersection = my @difference = ();
    my %count = ();
    foreach my $element (@array1, @array2) {
        $count{$element}++;
    }
    foreach my $element (keys %count) {
        push @union, $element;
        push @{ $count{$element} > 1 ? \@intersection : \@difference }, $element;
    }
    return \@intersection;
}
