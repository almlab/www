#!/usr/bin/perl -w

use strict;

my $fasta = $ARGV[0]; # the fasta file input (without full path name eg. contig.c47.concat3.fa )
my $subset = $ARGV[1]; # subset of species in the fasta file to include (eg /home/jesse1/STARRI/1.0/1F+ZF.group )

my $curr_dir = `pwd`;
chomp $curr_dir;

my $contig_file = $curr_dir."\/".$fasta;

my $contig = "XX";
if ($fasta =~ m/contig\.([\d]+)\./) {
    $contig = $1;
}

my @DNAlines;
open DNA, $fasta || die "Could not open fasta file for $fasta\n";
while (<DNA>) {
    push @DNAlines, $_;
}
close DNA;

my %subset;
open FILE, $subset || die "Can't open infile $subset\n";
while (<FILE>) {
    chomp;
    $subset{$_} = $_;
}
close FILE;

my %DNA = readFasta(@DNAlines); # makes a hash of header:sequence
my @species = sort keys %DNA;
# puts sequences in a list to check their length
my @sequences = values %DNA;
my $size = length $sequences[0];
foreach (@sequences) { # checks that all are same length
    unless ((length $_) == $size) {
	my %reversed = reverse %DNA;
	print "This sequence is not the right length: $reversed{$_}\n";
    }
}

# print list of singleton sites (excluded from parsimony & DP) to file:
my $single_name = $fasta;
$single_name =~ s/\.fa$/\.singletons\.key\.txt/;
my $single_file = $curr_dir."\/".$single_name;
open SING, ">$single_file" || die "Can't open $single_file\n";

# make new fasta, only including variable sites
my %polymorphic; # store polymorphic, informative sites
my %poly_variants; # the number of bases segregating at a site i
my %r; # store DIMORPHIC INFORMATIVE sites
my %dimorphic; # whether the site is dimorphic and informative
my %Nsingle;
for (my $i=0; $i<$size; $i+=1) {	
    my %unique_bases;
    my %singleton_sp;
    foreach my $species (@species) {
	my $base = substr($DNA{$species},$i,1);
	$unique_bases{$base} += 1;
	$singleton_sp{$base} = $species;
    }
    # only retain polymorphic sites with 2 segregating bases
    my $poly_variants = 0;
    my $singleton = 0; # whether the site contains a singleton or not
    my $singleton_sp = 0;
    my $non_sing = 0; # how many segregating bases are not singletons
    foreach my $base (keys %unique_bases) {
	if ($unique_bases{$base} == 1) { # singleton site!
	    $singleton++;
	    $singleton_sp = $singleton_sp{$base};
	}
	else {
	    $non_sing++;
	}
	$poly_variants++;
    }
    if ($non_sing >= 2) { # a potentially informative site, though it might also contain singletons
	if ($poly_variants >= 2) { # at least 2 alleles segregating
	    $poly_variants{$i} = $poly_variants;
	    foreach my $sp (@species) {
		my $base = substr($DNA{$sp},$i,1);
		$polymorphic{$i}{$sp} = $base;
	    }
	    if ($poly_variants == 2) { # exactly 2 alleles segregating => dimorphic site, to be considered in pre-filtering for perfectly parsimonious stretchs
		foreach my $sp (@species) {
		    my $base = substr($DNA{$sp},$i,1);
		    $r{$i}{$sp} = $base;
		    $dimorphic{$i} = $i;
		}
	    }
	}
    }
    elsif ($singleton >= 1) { 
	foreach my $base (keys %unique_bases) {
	    if ($unique_bases{$base} == 1) {
		print SING join "\t", ($i+1),$singleton, $singleton_sp{$base};
		print SING "\n";
		$Nsingle{$singleton}++;
	    }
	}
    }
}
close SING;

my @poly_sites = sort numeric keys %polymorphic; # all informative sites
my @dimo_sites = sort numeric keys %r; # all DIMORPHIC informative sites
my $n = (@dimo_sites+0);
my %split = getSplit(0,$n); # contains 2 non-overlapping arrays specifying the bipartition for site j

# print out mapping of polymorphic sites to the actual physical sequence (including invariant sites)
my $map_name = $fasta;
$map_name =~ s/\.fa$/\.poly\.key\.txt/;
my $map_file = $curr_dir."\/".$map_name;
open MAP, ">$map_file" || die "Can't open $map_file\n";
print MAP join "\t", "poly_pos", "cont_pos";
print MAP "\n";
for (my $i=0; $i<(@poly_sites); $i++) {
    print MAP join "\t", ($i+1), ($poly_sites[$i]+1);
    print MAP "\n";
}
close MAP;

my $var_name = $fasta;
$var_name =~ s/\.fa$/\.poly\.variants\.key\.txt/;
my $var_file = $curr_dir."\/".$var_name;
open VAR, ">$var_file" || die "Can't open $var_file\n";
print VAR join "\t", "poly_pos", "cont_pos", "Nvariants";
print VAR "\n";
my $Ninf2 = 0;
my $Ninf3 = 0;
my $Ninf4 = 0;
for (my $i=0; $i<(@poly_sites); $i++) {
    print VAR join "\t", ($i+1), ($poly_sites[$i]+1), $poly_variants{$poly_sites[$i]};
    print VAR "\n";
    if ($poly_variants{$poly_sites[$i]} == 2) {
	$Ninf2++;
    }
    if ($poly_variants{$poly_sites[$i]} == 3) {
	$Ninf3++;
    }
    if ($poly_variants{$poly_sites[$i]} == 4) {
	$Ninf4++;
    }
}
close VAR;

print "***informative sites****\n";
print "dimorph  inform: ", $Ninf2,"\n";
print "trimorph inform: ", $Ninf3,"\n";
print "4-morph  inform: ", $Ninf4,"\n";
print "total    infrom: ", ($Ninf2+$Ninf3+$Ninf4),"\n";

print "***non-informative sites***\n";
my $tot_nonInf = 0;
foreach my $n (keys %Nsingle) {
    print "singletons in ", $n, " leafs: ", $Nsingle{$n},"\n";
    $tot_nonInf += $Nsingle{$n};
}
print "singletons total: ", $tot_nonInf,"\n";

open OUT, ">key.txt" || die;
print OUT join "\t", "cont", "physLen", "inform", "di", "tri", "quad", "nonInf", "lk", "map", "subseqs", "fasta", "subset";
print OUT "\n";
my $lk_dir = $curr_dir."\/lk";
foreach my $subseq_file (glob "*.subseqs.txt") {
    my $lk_name = $subseq_file;
    $lk_name =~ s/\.subseqs\.txt/\.lk\.txt/;
    my $lk_file = $lk_dir."\/".$lk_name;
    unless (-e $lk_file) {
	print $lk_file, " does not exist!\n";
	next;
#	exit;
    }
    print OUT join "\t", $contig, $size, ($Ninf2+$Ninf3+$Ninf4), $Ninf2, $Ninf3, $Ninf4, $tot_nonInf, $lk_file, $var_file, $subseq_file, $contig_file, $subset;
    print OUT "\n";
}

#returns a hash of sequence indexed by fasta headers
sub readFasta{
    my %fasta;
    my $line;
    my $length=0;
    my $header;

    for $line (@_){
        chomp $line;

        #find header lines
	if ($line =~ /^>(.+)/) {
            $header = $1;
#	    print $header,"\n";
            next;
        }

        #for non-header lines...
        if(defined($header)){
	    # only include species in the subset of interest
	    next unless (exists $subset{$header});
            #get rid of spaces
            $line =~ s/\s+//g;
            #append to the current sequence stored in %fasta
            $fasta{$header} .= $line;
        }
    }
    #return sequences indexed by headers
    return %fasta;
}

sub numeric {
    $a <=> $b;
}

sub getSplit { # convert a site to 2 non-overlapping arrays
    my ($i,$j) = @_; # the sites of interest
    my %group;
#    print "sub_getSplit::\n";
    for (my $pos=$i; $pos< $j; $pos+=1) {
#	print "position= ", $pos,"\n";
	my $map = $dimo_sites[$pos];
	if (exists $r{$map}{$species[1]}) { # Only include dimorphic sites
	    my $ref_base = $r{$map}{$species[1]};

	    foreach my $sp (@species) {
		if ($r{$map}{$sp} eq $ref_base) {
		    push @{ $group{$map}{1} }, $sp;
#		    print "add ", $sp, " to group1\n";
		}
		else {
		    push @{ $group{$map}{2} }, $sp;
#		    print "add ", $sp, " to group2\n";
		}
	    }
	    # group1 always contains the shorter list of strain names
	    my @min;
	    my @max;
	    if ( (@{ $group{$map}{1} }+0) < (@{ $group{$map}{2} }+0) ) {
		@min = sort @{ $group{$map}{1} };
		@max = sort @{ $group{$map}{2} };
	    }
	    else {
		@min = sort @{ $group{$map}{2} };
		@max = sort @{ $group{$map}{1} };
	    }
	    @{ $group{$map}{1} } = @min;
	    @{ $group{$map}{2} } = @max;
#	    print join "\t", "@{ $group{$map}{1} }", "@{ $group{$map}{2} }";
#	    print "\n";
	}
    }
    return %group;
}

sub diffs { # returns differences between 2 arrays
    my ($array1, $array2) = @_;
    my @array1 = @$array1;
    my @array2 = @$array2;
    my @union = my @intersection = my @difference = ();
    my %count = ();
    foreach my $element (@array1, @array2) {
	$count{$element}++;
    }
    foreach my $element (keys %count) {
	push @union, $element;
	push @{ $count{$element} > 1 ? \@intersection : \@difference }, $element;
    }
    return \@difference;
}

sub intersect { # returns the intersection between 2 arrays                                                                                                                                                     
    my ($array1, $array2) = @_;
    my @array1 = @$array1;
    my @array2 = @$array2;
    my @union = my @intersection = my @difference = ();
    my %count = ();
    foreach my $element (@array1, @array2) {
        $count{$element}++;
    }
    foreach my $element (keys %count) {
        push @union, $element;
        push @{ $count{$element} > 1 ? \@intersection : \@difference }, $element;
    }
    return \@intersection;
}

