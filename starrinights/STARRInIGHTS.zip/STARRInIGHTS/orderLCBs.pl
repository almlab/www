#!/usr/bin/perl -w

use strict;
my $blast_out = $ARGV[0]; # the *.bestHit.out file, output of parseBLASTALL.pl
 
open BLAST, $blast_out;
my %coverage; # how many times a site in the reference genome is hit by an LCB
my %LCB; # list of the LCBs that hit the site
my %contigs;
my %contLen; # length of each contig
my %strand;
while (<BLAST>) {
    chomp;
    my ($query,$hit,$identity,$length,$mismatches,$gaps,$queryStart,$queryEnd,$hitStart,$hitEnd,$E,$bitscore) = split;
    $query =~ s/LCB//;
    $contigs{$hit}++;
    if ($hitStart < $hitEnd) {
	for (my $i=$hitStart; $i<=$hitEnd; $i++) {
	    $strand{$hit}{$i} = "+";
	    $coverage{$hit}{$i}++;
	    push @{ $LCB{$hit}{$i} }, $query;
	    if (! exists $contLen{$hit}) {
		$contLen{$hit} = $i;
	    }
	    elsif ($i > $contLen{$hit}) {
		$contLen{$hit} = $i;
	    }
	}
    }
    else {
	for (my $i=$hitEnd; $i<=$hitStart; $i++) {
	    $strand{$hit}{$i} = "-";
	    $coverage{$hit}{$i}++;
	    push @{ $LCB{$hit}{$i} }, $query;
	    if (! exists $contLen{$hit}) {
		$contLen{$hit} = $i;
	    }
	    elsif ($i > $contLen{$hit}) {
		$contLen{$hit} = $i;
	    }
	}
    }
}
close BLAST;

my %LCBcount; # each LCB should only be used once
my $totLen = 0;
my $coverage_file = $blast_out;
$coverage_file =~ s/\.out/\.coverage\.out/;
open COVER, ">$coverage_file" || die;
foreach my $contig (keys %contigs) {
    my %start; # where in the contig an LCB starts to align
    my %end; # where the alignment ends
    my %length;
    for (my $i=1; $i<=$contLen{$contig}; $i++) {
	if (exists $coverage{$contig}{$i}) {
	    print COVER $i, "\t", $coverage{$contig}{$i},"\n";
	    foreach my $LCB (@{ $LCB{$contig}{$i} }) {
		if (! exists $end{$LCB} ) { # seeing this LCB for the first time
		    $start{$LCB} = $i;
		    $end{$LCB} = $i;
		    $length{$LCB}++;
		}
		else {
		    $end{$LCB} = $i;
		    $length{$LCB}++;
		}
	    }
	}
	else {
	    print COVER $i,"\t","0","\n";
	}
    }
    my $last_end = 0; # LCBs should be non-overlapping
    for (my $i=1; $i<=$contLen{$contig}; $i++) {	
	if (exists $coverage{$contig}{$i}) {
	    my $maxLen = 0;
	    my $bestLCB = "NA";
	    foreach my $LCB (@{ $LCB{$contig}{$i} }) {
		if ($length{$LCB} > $maxLen) {
		    $maxLen = $length{$LCB};
		    $bestLCB = $LCB;
#		    print $LCB, "\t", $maxLen,"\n";
		}
	    }
#	    print join "\t", $i, "-", $start{$bestLCB},"=", $maxLen,"\n";
	    if ( ($i - $start{$bestLCB} + 1) == $maxLen ) {
		# what strand?
		my $plus_strand = 0;
		my $total = 0;
		for (my $site=$start{$bestLCB}; $site<=$i; $site++) {
		    next if (!exists $strand{$contig}{$site});
		    if ($strand{$contig}{$site} eq "+") {
			$plus_strand++;
		    }
		    $total++;
		}
		my $plus_fraction = $plus_strand/$total;
		print join "\t", $contig, $start{$bestLCB}, $i, $coverage{$contig}{$i}, $bestLCB, $length{$bestLCB}, $plus_fraction;
		$LCBcount{$bestLCB}++;
		if ($coverage{$contig}{$i} > 1) {
		    if ( ($end{$bestLCB} - $start{$bestLCB} + 1) != $length{$bestLCB}) {
			print "\t", "Length error!..  end= ", $end{$bestLCB}," start= ", $start{$bestLCB};
		    }
		}
		if ($start{$bestLCB} < $last_end) {
		    print "\t", "overlap";
		}
		$last_end = $i;
		print "\n";
	    }
	}
	else {
#	    print "-";
	}
    }
}

print "LCBs seen more than once:\n";
foreach my $LCB (keys %LCBcount) {
    if ($LCBcount{$LCB} > 1) {
	print $LCB,"\t", $LCBcount{$LCB},"\n";
    }
}

print "LCBs not seen at all:\n";
foreach my $LCB (keys %LCBcount) {
    if ($LCBcount{$LCB} < 1) {
	print $LCB,"\t", $LCBcount{$LCB},"\n";
    }
}
