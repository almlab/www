#!/usr/bin/perl -w

use strict;

my $fasta = $ARGV[0]; # the fasta file input (eg. /home/jesse1/STARRI/1.0/c47/contig.c47.concat3.fa )
my $prebreaks = $ARGV[1]; # pre-computed breakpoints, based on otto's phylogenetic inconsistency metric
my $subset = $ARGV[2]; # subset of species in the fasta file to include (eg /home/jesse1/STARRI/1.0/1F+ZF.group )
my $p_cut = $ARGV[3]; # the p-value cutoff for considering a stretch of phylogenetic incongruence in 'prebreaks' file
my $len_limit  =$ARGV[4]; # the amount of seq length lined up on a node. 400,000 for speedy.
my $node_lineup  =$ARGV[5]; #the number of jobs lined up on each compute node e.g. 1000 for short, 500 for speedy
my $start_site_min = $ARGV[6]; # the polymorphic site to start at
my $start_site_max = $ARGV[7]; # ... and to end at
my $skip_pars = $ARGV[8]; # if = 1, skip stretches of SNPs that fit the same tree (meaning that no breaks can be introduced within them); if 0, do not skip them
my $LCB_file = $ARGV[9]; # file containing the locations of LCB boundaries. do not consider subseqs that span LCB bounds.

#print start time
print "Start time:\n";
print "Start time:\n";
print $fasta,"\n";
print $prebreaks,"\n";
print $subset,"\n";
print $len_limit,"\n";
print $node_lineup,"\n";
print $start_site_min,"\n";
print $start_site_max,"\n";
my @Month_name = ( "January", "February", "March", "April", "May", "June",
		"July", "August", "September", "October", "November", "December" );
my ( $sec, $min, $hour, $day, $month, $year ) = ( localtime ) [ 0, 1, 2, 3, 4, 5 ];
printf  "%02d:%02d:%02d %02d %s %04d\n", 
    $hour, $min, $sec, $day, $Month_name[$month], $year+1900 ;
print "\n\n";

# print list of genomic stretches with perfect parsimony (no homoplasic SNPs) (excluded from parsimony tree building)
my $perfect_file = $fasta;
$perfect_file =~ s/\.fa$//;
$perfect_file .= ".".$start_site_max.".lk.txt";
open PERFECT, ">$perfect_file" || die "Can't open $perfect_file\n";
print "Subsequences without homoplasic SNPs written to file: ", $perfect_file,"\n\n";

my @DNAlines;
open DNA, $fasta || die "Could not open fasta file for $fasta\n";
while (<DNA>) {
    push @DNAlines, $_;
}
close DNA;

my %subset;
open FILE, $subset || die "Can't open infile $subset\n";
while (<FILE>) {
    chomp;
    $subset{$_} = $_;
}
close FILE;

my %DNA = readFasta(@DNAlines); # makes a hash of header:sequence
my @species = sort keys %DNA;
# puts sequences in a list to check their length
my @sequences = values %DNA;
my $size = length $sequences[0];
foreach (@sequences) { # checks that all are same length
    unless ((length $_) == $size) {
	my %reversed = reverse %DNA;
	print "This sequence is not the right length: $reversed{$_}\n";
    }
}

# make new fasta, only including variable sites
my %polymorphic; # store polymorphic, informative sites
my %poly_variants; # the number of bases segregating at a site i
my %r; # store DIMORPHIC INFORMATIVE sites
my %dimorphic; # whether the site is dimorphic and informative

for (my $i=0; $i<$size; $i+=1) {	
    my %unique_bases;
    foreach my $species (@species) {
	my $base = substr($DNA{$species},$i,1);
	$unique_bases{$base} += 1;
    }
    # only retain polymorphic sites with 2 segregating bases
    my $poly_variants = 0;
    my $singleton = 0; # whether the site contains a singleton or not
    my $non_sing = 0; # how many segregating bases are not singletons
    foreach my $base (keys %unique_bases) {
	if ($unique_bases{$base} == 1) { # singleton site!
	    $singleton++;
	}
	else {
	    $non_sing++;
	}
	$poly_variants++;
    }
    if ($non_sing >= 2) { # a potentially informative site, though it might also contain singletons
	if ($poly_variants >= 2) { # at least 2 alleles segregating
	    $poly_variants{$i} = $poly_variants;
	    foreach my $sp (@species) {
		my $base = substr($DNA{$sp},$i,1);
		$polymorphic{$i}{$sp} = $base;
	    }
	    if ($poly_variants == 2) { # exactly 2 alleles segregating => dimorphic site, to be considered in pre-filtering for perfectly parsimonious stretchs
		foreach my $sp (@species) {
		    my $base = substr($DNA{$sp},$i,1);
		    $r{$i}{$sp} = $base;
		    $dimorphic{$i} = $i;
		}
	    }
	}
    }
}

my @poly_sites = sort numeric keys %polymorphic;
my @dimo_sites = sort numeric keys %r; # all DIMORPHIC informative sites
my $n = (@dimo_sites+0);
my %split = getSplit(0,$n); # contains 2 non-overlapping arrays specifying the bipartition for site j

my %LCBbound; # end positions of LCBs
if (-e $LCB_file) {
    open LCB, $LCB_file || die "Can't find $LCB_file file\n";
    while (<LCB>) {
	chomp;
	next if (m/^LCB/); # header
	my ($LCB, $contig, $start, $end, $refStart, $refEnd, $strand) = split "\t";
	$LCBbound{$end} = 1;
    }
    close LCB;
}

my $w=5; # the window size used to compute pre-breaks
if ($prebreaks =~ m/\.w([\d]+)\.dat/) {
    $w = $1;
}

my %prebreaks;
if (-e $prebreaks) {
    open PREBREAKS, $prebreaks || die "Can't find $prebreaks file\n";
    while (<PREBREAKS>) {
	chomp;
	my ($snp_pos, $cont_pos, $mean, $sd, $chi, $sig, $ZF270, $oneF289, $oneF273, $ZF99, $ZF28, $oneF175, $oneF53, $oneF111, $FF75, $ZF14, $FF274, $ZF170, $ZF264, $FF160, $ZF65, $ZF205, $oneF97, $ZF255, $ZF207, $ZF30) = split;
	next if (m/^pos/);
	my $p_value = 0;
	if ($sig eq "*") {
	    $p_value = 2;
	}
	elsif ($sig eq "**") {
	    $p_value = 3;
	}
	elsif ($sig eq "***") {
	    $p_value = 4;
	}
	elsif ($sig eq "****") {
	    $p_value = 5;
	}
	elsif ($sig eq "*****") {
	    $p_value = 6;
	}
	if ($p_value >= $p_cut) {
	    $prebreaks{$cont_pos} = 1;
	}
    }
    close PREBREAKS;
}

# get appropriate species names and lengths for phylip format
my %sp_header;
foreach my $sp (@species) {
    my $Nchar = length($sp);
    my $sp_header = $sp;
    for (my $i=1; $i<=(10 - $Nchar); $i++) {
	$sp_header .= " ";
    }
    $sp_header{$sp} = $sp_header;
}

#`mkdir shell_scripts`;
my $sge_file = $fasta;
$sge_file =~ s/\.fa$//;
my $sh_count =  $start_site_max + 1;
$sge_file .= ".".$sh_count.".subseqs.txt";
open SGE, ">>$sge_file" || die "Can't open SGE file\n";

my $job_count=0; 
my $sub_job_count=0; # further divide jobs into 1000 to run sequentially on one node
my $subseq_len=0; # the amount of sequence (#bp) considered in the summed parsimony runs
my $batch_count = 1;
for (my $i=$start_site_min; $i<(@poly_sites); $i+=1) {
    next if ($i > $start_site_max);
    my $broken=1e10; # go no further than the first known breakpoint
    my $homoplasies = 0; # if no homoplasic sites, don't bother building pars tree. set homoplasy score to zero
    my %group_list;
    my %seen_group;
    if ($skip_pars == 1) {
	if (! exists $dimorphic{$poly_sites[$i]}) { # the site is >dimorphic, build pars trees including it
	    $homoplasies = 1;
#	print $i, " i not dimorphic\n";
	}
	else {
	    @ {$group_list{ 1 } } = @{ $split{$poly_sites[$i]}{1} };
#	print "group_list i = ", "@{ $split{$poly_sites[$i]}{1} }","\n";
	    my $group_str = "";
	    foreach my $sp (sort @{ $split{$poly_sites[$i]}{1} } ) {
		$group_str .= $sp.".";
	    }
	    $seen_group{$group_str} = 1;
	}
    }
    my $count = 1; # the number of unique splits in interval i->j
    for (my $j=$i; $j<(@poly_sites); $j+=1) {
	# don't allow subseqs to span LCBs
	if (exists $LCBbound{$j}) { # site j is the beginning of a new LCB, so do not consider the subseq i,j...
	    unless ($j==$i) { # consider subseq of one poly site in length (j,j) is allowed
		last;
	    }
	}
	next if ($j > ($broken+$w)); # new in v1.4
	# if there are any homoplasies in the stretch i->j, build pars tree
	if ($skip_pars == 1) {
	    if (! exists $dimorphic{$poly_sites[$j]}) { # the site is >dimorphic, build pars trees including it
		$homoplasies = 1;
#	    print $j, " j not dimorphic\n";
	    }	
	    else {
		if ($homoplasies == 0) {	    
		    
		    for (my $k=$i; $k<=$j; $k++) { # the entire interval i->j must be consistent 
#		    print "group_list k = ", "@{ $split{$poly_sites[$k]}{1} }","\n";
			my $group_str = "";
			foreach my $sp (sort @{ $split{$poly_sites[$k]}{1} } ) {
			    $group_str .= $sp.".";
			}
			if (! exists $seen_group{$group_str}) {
#			print "group_list k = ", "@{ $split{$poly_sites[$k]}{1} }","\n";
			    $count++;
			    @ {$group_list{ $count } } = @{ $split{$poly_sites[$k]}{1} };
			    $seen_group{$group_str} = 1;
			}
		    }      
		    for (my $x=1; $x<=$count; $x++) {
			my @group1_1 = @{ $group_list{$x} };
			my $group1_2 = diffs(\@species, \@group1_1);
			my @group1_2 = @$group1_2;
#		    print "group1_1= ", "@group1_1","\n";
#		    print "group1_2= ", "@group1_2","\n";
			for (my $y=$x; $y<=$count; $y++) {
			    my @group2_1 = @{ $group_list{$y} };
			    my $group2_2 = diffs(\@species, \@group2_1);
			    my @group2_2 = @$group2_2;
#			print "group2_1= ", "@group2_1","\n";
#			print "group2_2= ", "@group2_2","\n";
			    my $num_crosses = 0;
			    my $intersect1_1 = intersect(\@group1_1, \@group2_1);
			    my $intersect2_2 = intersect(\@group1_2, \@group2_2);
			    my $intersect1_2 = intersect(\@group1_1, \@group2_2);
			    my $intersect2_1 = intersect(\@group1_2, \@group2_1);
			    my @intersect1_1 = @$intersect1_1;
			    my @intersect2_2 = @$intersect2_2;
			    my @intersect1_2 = @$intersect1_2;
			    my @intersect2_1 = @$intersect2_1;
			    if ( ((@intersect1_1+0) > 0) && ((@intersect1_2) > 0) ) { # If group1 at site j spans two previously defined groups at pos
				$num_crosses++;
			    }
			    if ( ((@intersect2_1+0) > 0) && ((@intersect2_2) > 0) ) { # if group2 at site j spans two previously defined groups at pos
				$num_crosses++;
			    }
			    if ($num_crosses >= 2) { # There is a break between blocks
				$homoplasies = 1;
#			    print join "\t", ($i+1), ($j+1), "yes-homo", "@group1_1", "@group1_2", "@group2_1", "@group2_2";
#			    print "\n";
				last;
			    }
#			else {
#			    print join "\t", ($i+1), ($j+1), "no-homo", "@group1_1", "@group1_2", "@group2_1", "@group2_2";
#			    print "\n";
#			}
			    last if ($homoplasies == 1);
			}
			last if ($homoplasies == 1);
		    }
		}
	    }
	    if ($homoplasies == 0) { # if there isn't any homoplasy between i and j, make a note and don't bother with pars tree
		my $lk = 0; # the log-likelihood of a perfectly parsimonious SNP is 0 (no penalty). The likelihood increases slightly (+1 log-like unit) for each consecutive parsimonious SNP to avoid over-fitting by putting unecessary breakpoints between them
		my $Nconsecutive = $j - $i;
		$lk += $Nconsecutive;
		print PERFECT join "\t", "0", ($i+1), ($j+1), $lk, "tree";
		print PERFECT "\n";
		next;
	    }
	}
	
	# evaluate whether subseq should be split based on phylo. discordance score
	my $start_region = 0; # does the region(i,j) start discordant?
	my $end_region = 0; # does the region end discordant?
	my $btw_region = 0; # are there discordances between start and end?
	if (exists $prebreaks{$poly_sites[$i]}) {
	    $start_region = 1;
	}
	if (exists $prebreaks{$poly_sites[$j]}) {
	    $end_region = 1;
	}
	my $N_discord_stretches = 0;
	my $first_discord_site = (-1);
	my $last_discord_site = 0;
	for (my $k=$i; $k<=$j; $k++) {
	    if (exists $prebreaks{$poly_sites[$k]}) {
		if ($first_discord_site == (-1) ) {
		    $first_discord_site = $k;
		}
		$btw_region++;
		if ($k > ($last_discord_site+1) ) { # start of a new discordant stretch
		    $N_discord_stretches++;
		}
		$last_discord_site = $k;
	    }
	}
	# skip obviously discordant stretches: these require at least 1 breakpoint somewhere btw. i&j
	if ( ($j-$i+1) > $w ) { # if the discordant stretch is less than the window size, we still want to consider this chunk. otherwise, skip * NEW in v1.4
	    if ($start_region == 0) { # region (i, j) begins in a region of concordance
		if ($end_region == 0) { # region(i,j) ends in a region of concordance
		    if ($N_discord_stretches >= 1) { # ... and there is at least 1 discordant stretch in btw.
			$broken = $j;
	#		print join "\t", ($i+1), ($j+1), "a-skipped";
	#		print "\n";
			next;		    
		    }
		}
		else { # ends in discordance region
		    if ($N_discord_stretches > 1) { # ... and there are more than 1 discordant stretches in btw.
			$broken = $j;
	#		print join "\t", ($i+1), ($j+1), "b-skipped";
	#		print "\n";
			next;
		    }
		}
	    }
	    else { # region (i,j) starts in discordant region
		if ($end_region == 0) { # region(i,j) ends in a region of concordance
		    if ($N_discord_stretches > 1) { # ... and there are more than 1 discordant stretches in btw.
			$broken = $j;
	#		print join "\t", ($i+1), ($j+1), "c-skipped";
	#		print "\n";
			next;
		    }
		}
		else { # ends in discordance region
		    if ($N_discord_stretches > 2) { # 1 concordant stretch with a discordant flank on either side is ok.
			$broken = $j;
	#		print join "\t", ($i+1), ($j+1), "d-skipped";
	#		print "\n";
			next;
		    }
		}
	    }
	}
	print SGE join "\t", $job_count, ($i+1), ($j+1);
	print SGE "\n";
	my $start = ($i+1);
	my $end = ($j+1);

	my $downstream_include = 0;
	if ($i == 0) { # if it's the very first informative site, include all upstream non-inform. sites
	    $downstream_include = 0;
	}
	else {
	    $downstream_include = $poly_sites[$i-1] + 1; # start at the first non-informative site AFTER the LAST informative site
	}
	my $upstream_include = $poly_sites[$j];
	my $true_length = $upstream_include - $downstream_include + 1;

	$subseq_len += $true_length;
	$sub_job_count++;
	# decide whether to continue with the same phylip file or start a new one
	if ($subseq_len >= $len_limit) {
	    $job_count++;
	    $sub_job_count = 0; # reset
	    $subseq_len = 0;
	}
	elsif ($sub_job_count == $node_lineup) {
	    $job_count++;
	    $sub_job_count = 0; # reset
	    $subseq_len = 0;
	}
	
	if ($job_count == 100 ) {
# finish SGE job file
	    # open new SGE batch file
	    $batch_count++;
	    $sge_file = $fasta;
	    $sge_file =~ s/\.fa$//;
	    my $curr_count = $start_site_max + $batch_count;
	    $sge_file .= ".".$curr_count.".subseqs.txt";
	    $job_count = 0; # reset
	    $subseq_len = 0;
	    $sub_job_count = 0;
	    close SGE;
	    open SGE, ">>$sge_file" || die "Can't open SGE file\n";
	    next;
	}
    }
}

print "\n";
#print stop time
print "Finish time:\n";
( $sec, $min, $hour, $day, $month, $year ) = ( localtime ) [ 0, 1, 2, 3, 4, 5 ];
printf  "%02d:%02d:%02d %02d %s %04d\n", 
    $hour, $min, $sec, $day, $Month_name[$month], $year+1900 ;

#returns a hash of sequence indexed by fasta headers
sub readFasta{
    my %fasta;
    my $line;
    my $length=0;
    my $header;

    for $line (@_){
        chomp $line;

        #find header lines
	if ($line =~ /^>(.+)/) {
            $header = $1;
#	    print $header,"\n";
            next;
        }

        #for non-header lines...
        if(defined($header)){
	    # only include species in the subset of interest
	    next unless (exists $subset{$header});
            #get rid of spaces
            $line =~ s/\s+//g;
            #append to the current sequence stored in %fasta
            $fasta{$header} .= $line;
        }
    }
    #return sequences indexed by headers
    return %fasta;
}

sub numeric {
    $a <=> $b;
}

sub diffs { # returns differences between 2 arrays
    my ($array1, $array2) = @_;
    my @array1 = @$array1;
    my @array2 = @$array2;
    my @union = my @intersection = my @difference = ();
    my %count = ();
    foreach my $element (@array1, @array2) {
	$count{$element}++;
    }
    foreach my $element (keys %count) {
	push @union, $element;
	push @{ $count{$element} > 1 ? \@intersection : \@difference }, $element;
    }
    return \@difference;
}

sub intersect { # returns the intersection between 2 arrays                                                                                                                                                     
    my ($array1, $array2) = @_;
    my @array1 = @$array1;
    my @array2 = @$array2;
    my @union = my @intersection = my @difference = ();
    my %count = ();
    foreach my $element (@array1, @array2) {
        $count{$element}++;
    }
    foreach my $element (keys %count) {
        push @union, $element;
        push @{ $count{$element} > 1 ? \@intersection : \@difference }, $element;
    }
    return \@intersection;
}

sub getSplit { # convert a site to 2 non-overlapping arrays
    my ($i,$j) = @_; # the sites of interest
    my %group;
#    print "sub_getSplit::\n";
    for (my $pos=$i; $pos< $j; $pos+=1) {
#	print "position= ", $pos,"\n";
	my $map = $dimo_sites[$pos];
	if (exists $r{$map}{$species[1]}) { # Only include dimorphic sites
	    my $ref_base = $r{$map}{$species[1]};

	    foreach my $sp (@species) {
		if ($r{$map}{$sp} eq $ref_base) {
		    push @{ $group{$map}{1} }, $sp;
#		    print "add ", $sp, " to group1\n";
		}
		else {
		    push @{ $group{$map}{2} }, $sp;
#		    print "add ", $sp, " to group2\n";
		}
	    }
	    # group1 always contains the shorter list of strain names
	    my @min;
	    my @max;
	    if ( (@{ $group{$map}{1} }+0) < (@{ $group{$map}{2} }+0) ) {
		@min = sort @{ $group{$map}{1} };
		@max = sort @{ $group{$map}{2} };
	    }
	    else {
		@min = sort @{ $group{$map}{2} };
		@max = sort @{ $group{$map}{1} };
	    }
	    @{ $group{$map}{1} } = @min;
	    @{ $group{$map}{2} } = @max;
#	    print join "\t", "@{ $group{$map}{1} }", "@{ $group{$map}{2} }";
#	    print "\n";
	}
    }
    return %group;
}
