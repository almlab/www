#!/usr/bin/perl -w

use strict;

my $starri_dir = $ARGV[0]; # the directory to run in. must contain the file "subseqs.list.txt", made by catting key.txt files from each contig together
my $breaks = $ARGV[1]; # the number of bins (e.g. 4 = quartiles)

if ($starri_dir =~ m/\/$/) {
    $starri_dir =~ s/\/$//;
}

my $contig_list = $starri_dir."/subseqs.list.txt";
unless (-e $contig_list) {
    $contig_list = $starri_dir."/key.txt";
}
unless (-e $contig_list) {
    print "Can't find ", $contig_list,"\n";
    exit;
}

# get info for contigs to optimize on
my %poly_map; # map polymorphic sites to their actual genomic/contig position
my %unmap; # map of true site => poly site
my %n; # the total number of polymorphic sites in the contig
my %lk; # the likelihood between informative sites i and j
my %subseqs; # the subseqs for which there should be likelihoods (if not, they are excluded due to phylogenetic incongruence
my %seenContig;
my %physLen; # the total number of bp in the contig, including invar sites
my %firstPoly; # the physical location of the first polymorphic site in the contig
my %lastPoly; #... and the last poly site in the contig
my @poly;
my @len;
my $max_poly = 0;
my $max_len = 0;
my $N = 0;
open CONT, $contig_list || die "Can't find $contig_list file\n";
while (<CONT>) {
    chomp;
    next if (m/^cont/);
    my ($contig, $physLen, $inform, $di, $tri, $quad, $nonInf, $lk_file, $map_file, $subseqs, $concat_file, $subset_file) = split "\t";
#    print $_,"\n";
    $physLen{$contig} = $physLen;
    unless (-e $map_file) {
	print $map_file, " does not exist!\n";
	exit;
    }
    unless (exists $seenContig{$contig}) {
	open MAP, "$map_file" || die "Can't find $map_file\n";
	while (<MAP>) {
	    chomp;
	    next if (m/poly/);
	    my ($poly_pos, $cont_pos, $Nvariants) = split "\t";
	    $poly_map{$contig}{$poly_pos} = $cont_pos;
	    $unmap{$contig}{$cont_pos} = $poly_pos;
	    $n{$contig} = $poly_pos;
	    if (!exists $firstPoly{$contig}) {
		$firstPoly{$contig} = $cont_pos;
	    }
	    elsif ($cont_pos < $firstPoly{$contig}) {
		$firstPoly{$contig} = $cont_pos;
	    }
	    if (!exists $lastPoly{$contig}) {
		$lastPoly{$contig} = $cont_pos;
	    }
	    elsif ($cont_pos > $lastPoly{$contig}) {
		$lastPoly{$contig} = $cont_pos;
	    }
	}
	close MAP;
    }
    $seenContig{$contig} = 1;
# read in likelihood for each subsequence ij
    unless (-e $lk_file) {
	print $lk_file, " does not exist!\n";
	exit;
    }
    open LK, $lk_file || die "Can't find $lk_file\n";
    while (<LK>) {
	chomp;
	my ($batch, $i, $j, $lk, $tree) = split "\t";
	my $poly_len = $j - $i + 1;
	my $bp = $poly_map{$contig}{$j} - $poly_map{$contig}{$i} + 1;
	my $poly_per_site = $poly_len / $bp;
	push @poly, $poly_per_site;
	push @len, $bp;
	if ($poly_per_site > $max_poly) {
	    $max_poly = $poly_per_site;
	}
	if ($bp > $max_len) {
	    $max_len = $bp;
	}
	$N++;
    }
    close LK;
}
close CONT;

print "max len = ", $max_len," bp\n";
print "max poly= ", $max_poly," snps/site\n";

my @sort_poly = sort numeric @poly;
my @sort_len = sort numeric @len;

# print percentiles (or quartiles, deciles, etc. as desired) of polymorphism and sequence length to files:
open POLY, ">poly.tiles.txt" || die;
open LEN, ">length.tiles.txt" || die;

my $bin_brk = int($N / $breaks);
my $curr_brk = $bin_brk;
my $count = 0;
while ($curr_brk < $N) {
    $count++;
#    print join "\t", $count, $curr_brk, $sort_poly[$curr_brk], $sort_len[$curr_brk];
#    print "\n";
    print POLY $sort_poly[$curr_brk], "\n";
    print LEN $sort_len[$curr_brk], "\n";
    $curr_brk += $bin_brk;
}

sub numeric {
    $a<=>$b;
}
