#!/usr/bin/perl -w

use strict;

my $starri_dir = $ARGV[0]; # the directory to run in. must contain the file "subseqs.list.txt", made by catting key.txt files from each contig together
my $poly_list = $ARGV[1]; # produced by perl /home/jesse1/STARRI/2.0/printDistr_poly_per_site.pl /home/jesse1/STARRI/2.0/vib/starriEM 10 > deciles.txt
my $len_list = $ARGV[2];

if ($starri_dir =~ m/\/$/) {
    $starri_dir =~ s/\/$//;
}

my $contig_list = $starri_dir."/subseqs.list.txt";
unless (-e $contig_list) {
    $contig_list = $starri_dir."/key.txt";
}
unless (-e $contig_list) {
    print "Can't find ", $contig_list,"\n";
    exit;
}

# get bin polymorphism and length bins
my @lengths;
my @polys;
open LEN, $len_list || die;
while (<LEN>) {
    chomp;
    push @lengths, $_;
}
close LEN;

open POLY, $poly_list || die;
while (<POLY>) {
    chomp;
    push @polys, $_;
}
close POLY;

# get info for contigs to optimize on
my %poly_map; # map polymorphic sites to their actual genomic/contig position
my %unmap; # map of true site => poly site
my %n; # the total number of polymorphic sites in the contig
my %lk; # the likelihood between informative sites i and j
my %subseqs; # the subseqs for which there should be likelihoods (if not, they are excluded due to phylogenetic incongruence
my %seenContig;
my %physLen; # the total number of bp in the contig, including invar sites
my %firstPoly; # the physical location of the first polymorphic site in the contig
my %lastPoly; #... and the last poly site in the contig
my %trees;
open CONT, $contig_list || die "Can't find $contig_list file\n";
while (<CONT>) {
    chomp;
    next if (m/^cont/);
    my ($contig, $physLen, $inform, $di, $tri, $quad, $nonInf, $lk_file, $map_file, $subseqs, $concat_file, $subset_file) = split "\t";
    print $_,"\n";
    $physLen{$contig} = $physLen;
    unless (-e $map_file) {
	print $map_file, " does not exist!\n";
	exit;
    }
    unless (exists $seenContig{$contig}) {
	open MAP, "$map_file" || die "Can't find $map_file\n";
	while (<MAP>) {
	    chomp;
	    next if (m/poly/);
	    my ($poly_pos, $cont_pos, $Nvariants) = split "\t";
	    $poly_map{$contig}{$poly_pos} = $cont_pos;
	    $unmap{$contig}{$cont_pos} = $poly_pos;
	    $n{$contig} = $poly_pos;
	    if (!exists $firstPoly{$contig}) {
		$firstPoly{$contig} = $cont_pos;
	    }
	    elsif ($cont_pos < $firstPoly{$contig}) {
		$firstPoly{$contig} = $cont_pos;
	    }
	    if (!exists $lastPoly{$contig}) {
		$lastPoly{$contig} = $cont_pos;
	    }
	    elsif ($cont_pos > $lastPoly{$contig}) {
		$lastPoly{$contig} = $cont_pos;
	    }
	}
	close MAP;
    }
    $seenContig{$contig} = 1;
# read in likelihood for each subsequence ij
    unless (-e $lk_file) {
	print $lk_file, " does not exist!\n";
	exit;
    }
    open LK, $lk_file || die "Can't find $lk_file\n";
    while (<LK>) {
	chomp;
	my ($batch, $i, $j, $lk, $tree) = split "\t";
	my $poly_len = $j - $i + 1;
	my $bp = $poly_map{$contig}{$j} - $poly_map{$contig}{$i} + 1;
	my $poly_per_site = $poly_len / $bp;
	my $last_len = 0;
	my $last_poly = 0;
	for (my $i=0; $i<=((@lengths+0)-1); $i++) {
	    for (my $j=0; $j<=(@polys+0); $j++) {
		my $last_i = $i-1;
		my $last_j = $j-1;
		my $last_len = 0;
		my $last_poly = 0;
		if ($last_i >= 0) {
		    $last_len = $lengths[$last_i];
		}
		if ($last_j >= 0) {
		    $last_poly = $polys[$last_j];
		}
		my $len = $lengths[$i];
		my $poly = $polys[$j];
		if ($bp > $last_len) {
		    if ($bp <= $len) {
			if ($poly_per_site > $last_poly) {
			    if ($poly_per_site <= $poly) {
				push @{ $trees{$len}{$poly} }, $tree;
			    }
			}
		    }
		}
	    }
	}
    }
    close LK;
}
close CONT;

# print out 100 random trees for each 2D bin
foreach my $len (sort numeric @lengths) {	    
    foreach my $poly (sort numeric @polys) {
	my $NtreesInBin = 0;
	my @trees = ();
	if (defined @{ $trees{$len}{$poly}}) {
	    @trees = @{ $trees{$len}{$poly}};
	}
	$NtreesInBin = (@trees+0);	
	print join "\t", $len, $poly, $NtreesInBin;
	print "\n";
	next if ($NtreesInBin == 0);

# shuffle trees
	fisher_yates_shuffle( \@trees );    # permutes @array in place
	my @final_trees; # a list of 100 trees with non-identical topologies

	while ( (@final_trees+0) < 101 ) {
	    last if ( (@trees+0) == 0);
	    while ( (@trees+0) > 0 ) {
		my $tree = pop(@trees);
		last if ( (@final_trees+0) >= 101 );
		my $nolen = $tree;
		$nolen =~ s/\:[\d\.\e]+\,/\,/g;
		$nolen =~ s/\:[\d\.\e]+\)/\)/g;
		my $identical = 0;
		foreach my $tree2 (@final_trees) {
		    my $nolen2 = $tree2;
		    $nolen2 =~ s/\:[\d\.\e]+\,/\,/g;
		    $nolen2=~ s/\:[\d\.\e]+\)/\)/g;
		    if ($nolen2 eq $nolen) {
			$identical = 1;
			last;
		    }
		}
		if ($identical == 1) { # don't add identical tree topologies to one we've already seen
		    next;
		}
		else {
		    push @final_trees, $tree;
#	    print $tree, "added\n";
		}
	    }
	}

	my $count = 1;
	my $outfile = "sampleTrees.len_".$len.".poly_".$poly.".txt";
	open OUT, ">$outfile" || die;
	foreach my $tree (@final_trees) {
	    my $nolen = $tree;
	    $nolen =~ s/\:[\d\.\e]+\,/\,/g;
	    $nolen =~ s/\:[\d\.\e]+\)/\)/g;    
	    print OUT join "\t", $count, $nolen, $tree;
	    print OUT "\n";
	    $count++;
	}
    }
}

# fisher_yates_shuffle( \@array ) : generate a random permutation
# of @array in place
sub fisher_yates_shuffle {
    my $array = shift;
    my $i;
    for ($i = @$array; --$i; ) {
        my $j = int rand ($i+1);
        next if $i == $j;
        @$array[$i,$j] = @$array[$j,$i];
    }
}

sub numeric {
    $a<=>$b;
}
