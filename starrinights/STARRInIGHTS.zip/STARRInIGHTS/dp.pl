#!/usr/bin/perl -w

use strict;

my $starri_dir = $ARGV[0]; # the directory to run in. must contain the file "subseqs.list.txt", made by catting key.txt files from each contig together
my $start_pB_file = $ARGV[1]; # initial log-likelihood of breakpoint per site

if ($starri_dir =~ m/\/$/) {
    $starri_dir =~ s/\/$//;
}

my $contig_list = $starri_dir."/subseqs.list.txt";
unless (-e $contig_list) {
    $contig_list = $starri_dir."/key.txt";
}
unless (-e $contig_list) {
    print "Can't find ", $contig_list,"\n";
    exit;
}

my $lcb_bound_file = $starri_dir."/LCB.boundaries.key.txt";
#my %bound;
my $N_lcb = 0;
if (-e $lcb_bound_file) {
    open LCB, $lcb_bound_file || die "can't open LCB.boundaries.key.txt\n";
    while (<LCB>) {
	chomp;
	next if (m/LCB/);
	my ($LCB, $contig, $start, $end, $ref1, $ref2, $strand) = split "\t";
#	$bound{$end} = 1;
	$N_lcb++;
    }
    print "read ", $lcb_bound_file,"\n";
    print $N_lcb, " LCBs total. Breaks between these to be excluded from nb counts\n";
    close LCB;
}

my @pBs;
my @alphas;
open PB, $start_pB_file || die "Can't open pb file\n";
while (<PB>) {
    chomp;
    push @pBs, $_;
}
close PB;

# get info for contigs to optimize on
my %poly_map; # map polymorphic sites to their actual genomic/contig position
my %unmap; # map of true site => poly site
my %n; # the total number of polymorphic sites in the contig
my %lk; # the likelihood between informative sites i and j
my %subseqs; # the subseqs for which there should be likelihoods (if not, they are excluded due to phylogenetic incongruence
my %seenContig;
my %physLen; # the total number of bp in the contig, including invar sites
my %firstPoly; # the physical location of the first polymorphic site in the contig
my %lastPoly; #... and the last poly site in the contig
open CONT, $contig_list || die "Can't find $contig_list file\n";
while (<CONT>) {
    chomp;
    next if (m/^cont/);
    my ($contig, $physLen, $inform, $di, $tri, $quad, $nonInf, $lk_file, $map_file, $subseqs, $concat_file, $subset_file) = split "\t";
    print $_,"\n";
    $physLen{$contig} = $physLen;
    unless (-e $map_file) {
	print $map_file, " does not exist!\n";
	exit;
    }
    unless (exists $seenContig{$contig}) {
	open MAP, "$map_file" || die "Can't find $map_file\n";
	while (<MAP>) {
	    chomp;
	    next if (m/poly/);
	    my ($poly_pos, $cont_pos, $Nvariants) = split "\t";
	    $poly_map{$contig}{$poly_pos} = $cont_pos;
	    $unmap{$contig}{$cont_pos} = $poly_pos;
	    $n{$contig} = $poly_pos;
	    if (!exists $firstPoly{$contig}) {
		$firstPoly{$contig} = $cont_pos;
	    }
	    elsif ($cont_pos < $firstPoly{$contig}) {
		$firstPoly{$contig} = $cont_pos;
	    }
	    if (!exists $lastPoly{$contig}) {
		$lastPoly{$contig} = $cont_pos;
	    }
	    elsif ($cont_pos > $lastPoly{$contig}) {
		$lastPoly{$contig} = $cont_pos;
	    }
	}
	close MAP;
    }
    $seenContig{$contig} = 1;
# read in likelihood for each subsequence ij
    unless (-e $lk_file) {
	print $lk_file, " does not exist!\n";
	exit;
    }
    open LK, $lk_file || die "Can't find $lk_file\n";
    while (<LK>) {
	chomp;
	my ($batch, $i, $j, $lk, $tree) = split "\t";
	if ($i == $j) { # a recombination block can't be just one bp long
	    $lk{$contig}{$i}{$j} = (-10000000000);
	}
	else {
	    $lk{$contig}{$i}{$j} = $lk;
	}
    }
    close LK;
    print "read ", $lk_file,"\n";

# read in intended subsequences ij
    unless (-e $subseqs) {
	my $new_subseqs_file = 'na';
	if ($concat_file =~ m/(.+)contig/) {
	    $new_subseqs_file = $1.$subseqs;
	}
	if ($new_subseqs_file ne 'na') {
	    $subseqs = $new_subseqs_file;
	    unless (-e $subseqs) {
		print $subseqs, " does not exist!\n";
		exit;
	    }
	}
	else {
	    print $subseqs, " does not exist!\n";
	    exit;
	}
    }
    open SUBS, $subseqs || die "Can't find $subseqs\n";
    while (<SUBS>) {
	chomp;
	my ($batch, $i, $j) = split "\t";
	$subseqs{$contig}{$i}{$j} = $batch;
    }
    close SUBS;
    print "read ", $subseqs,"\n";
}
close CONT;
print "done reading subseqs files\n";

# check to make sure all subseqs have been stored
print "missed subseqs:\n";
foreach my $contig (keys %physLen) {
    foreach my $i (keys %{$subseqs{$contig}}) {
	foreach my $j (keys %{ $subseqs{$contig}{$i} }) {
	    if (exists $lk{$contig}{$i}{$j}) {
		if ($lk{$contig}{$i}{$j} !~ m/[\d\-\.]+/) {
		    print join "\t", $contig, $i, $j, $lk{$contig}{$i}{$j};		    
		}
	    }
	    else {
		print join "\t", $contig, $i, $j, "not exist";
		print "\n";
	    }
	}
    }
}
#exit;
# iterate over possible initial breakpoint prob's
foreach my $start_pB (sort numeric @pBs) {
    print "start pB= ", $start_pB,"\n";
    my $outfile = $starri_dir."/starri.init.pB_".$start_pB.".out";
    open OUT, ">$outfile" || die "Can't open $outfile\n";
    
    # print start time
    print OUT "Start time:\n";
    my @Month_name = ( "January", "February", "March", "April", "May", "June",
		       "July", "August", "September", "October", "November", "December" );
    my ( $sec, $min, $hour, $day, $month, $year ) = ( localtime ) [ 0, 1, 2, 3, 4, 5 ];
    printf  OUT "%02d:%02d:%02d %02d %s %04d\n", 
    $hour, $min, $sec, $day, $Month_name[$month], $year+1900 ;
    
    print OUT "Initializing...\n";
# initialize with starting probs
    my $nb = 0; # the number of breakpoints, summed over all positions and all sequences
    my $N = 0; # the total number of sites across all contigs
    my $blocks_lk = 0; # the summed likelihood of all blocks
    foreach my $contig (keys %physLen) {
# run STARRI with the current starting params
	my $Bcost = (-1)*($start_pB); # the cost of a breakpoint is high when the log-prob of a breakpoint is low
	my $breaks = starri($contig, $Bcost);
	my @breaks = @$breaks;
	my $contig_starri_out = $starri_dir."/STARRI.2.0.noEM.".$contig.".init.pB_".$start_pB.".out";
	open BREAKS, ">$contig_starri_out" || die "Can't open file $contig_starri_out\n";
	print BREAKS "@breaks";
	print BREAKS "\n";
	print OUT "done first STARRI run for contig ", $contig,"\n";
	print "done first STARRI run for contig ", $contig,"\n";
	my $blocks_out = $starri_dir."/STARRI.2.0.noEM.".$contig.".init.pB_".$start_pB.".blocks.out";
	open BLOCKFILE, ">$blocks_out" || die "Can't open $blocks_out\n";
# add ni and nb from the current sequence to the total
	my $nb_curr = (@breaks+0);
	$nb += ($nb_curr - 2); # add the number of breaks in this contig to the total, minus the edges (one breakpoint on each end =2 )
	my $last_break = $breaks[$#breaks];
	$N += $physLen{$contig};
	for (my $i=($#breaks-1); $i>=0; $i-=1) {
	    my $start_block = $last_break;
	    my $end_block = $breaks[$i] - 1;
	    $last_break = $breaks[$i];
	    $blocks_lk += $lk{$contig}{$start_block}{$end_block};
	    my $L = $poly_map{$contig}{$end_block} - $poly_map{$contig}{$start_block} + 1;
	    print BLOCKFILE join "\t", $start_block, $end_block, $poly_map{$contig}{$start_block}, $poly_map{$contig}{$end_block}, $L;
	    print BLOCKFILE "\n";
	}
    }
    # exclude breaks between LCBs from breakpoint counts
    $nb = $nb - ($N_lcb - 1);
    if ($nb < 0) {
	$nb = 0;
    }
# get likelihood of all contigs under the current prob
    my $p_brk_unlog = exp($start_pB);
    if ($p_brk_unlog >= 1) {
	$p_brk_unlog = ($N-1)/$N;
    }
    my $p_no_brk = ( log(1-$p_brk_unlog) );
	
    my $p_brk = ($start_pB)*($nb);
    my $p_not = ($p_no_brk)*($N - $nb);
    
    my $last_L = $p_brk + $p_not + $blocks_lk;
    
    print OUT "P_brk     = ", $p_brk,"\n";
    print OUT "P_noevnt  = ", $p_not,"\n";
    print OUT "P_blocks  = ", $blocks_lk,"\n\n";
    
    print OUT "last_L= ", $last_L, "\n";
    print OUT "N= ", $N, " sites\n";
    print OUT "nb= ", $nb,"\n";
	
    print "last_L= ", $last_L, "\n";
    print "N= ", $N, " sites\n";
    print "nb= ", $nb,"\n";
    
    print OUT "Finish time:\n";
    ( $sec, $min, $hour, $day, $month, $year ) = ( localtime ) [ 0, 1, 2, 3, 4, 5 ];
    printf OUT "%02d:%02d:%02d %02d %s %04d\n", 
    $hour, $min, $sec, $day, $Month_name[$month], $year+1900 ;
}

sub starri { # runs dp to find optimal breakpoint locations
    my ($contig, $Bcost) = @_;
    my %B; # the minimum score for for the stretch 0-->n
    $B{0} = 0;
    my %traceback;
    my $n = $n{$contig}; # the number of polymorphic sites in the current contig (not including singletons)
    print "starri:\n";
    for (my $j=1; $j<=$n; $j+=1) {
	my %f;
	for (my $i=1; $i<=$j; $i+=1) {
	    my $lk_cost = 1e10;
	    if (exists $lk{$contig}{$i}{$j}) {
		$lk_cost = (-1)*($lk{$contig}{$i}{$j});
	    }
	    else {
#		print "lk cost ", $i, " ", $j, " does not exist!\n";
	    }
	    my $L = $poly_map{$contig}{$j} - $poly_map{$contig}{$i};
	    my $noBcost = (-1)*((log (1 - exp((-1)*$Bcost)))*$L);
	    $f{$i} = $B{$i-1} + $lk_cost + $Bcost + $noBcost;
	}
	my $min = 1e10;
	for (my $i=1; $i<$j; $i+=1) {    
	    if ($f{$i} < $min) {
		$min = $f{$i};
		$traceback{$j} = $i-1; # propose a break between SNP i and i-1
#		print "traceback ( ", $j," ) = ",($i-1),"\n"; 
	    }
	}
	$B{$j} = $min;
#	print "*";
    }
#    print "done\n";
    my $last_break = $n;
    my $end_contig = $last_break+1;
    my @breaks;
    push (@breaks, $end_contig);
#    print "@breaks","\n";
    while ($last_break > 1) {
	$last_break = $traceback{$last_break};
	print $last_break,"\n";
	push(@breaks, ($last_break+1)); # @breaks is a list of block START positions
    }
    print "end\n";
    return \@breaks;
}

sub numeric {
    $a<=>$b;
}
