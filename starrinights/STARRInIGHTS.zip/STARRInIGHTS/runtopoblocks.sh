java -classpath .:ext-lib/colt.jar:./ext-lib/commons-collections-3.2.jar -jar topoblocks.jar $1 $2 $3
