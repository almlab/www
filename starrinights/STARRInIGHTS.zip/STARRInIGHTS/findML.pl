#!/usr/bin/perl -w

use strict;

my $glob = $ARGV[0];

my %like;
my %nb;
my %ni;
my %final_pB;
my %final_pM;

$glob .= "*";

print join "\t", "pBinit", "pB", "like", "nb";
print "\n";

foreach my $em_file (glob $glob) {
    if ($em_file =~ m/\.init\.pB\_([\-\d\.e]+)\.out/) {
	my $pB = $1;
	my $like = (-1e100);
	my $nb = 'na';
	my $final_pB = 'na';
	my $best_like = (-1e100);
	my $best_nb = 'na';
	my $best_final_pB = 'na';
	open EM, $em_file || die "Can't open em file\n";
	my $curr_best = 0;
	while (<EM>) {
	    chomp;
#	    print $_, "\t\t\t", $curr_best,"\t", $best_like, "\t",$best_nb,"\n";
	    if (m/^new ln L= ([\d\-\.e]+)/) {
		$like = $1;
		if ($like > $best_like) {
		    $best_like = $like;
		    $curr_best = 1;
		}
		else {
		    $curr_best = 0;
		}
	    }

	    if ($curr_best == 1) {
		if (m/^[currfinal]+ nb= ([\d\-\.]+)/) {
#		    print "NB== ", $1,"\n";
		    $nb = $1;
		}
		if (m/^[currfinal]+ log\( P\(B\) \)= ([\d\-\.]+)/) {
		    $final_pB = $1;
		}
#		print "******\n";
		$best_nb = $nb;
		$best_final_pB = $final_pB;
	    }
	}
	close EM;
	print join "\t", $pB, $best_final_pB, $best_like, $best_nb;
	print "\n";
	$like{$pB} = $best_like;
	$nb{$pB} = $best_nb;
	$final_pB{$pB} = $best_final_pB;
    }
}
