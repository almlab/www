#!/usr/bin/perl -w

use strict;

my $glob = "sampleTrees.len_*";

foreach my $tree_file (glob $glob) {

    my $sim_len = 'na';
    my $poly = 'na';
    if ($tree_file =~ m/sampleTrees\.len\_(\d+)\.poly\_([\d\.]+)\.txt/) {
	$sim_len = $1;
	$poly = $2;
    }
    
    my $Ncontigs = 1;
    while ($Ncontigs < 101) { # keep simulating until we get 100 sequences, ideally each from a different tree unless this is not possible based on the observed data
	open TREES, $tree_file || die;
	while (<TREES>) {
	    chomp;
	    my ($count, $noLen, $tree) = split "\t";
	    open CURRTREE, ">curr.tree.tmp" || die;
	    print CURRTREE $tree,"\n";
	    close CURRTREE;
	    `/Applications/./seq-gen -mHKY -l$sim_len -n1 < curr.tree.tmp > seqgen.tmp`;
	    `rm curr.tree.tmp`;
	    my %seq1;
	    my $sim_count = 0;
	    open SEQ1, "seqgen.tmp" ||die;
	    while (<SEQ1>) {
		chomp;
		if (m/^[\s]+[\d]+/) { # new sim of $length bp
		    $sim_count++;
		}
		elsif (m/^([\w\d]+)[\s]+([\w]+)/) {
		    $seq1{$1} = $2;
		}
	    }
	    close SEQ1;
	    `rm seqgen.tmp`;
	    
	    # write to contig files
	    my $onetree = "contig.".$sim_len."_".$poly."_".$count.".concat3.fa";
	    open ONE, ">$onetree" || die;
	    foreach my $sp (sort keys %seq1) {
		print ONE ">",$sp,"\n";
		print ONE $seq1{$sp},"\n";
	    }
	    $Ncontigs++;
	}
	close TREES;
    }
}
