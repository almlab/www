function [x,locus_order]=recombination(x,k,r,L,B,select_frac,locus_order)

%find commulative population distribution

xt= sum(x);
col_com=x;
for i=2:length(col_com)
    col_com(1,i)=col_com(1,(i-1))+col_com(1,i);
end
col_com=col_com./xt;

extant_count = 0; % number of columns with extant genotypes
for i=1:size(x,2)
    if x(1,i) > 0
        extant_count = i;
    end
    x_ext(i) = extant_count;
end

%total # recombination events in the population
num_rec = (r*xt*(B+L));
reset(RandStream.getDefaultStream,sum(100*clock))
if num_rec > 0
    for i=1:num_rec     
        %randomly choose an extant donor genotype (column)
        from_col=col_com-rand;
        from_col=find(from_col>0,1,'first');
        from_col=x_ext(from_col);

        %randomly chose recipient genotype (column)
        to_col=col_com-rand;
        to_col=find(to_col>0,1,'first');
        to_col=x_ext(to_col);

        % randomly choose a locus to recombine
        locus=round(rand*(B+L));
        if locus == 0
            locus = 1;
        elseif locus > (B+L)
            locus = (B+L);
        end
        % take away one individual from recipient genotype
        x(1,to_col)=x(1,to_col)-1; % delete old allele
        % select the right new genotype to add to
        acceptor_geno = locus_order(:,to_col);
        donor_geno = locus_order(:,from_col);

        new_geno = acceptor_geno;

        new_geno(locus) = donor_geno(locus); % new genotype is the acceptor genotype, replaced with the donor allele at 1 locus
        % find location of the new genotype in matrix x
        loc=0;
        for h=1:length(select_frac)
            curr_geno = locus_order(:,h);
            if sum(abs(curr_geno - new_geno)) == 0
                loc=h;
                break
            end
        end
        % add a count to this new genotype
        x(1,loc) = x(1,loc) + 1;
    end
end

x(x<0)=0; %if removed too many 
