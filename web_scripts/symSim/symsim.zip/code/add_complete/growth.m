function x=growth(x,k,s,select_frac)

%% set parameters
d  = .1;     % death rate 
bm = 10;     % maximal birth rate
F  = 1;      % amout of food available per generation     
reset(RandStream.getDefaultStream,sum(100*clock))
% % let each genotype grow in its most fit niche. if equally fit in each
% % niche, choose at random.
niches = ones(size(select_frac));
w = ones(size(select_frac)); % fitness
Nw0 = 0; % total fitness in niche 0
Nw1 = 0; % total fitness in niche 1
for i=1:length(select_frac)
  niche=0;
  if select_frac(1,i) < 0.5
    niche=0;
  end
  if select_frac(1,i) > 0.5
    niche=1;
  end
  if select_frac(1,i) == 0.5
    random_frac = rand(1);
    if random_frac > 0.5
      niche=1;
    end
    if random_frac < 0.5
      niche=0;
    end
    if random_frac == 0.5
      random_frac = rand(1);
      if random_frac >= 0.5
        niche=1;
      end
      if random_frac < 0.5
        niche=0;
      end
    end
  end
  if niche == 0 % compete in niche 0, where genotype 000000... has max fitness       
    niches(1,i) = 0;
    prob=( ( (1-select_frac(1,i))*s) );
    w(1,i)=1+prob;
    Nw0=Nw0+(x(1,i)*w(1,i));
  end
  if niche == 1 % compete in niche 1, where genotype 111111... has max fitness
    niches(1,i) = 1;
    prob=( ( (select_frac(1,i))*s) );
    w(1,i)=1+prob;
    Nw1=Nw1+(x(1,i)*w(1,i));
  end
end

F0  = (bm/d-1)/(k/F); % Half saturation constat of birth function
Fx = 0; % the amount of food per individual of genotype x
%% allocate food proportional to fitness
for i=1:length(select_frac)
  if niches(1,i) == 0
    if Nw0 > 0
      Fx = F*w(1,i)/Nw0; % avg amount of food per individual of type x
    end
    lx = 1 - d + bm*Fx/(Fx + F0); % avg number of projeny per individual (including self)
    Nx=poissrnd(x(1,i)*lx);
    x(1,i) = Nx; % new number of genotypes x in the next generation
  end
  if niches(1,i) == 1    
    if Nw1 > 0
      Fx = F*w(1,i)/Nw1; % avg amount of food per individual of type x
    end
    lx = 1 - d + bm*Fx/(Fx + F0); % avg number of projeny per individual (including self)
    Nx=poissrnd(x(1,i)*lx);
    x(1,i) = Nx; % new number of genotypes x in the next generation
  end
end
