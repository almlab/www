function [clonality takeover]=symsim(rep,r,s,k,L,B)

% output file
batch=1; % write new output file every 1000000 gen's
filename = strcat('symsim.B_', num2str(B), '.r_', num2str(r), '.s_', num2str(s), '.k_', num2str(k), '.L_', num2str(L), '.rep_', num2str(rep), '.batch_', num2str(batch), '.txt');

% write header to file
line = ['t ', 'xt'];
outfile = fopen( filename, 'a');
fprintf(outfile,'%s',line);
fclose('all');

% keep track of proportion 'selected alleles' each genotype in x contains
LB=((2^L)*(2^B));
select_frac=zeros(1,LB);
locus_order=zeros((L+B),LB); % order of loci for this genotype. e.g. can be 001, 010 or 100
start_fill=1;
for i=0:L
    Nways = factorial(L)/( (factorial(i))*(factorial(L-i))); % L choose i ways of getting i selected alleles
    for j=start_fill:(start_fill+Nways-1)
        select_frac(1,j) = (i/L);
        % create locus ordering
        keep_trying = 1; % keep trying allele combos until an unused one is found
        while keep_trying > 0
            % reset the locus order
            locus_order(:,j) = zeros;
            N_ones = i; % the number of '1' alleles to place in L loci
            while N_ones > 0
                h=round(rand*L);
                if h == 0
                    h = 1;
                elseif h > L
                    h = L;
                end
                locus_order(h,j) = 1;
                N_ones = N_ones - 1;
            end
            % make sure the new allele combo is unique
            curr_order = locus_order(:,j);
            same=0;
            for h=1:(j-1)
                prev_order = locus_order(:,h);
                if sum(abs(curr_order - prev_order)) == 0
                    same=1;
                    break
                end
            end
            if same == 1
                keep_trying = 1;
            else
                keep_trying = 0;
                break
            end           
        end
        outfile = fopen( filename, 'a');
        fprintf(outfile,'%s',' ',num2str(locus_order(:,j)));
        fclose('all');
    end
    start_fill = start_fill + Nways;
end

% find combos of bg alleles
bg_order=zeros(B,(2^B)); % order of loci for this genotype. e.g. can be 001, 010 or 100
start_fill=1;
for i=0:B
    Nways = factorial(B)/( (factorial(i))*(factorial(B-i))); % L choose i ways of getting i selected alleles
    for j=start_fill:(start_fill+Nways-1)
        % create locus ordering
        keep_trying = 1; % keep trying allele combos until an unused one is found
        while keep_trying > 0
            % reset the locus order
            bg_order(:,j) = zeros;
            N_ones = i; % the number of '1' alleles to place in L loci
            while N_ones > 0
                h=round(rand*B);
                if h == 0
                    h = 1;
                elseif h > B
                    h = B;
                end
                bg_order(h,j) = 1;
                N_ones = N_ones - 1;
            end
            % make sure the new allele combo is unique
            curr_order = bg_order(:,j);
            same=0;
            for h=1:(j-1)
                prev_order = bg_order(:,h);
                if sum(abs(curr_order - prev_order)) == 0
                    same=1;
                    break
                end
            end
            if same == 1
                keep_trying = 1;
            else
                keep_trying = 0;
                break
            end           
        end
    end
    start_fill = start_fill + Nways;
end

% fill in background loci into locus_order
for q=1:2^B
    start_fill=q*(2^L)+1;
    if start_fill > LB
        break
    end
    
    for i=0:L
        Nways = factorial(L)/( (factorial(i))*(factorial(L-i)));
        for j=start_fill:(start_fill+Nways-1)
            select_frac(1,j) = (i/L);
            % create locus ordering
            locus_order(:,j) = zeros;
            locus_order(:,j) = locus_order(:,(j-(2^L)));
            % add in bg loci
            bg_col = floor(((start_fill-1)/(2^L))+1);
            locus_order((L+1):(L+B),j) = bg_order(:,bg_col);
            
            outfile = fopen( filename, 'a');
            fprintf(outfile,'%s',' ',num2str(locus_order(:,j)));
            fclose('all');
        end
        start_fill = start_fill + Nways;
    end
end
outfile = fopen( filename, 'a');
fprintf(outfile, '\n');
fclose('all');

% ancestral genotype (000...) makes up 95% of population
% niche-1 adapted geno (111...) makes up 1%
% all non-ancestral genotypes together make up remaining 4% of
% population

x=zeros(1,(LB)); % x is the number of individuals of each genotype
for i=1:LB
    if sum(locus_order(1:L,i)) == 0 % ancestral (niche-0-adapted) gets bg 00
        if sum(locus_order((L+1):(L+B),i)) == 0
            x(1,i)=(0.95)*k;
        else
            x(1,i)=0;
        end
    elseif sum(locus_order(1:L,i)) == L % niche-1-adapted gets bg 11
        if sum(locus_order((L+1):(L+B),i)) == B
            x(1,i)=(0.01)*k;
        else
            x(1,i)=0;
        end
    else % intermediates all get bg 00
        if sum(locus_order((L+1):(L+B),i)) == 0
            x(1,i)=(0.04/((2^L)-2))*k;
        else
            x(1,i)=0;
        end
    end
end

% iterate for a maximum of t_end generations, or until the intermediate
% genotypes go extinct
t_end=20000000;
t=1;
bg_geno=zeros(2,(2^B));
while sum(x) > 0 && t < t_end
    % check to make sure extreme genotypes haven't taken over 95% of the
    % population:
    xt=sum(x);
    curr_f1 = 0;
    curr_f2 = 0;
    freq_intermed = 0;
    for i=1:LB
        if sum(locus_order(1:L,i)) == 0 % ancestral (niche-0-adapted)
            curr_f1 = curr_f1 + x(1,i);
        elseif sum(locus_order(1:L,i)) == L % derived (niche-1-adapted)  
            curr_f2 = curr_f2 + x(1,i);
        else
	  freq_intermed = freq_intermed + x(1,i);
        end
    end


    % new output file every 1000000 gen's
    if mod( (t-1), 1000000 ) == 0
        batch = batch + 1;
    end
    
    % write results to file every 10 generations
    if mod( (t-1), 10 ) == 0
        t;
        curr_f1;
        curr_f2;
        line = [t, xt, x];
        % output file
        filename = strcat('symsim.B_', num2str(B), '.r_', num2str(r), '.s_', num2str(s), '.k_', num2str(k), '.L_', num2str(L), '.rep_', num2str(rep), '.batch_', num2str(batch), '.txt');
        outfile = fopen( filename, 'a');
        fprintf(outfile, '%5.5G\t', line);
        fprintf(outfile, '\n');
        fclose('all');
    end
    
    
    %&&&&Growth
    x=growth(x,k,s,select_frac);   
    
    %%%%recombination, selected allele 
    if r > 0
        x=recombination(x,k,r,L,B,select_frac,locus_order);
    end
    
    t=t+1;
end

outfile = fopen( filename, 'a');
fprintf(outfile, '\nDone!\n\n');
fclose('all');
